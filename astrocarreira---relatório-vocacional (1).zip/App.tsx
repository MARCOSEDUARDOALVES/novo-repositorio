
import React, { useState, useCallback } from 'react';
import { UserData, PaymentStatus, ReportState, ApiResponse } from './types';
import { generateVocationalReport } from './services/gemini';
import AstroChart from './components/AstroChart';
import LocationAutocomplete from './components/LocationAutocomplete';
import StepLoader from './components/StepLoader';
import SimulatedPayment from './components/SimulatedPayment';
import VocationalRanking from './components/VocationalRanking';
import { 
  ArrowRight, 
  Target, 
  Zap, 
  ShieldAlert,
  CalendarCheck,
  Award,
  AlertCircle,
  Flame,
  Droplets,
  Wind,
  Mountain,
  Sun,
  Compass
} from 'lucide-react';

// Logo SVG da Águia Árabe com Sol
const ArabicEagleLogo = ({ className = "w-12 h-12" }) => (
  <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="50" cy="50" r="48" stroke="currentColor" strokeWidth="0.5" strokeDasharray="2 2" className="opacity-30" />
    <path d="M50 15C35 15 25 25 20 40C20 40 35 35 50 35C65 35 80 40 80 40C75 25 65 15 50 15Z" fill="currentColor" />
    <path d="M50 35L45 55L50 50L55 55L50 35Z" fill="currentColor" />
    <path d="M30 45C20 55 15 75 15 85C30 80 45 70 50 50C55 70 70 80 85 85C85 75 80 55 70 45" stroke="currentColor" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
    <circle cx="50" cy="30" r="4" fill="#FBBF24" />
  </svg>
);

const ElementIcon = ({ element }: { element?: string }) => {
  const e = element?.toLowerCase() || '';
  if (e.includes('fogo')) return <Flame className="text-orange-500" size={24} />;
  if (e.includes('água')) return <Droplets className="text-blue-500" size={24} />;
  if (e.includes('ar')) return <Wind className="text-cyan-500" size={24} />;
  if (e.includes('terra')) return <Mountain className="text-emerald-700" size={24} />;
  return <Zap className="text-indigo-500" size={24} />;
};

const App: React.FC = () => {
  const [userData, setUserData] = useState<UserData>({
    name: '',
    birthDate: '',
    birthTime: '',
    location: ''
  });

  const [report, setReport] = useState<ReportState>({
    loading: false,
    paymentStatus: PaymentStatus.FREE
  });

  const [showCheckout, setShowCheckout] = useState(false);
  const [view, setView] = useState<'form' | 'report'>('form');

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setUserData(prev => ({ ...prev, [name]: value }));
  };

  const handleGenerate = useCallback(async (status: PaymentStatus = PaymentStatus.FREE) => {
    if (!userData.birthDate || !userData.location) {
      alert("Por favor, preencha data e local de nascimento.");
      return;
    }
    
    setReport(prev => ({ ...prev, loading: true, error: undefined, paymentStatus: status }));
    setView('report');

    try {
      const result = await generateVocationalReport(userData, status);
      setReport({ loading: false, data: result, paymentStatus: status });
    } catch (err) {
      console.error(err);
      setReport(prev => ({ ...prev, loading: false, error: "Falha na conexão com os astros. Tente novamente." }));
    }
  }, [userData]);

  const reset = () => {
    setView('form');
    setReport({ loading: false, paymentStatus: PaymentStatus.FREE });
    setShowCheckout(false);
  };

  return (
    <div className="min-h-screen bg-[#FDFCFB] text-slate-900 selection:bg-amber-100 overflow-x-hidden">
      {/* Background Decorativo Celestial */}
      <div className="fixed inset-0 pointer-events-none opacity-[0.03] z-0 overflow-hidden">
        <svg width="100%" height="100%">
          <pattern id="zodiac" x="0" y="0" width="200" height="200" patternUnits="userSpaceOnUse">
            <text x="20" y="40" fontSize="30" fill="currentColor">♈</text>
            <text x="120" y="140" fontSize="30" fill="currentColor">♌</text>
            <text x="60" y="100" fontSize="30" fill="currentColor">♐</text>
          </pattern>
          <rect width="100%" height="100%" fill="url(#zodiac)" />
        </svg>
      </div>

      <nav className="sticky top-0 z-50 px-8 py-4 flex justify-between items-center bg-white/90 backdrop-blur-xl border-b border-slate-100 shadow-sm">
        <div className="flex items-center gap-4 cursor-pointer group" onClick={reset}>
          <div className="text-indigo-950 transition-transform group-hover:scale-110 duration-500">
            <ArabicEagleLogo className="w-12 h-12" />
          </div>
          <div className="flex flex-col">
            <span className="font-serif text-2xl font-black tracking-tighter text-indigo-950 leading-none">AstroCarreira</span>
            <span className="text-[9px] uppercase tracking-[0.4em] font-bold text-amber-500">Janus Applied Astrology</span>
          </div>
        </div>
        {view === 'report' && !report.loading && (
          <button onClick={reset} className="group relative flex items-center gap-2 overflow-hidden bg-indigo-950 text-white px-8 py-3 rounded-full font-black text-[10px] uppercase tracking-widest hover:bg-indigo-900 transition-all">
            <span className="relative z-10">Novo Mapa</span>
            <Compass size={14} className="relative z-10 group-hover:rotate-180 transition-transform duration-700" />
          </button>
        )}
      </nav>

      <main className="relative z-10 max-w-[1400px] mx-auto px-6 py-12">
        {view === 'form' ? (
          <div className="max-w-3xl mx-auto py-20 text-center space-y-16">
            <div className="space-y-6">
               <div className="inline-flex items-center gap-3 px-4 py-2 bg-amber-50 border border-amber-100 rounded-full text-amber-700 text-[10px] font-black uppercase tracking-widest animate-bounce">
                 <Sun size={14} /> Sol em Escorpião Ativo
               </div>
               <h1 className="text-6xl md:text-8xl font-serif text-indigo-950 font-black leading-[0.9] tracking-tighter">
                 Sua rota de <span className="italic text-amber-500">Poder</span> começa aqui.
               </h1>
               <p className="text-slate-400 text-xl font-light max-w-xl mx-auto leading-relaxed">
                 O motor astrológico mais preciso do mundo, agora com a visão da Águia Janus.
               </p>
            </div>

            <div className="relative group">
              <div className="absolute -inset-1 bg-gradient-to-r from-amber-400 to-indigo-600 rounded-[4rem] blur opacity-20 group-hover:opacity-40 transition duration-1000"></div>
              <div className="relative bg-white rounded-[3.5rem] p-12 shadow-2xl border border-slate-50 text-left">
                <div className="space-y-10">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-3">
                      <label className="text-[11px] font-black text-slate-400 uppercase tracking-[0.2em] ml-2">Nome de Batismo</label>
                      <input name="name" onChange={handleInputChange} value={userData.name} className="w-full bg-slate-50 border-2 border-transparent rounded-[1.5rem] px-8 py-5 focus:bg-white focus:border-amber-400 focus:ring-0 outline-none transition-all text-xl font-medium" placeholder="Ex: Ibrahim Silva" />
                    </div>
                    <div className="space-y-3">
                      <label className="text-[11px] font-black text-slate-400 uppercase tracking-[0.2em] ml-2">Local de Nascimento</label>
                      <LocationAutocomplete value={userData.location} onChange={(val) => setUserData(p => ({...p, location: val}))} placeholder="Brasília, DF..." />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-8">
                    <div className="space-y-3">
                      <label className="text-[11px] font-black text-slate-400 uppercase tracking-[0.2em] ml-2">Data</label>
                      <input type="date" name="birthDate" value={userData.birthDate} onChange={handleInputChange} className="w-full bg-slate-50 border-2 border-transparent rounded-[1.5rem] px-8 py-5 focus:bg-white focus:border-amber-400 outline-none font-medium" />
                    </div>
                    <div className="space-y-3">
                      <label className="text-[11px] font-black text-slate-400 uppercase tracking-[0.2em] ml-2">Hora Exata</label>
                      <input type="time" name="birthTime" value={userData.birthTime} onChange={handleInputChange} className="w-full bg-slate-50 border-2 border-transparent rounded-[1.5rem] px-8 py-5 focus:bg-white focus:border-amber-400 outline-none font-medium" />
                    </div>
                  </div>

                  <button 
                    onClick={() => handleGenerate(PaymentStatus.FREE)}
                    className="w-full relative group overflow-hidden bg-indigo-950 text-white font-black py-8 rounded-[2rem] shadow-2xl transition-all transform hover:scale-[1.01] active:scale-[0.98] text-2xl uppercase tracking-tighter"
                  >
                    <div className="absolute inset-0 bg-gradient-to-r from-amber-500 to-amber-600 translate-x-[-100%] group-hover:translate-x-0 transition-transform duration-500"></div>
                    <span className="relative z-10 flex items-center justify-center gap-4">
                      Ver meu Destino <ArrowRight size={24} className="text-amber-400" />
                    </span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="animate-in fade-in slide-in-from-bottom-5 duration-700">
            {report.loading ? (
              <StepLoader />
            ) : report.error ? (
              <div className="bg-red-50 p-16 rounded-[3.5rem] text-center border border-red-100 max-w-2xl mx-auto space-y-6 shadow-2xl">
                <AlertCircle className="mx-auto text-red-500" size={64} />
                <p className="text-red-700 text-2xl font-black font-serif">{report.error}</p>
                <button onClick={() => setView('form')} className="bg-red-600 text-white px-10 py-5 rounded-full font-bold uppercase tracking-widest text-xs shadow-lg">Reiniciar Sistema</button>
              </div>
            ) : report.data && (
              <div className="flex flex-col lg:flex-row gap-16 items-start">
                
                <aside className="w-full lg:w-[480px] shrink-0 lg:sticky lg:top-32 space-y-8">
                  <AstroChart data={report.data.astroData} userName={userData.name} />
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-8 bg-white rounded-[2.5rem] border border-slate-100 shadow-sm space-y-4">
                      <div className="flex items-center gap-3">
                        <div className="p-3 bg-amber-50 rounded-2xl">
                          <ElementIcon element={report.data.primaryElement} />
                        </div>
                        <div>
                          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">Elemento</span>
                          <span className="text-lg font-bold text-slate-800 capitalize">{report.data.primaryElement}</span>
                        </div>
                      </div>
                    </div>
                    <div className="p-8 bg-indigo-950 rounded-[2.5rem] text-white shadow-xl flex flex-col justify-center">
                       <span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest block mb-2">Padrão Janus</span>
                       <span className="text-sm font-medium leading-tight">Visão Saqr Calibrada</span>
                    </div>
                  </div>
                </aside>

                <section className="flex-1 space-y-20 bg-white rounded-[4rem] p-8 md:p-24 shadow-3xl border border-slate-50 relative overflow-hidden">
                  <div className="absolute top-0 right-0 opacity-[0.02] -translate-y-1/2 translate-x-1/4">
                    <ArabicEagleLogo className="w-[800px] h-[800px]" />
                  </div>

                  {report.paymentStatus === PaymentStatus.FREE && (
                    <div className="inline-block bg-amber-400 text-indigo-950 px-6 py-2 rounded-full font-black text-[12px] uppercase tracking-[0.2em] shadow-xl shadow-amber-400/20">
                      Relatório Preview
                    </div>
                  )}

                  <div className="space-y-12 max-w-4xl relative z-10">
                    <h2 className="text-6xl md:text-8xl font-serif text-indigo-950 font-black leading-[0.85] tracking-tighter">
                      Sua essência <span className="text-amber-500 italic">Estratégica</span>
                    </h2>
                    
                    {(report.data as any).coreInsight && (
                      <div className="relative p-10 bg-indigo-50/40 rounded-[3rem] border border-indigo-100 group">
                        <div className="absolute top-6 left-6 text-amber-500 opacity-20">
                           <Sun size={48} />
                        </div>
                        <span className="text-[10px] font-black text-indigo-600 uppercase tracking-[0.4em] block mb-6 text-center">Conselho Real de Carreira</span>
                        <p className="text-indigo-950 text-2xl font-bold italic leading-relaxed text-center px-8">
                          "{(report.data as any).coreInsight}"
                        </p>
                      </div>
                    )}
                  </div>

                  <div className="prose prose-slate prose-2xl max-w-none space-y-16 relative z-10">
                     <div className="whitespace-pre-line text-slate-700 text-2xl leading-relaxed font-light">
                        {report.data.reportText}
                     </div>
                  </div>

                  {report.paymentStatus === PaymentStatus.FREE ? (
                    <div className="mt-40 pt-20 border-t border-slate-100 relative z-10">
                      <div className="bg-indigo-950 rounded-[4rem] p-12 md:p-28 text-white shadow-3xl text-center space-y-12 overflow-hidden relative group">
                        <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/20 to-transparent pointer-events-none"></div>
                        <div className="absolute top-10 left-1/2 -translate-x-1/2 text-white/5">
                           <ArabicEagleLogo className="w-96 h-96" />
                        </div>
                        
                        <div className="relative z-10 space-y-6">
                          <h3 className="text-5xl md:text-7xl font-serif font-black leading-tight tracking-tighter">
                            A visão completa <br/>da sua <span className="text-amber-400 italic">Jornada.</span>
                          </h3>
                          <p className="text-indigo-200/60 text-2xl font-light max-w-2xl mx-auto">
                            Desbloqueie o ranking de cargos, sabotadores ocultos e seu plano de execução de 30 dias.
                          </p>
                        </div>
                        
                        <button 
                          onClick={() => setShowCheckout(true)}
                          className="w-full relative z-10 bg-amber-400 hover:bg-white text-indigo-950 font-black py-10 px-16 rounded-[3rem] shadow-2xl transition-all transform hover:scale-[1.02] active:scale-[0.97] text-3xl uppercase tracking-tighter"
                        >
                          Ativar Premium Janus
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-40 animate-in slide-in-from-bottom-20 duration-1000 pt-20 relative z-10">
                       {report.data.professions && <VocationalRanking professions={report.data.professions} />}
                       
                       <div className="grid md:grid-cols-2 gap-20">
                          <div className="space-y-12">
                            <h4 className="text-4xl font-serif font-black text-indigo-950 flex items-center gap-6">
                               <div className="w-14 h-14 bg-amber-50 rounded-2xl flex items-center justify-center text-amber-600"><Award size={32} /></div> Talentos Janus
                            </h4>
                            <div className="space-y-8">
                              {report.data.talents?.map((t, idx) => (
                                <div key={idx} className="bg-slate-50/50 p-10 rounded-[3rem] border border-slate-100 group hover:bg-white hover:shadow-xl transition-all">
                                  <p className="font-black text-indigo-600 uppercase tracking-widest text-[11px] mb-4">{t.name}</p>
                                  <p className="text-slate-500 text-lg leading-relaxed italic">"{t.example}"</p>
                                </div>
                              ))}
                            </div>
                          </div>
                          <div className="space-y-12">
                            <h4 className="text-4xl font-serif font-black text-indigo-950 flex items-center gap-6">
                               <div className="w-14 h-14 bg-red-50 rounded-2xl flex items-center justify-center text-red-600"><ShieldAlert size={32} /></div> Sabotadores
                            </h4>
                            <div className="space-y-8">
                              {report.data.saboteurs?.map((s, idx) => (
                                <div key={idx} className="bg-red-50/20 p-10 rounded-[3rem] border border-red-100/30 space-y-6">
                                  <p className="font-black text-red-700 uppercase tracking-widest text-[11px]">{s.pattern}</p>
                                  <p className="text-md text-slate-500 italic leading-relaxed">{s.howItAppears}</p>
                                  <div className="bg-white p-6 rounded-3xl text-sm font-bold text-slate-800 border border-red-100 shadow-sm">
                                    Ação Janus: {s.fix}
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                       </div>

                       {report.data.plan && (
                          <div className="bg-indigo-950 rounded-[5rem] p-12 md:p-32 text-white shadow-3xl relative overflow-hidden">
                             <div className="absolute top-0 right-0 opacity-10 translate-x-1/4 -translate-y-1/4">
                               <ArabicEagleLogo className="w-[600px] h-[600px]" />
                             </div>
                             <div className="space-y-20 relative z-10">
                               <div className="space-y-6 text-center">
                                  <h3 className="text-5xl md:text-8xl font-serif font-black tracking-tighter">
                                     Plano de <span className="text-amber-400 italic">Voo</span>
                                  </h3>
                                  <p className="text-indigo-300 text-2xl font-light">Os próximos 30 dias para sua ascensão.</p>
                               </div>
                               <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-10">
                                 {report.data.plan.map((step, idx) => (
                                   <div key={idx} className="bg-white/5 border border-white/10 p-10 rounded-[3rem] backdrop-blur-md">
                                     <span className="text-amber-400 text-[11px] font-black uppercase tracking-widest block mb-6 border-b border-white/10 pb-4">{step.week}</span>
                                     <h4 className="font-bold text-xl mb-8 leading-tight">{step.title}</h4>
                                     <div className="space-y-5">
                                       {step.tasks.map((task, tidx) => (
                                         <div key={tidx} className="text-sm text-indigo-100/60 leading-relaxed flex items-start gap-4">
                                           <div className="w-2 h-2 bg-amber-400 rounded-full mt-1.5 shrink-0 shadow-[0_0_10px_rgba(251,191,36,0.5)]"></div>
                                           {task}
                                         </div>
                                       ))}
                                     </div>
                                   </div>
                                 ))}
                               </div>
                             </div>
                          </div>
                       )}
                    </div>
                  )}
                </section>
              </div>
            )}
          </div>
        )}
      </main>

      {showCheckout && (
        <SimulatedPayment 
          onCancel={() => setShowCheckout(false)} 
          onSuccess={() => {
            setShowCheckout(false);
            handleGenerate(PaymentStatus.PAID);
          }} 
        />
      )}
    </div>
  );
};

export default App;
