
import React, { useState, useMemo } from 'react';
import { AstroData, PlanetData } from '../types';
// Added missing Sun import from lucide-react
import { Search, ZoomOut, X, Sun } from 'lucide-react';

const ZODIAC_SIGNS = [
  'Áries', 'Touro', 'Gêmeos', 'Câncer', 'Leão', 'Virgem',
  'Libra', 'Escorpião', 'Sagitário', 'Capricórnio', 'Aquário', 'Peixes'
];

const ZODIAC_SYMBOLS: Record<string, string> = {
  'Áries': '♈', 'Touro': '♉', 'Gêmeos': '♊', 'Câncer': '♋', 'Leão': '♌', 'Virgem': '♍',
  'Libra': '♎', 'Escorpião': '♏', 'Sagitário': '♐', 'Capricórnio': '♑', 'Aquário': '♒', 'Peixes': '♓'
};

const ZODIAC_COLORS: Record<string, string> = {
  'Áries': '#FF4D4D', 'Touro': '#4CAF50', 'Gêmeos': '#FBBF24', 'Câncer': '#2196F3',
  'Leão': '#F59E0B', 'Virgem': '#8BC34A', 'Libra': '#F06292', 'Escorpião': '#B71C1C',
  'Sagitário': '#9C27B0', 'Capricórnio': '#455A64', 'Aquário': '#03A9F4', 'Peixes': '#3F51B5'
};

const PLANET_SYMBOLS: Record<string, string> = {
  'Sol': '☉', 'Lua': '☽', 'Mercúrio': '☿', 'Vênus': '♀', 'Marte': '♂', 'Júpiter': '♃', 'Saturno': '♄', 'Urano': '♅', 'Netuno': '♆', 'Plutão': '♇'
};

const ArabicEagleIcon = () => (
  <g transform="translate(-15, -15) scale(0.3)">
    <path d="M50 15C35 15 25 25 20 40C20 40 35 35 50 35C65 35 80 40 80 40C75 25 65 15 50 15Z" fill="#1E1B4B" />
    <path d="M50 35L45 55L50 50L55 55L50 35Z" fill="#F59E0B" />
    <path d="M30 45C20 55 15 75 15 85C30 80 45 70 50 50C55 70 70 80 85 85C85 75 80 55 70 45" stroke="#1E1B4B" strokeWidth="4" strokeLinecap="round" />
  </g>
);

const AstroChart: React.FC<AstroChartProps> = ({ data, userName }) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const planetPositions = useMemo(() => {
    return data.planets.map(p => {
      const signIdx = ZODIAC_SIGNS.indexOf(p.sign);
      return {
        ...p,
        absDeg: (signIdx * 30) + p.degree
      };
    });
  }, [data.planets]);

  const rotationOffset = useMemo(() => {
    if (data.ascendantSign) {
      const signIdx = ZODIAC_SIGNS.indexOf(data.ascendantSign);
      const ascDeg = (signIdx * 30) + (data.ascendantDegree || 0);
      return 180 - ascDeg;
    }
    return 0;
  }, [data.ascendantSign, data.ascendantDegree]);

  const centerX = 200;
  const centerY = 200;
  const outerRadius = 180;
  const zodiacRadius = 165;
  const innerRadius = 145;
  const aspectRadius = 140;

  const getPos = (deg: number, r: number) => {
    const rad = (deg + rotationOffset) * (Math.PI / 180);
    return {
      x: centerX + r * Math.cos(rad),
      y: centerY + r * Math.sin(rad)
    };
  };

  const ChartSVG = ({ size }: { size: number }) => (
    <svg viewBox="0 0 400 400" width={size} height={size} className="drop-shadow-2xl overflow-visible">
      <defs>
        <radialGradient id="sunGlow">
          <stop offset="0%" stopColor="#FEF3C7" stopOpacity="0.4" />
          <stop offset="100%" stopColor="white" stopOpacity="0" />
        </radialGradient>
      </defs>

      <circle cx={centerX} cy={centerY} r={outerRadius + 10} fill="url(#sunGlow)" />
      <circle cx={centerX} cy={centerY} r={outerRadius} fill="white" stroke="#F1F5F9" strokeWidth="1" />
      <circle cx={centerX} cy={centerY} r={zodiacRadius} fill="#F8FAFC" stroke="#E2E8F0" strokeWidth="0.5" />
      
      {ZODIAC_SIGNS.map((sign, i) => {
        const startDeg = i * 30;
        const lineStart = getPos(startDeg, outerRadius);
        const lineEnd = getPos(startDeg, innerRadius);
        const symbolPos = getPos(startDeg + 15, (zodiacRadius + innerRadius) / 2);
        
        return (
          <g key={sign}>
            <line x1={lineStart.x} y1={lineStart.y} x2={lineEnd.x} y2={lineEnd.y} stroke="#E2E8F0" strokeWidth="1" />
            <text 
              x={symbolPos.x} y={symbolPos.y} 
              fontSize="18" textAnchor="middle" alignmentBaseline="middle" 
              fill={ZODIAC_COLORS[sign]}
              className="font-serif font-bold filter drop-shadow-[0_1px_1px_rgba(0,0,0,0.1)]"
            >
              {ZODIAC_SYMBOLS[sign]}
            </text>
          </g>
        );
      })}

      {Array.from({ length: 12 }).map((_, i) => {
        const deg = i * 30;
        const lineStart = getPos(deg, innerRadius);
        const lineEnd = getPos(deg, 45);
        const numPos = getPos(deg + 15, 68);
        
        return (
          <g key={i}>
            <line x1={lineStart.x} y1={lineStart.y} x2={lineEnd.x} y2={lineEnd.y} stroke="#F8FAFC" strokeWidth="1" />
            <text x={numPos.x} y={numPos.y} fontSize="9" textAnchor="middle" alignmentBaseline="middle" fill="#CBD5E1" className="font-black italic">
              {i + 1}
            </text>
          </g>
        );
      })}

      {planetPositions.map((p, i) => {
        const pos = getPos(p.absDeg, innerRadius - 15);
        const tickStart = getPos(p.absDeg, innerRadius);
        const tickEnd = getPos(p.absDeg, innerRadius - 5);
        
        return (
          <g key={i}>
            <line x1={tickStart.x} y1={tickStart.y} x2={tickEnd.x} y2={tickEnd.y} stroke="#F59E0B" strokeWidth="2" />
            <circle cx={pos.x} cy={pos.y} r="11" fill="white" stroke="#F1F5F9" strokeWidth="1" className="shadow-sm" />
            <text 
              x={pos.x} y={pos.y} 
              fontSize="16" textAnchor="middle" alignmentBaseline="middle" 
              fill="#1E1B4B"
              className="font-bold"
            >
              {PLANET_SYMBOLS[p.name] || p.symbol}
            </text>
          </g>
        );
      })}

      <g transform={`translate(${centerX}, ${centerY})`}>
        <circle r="35" fill="white" stroke="#F59E0B" strokeWidth="0.5" strokeDasharray="2 2" />
        <ArabicEagleIcon />
      </g>
    </svg>
  );

  return (
    <div className="flex flex-col items-center w-full">
      <div className="relative bg-white rounded-[3rem] p-10 shadow-3xl border border-slate-50 flex flex-col items-center group w-full max-w-[450px]">
        <button 
          onClick={() => setIsExpanded(true)}
          className="absolute top-8 right-8 p-3 bg-amber-50 text-amber-600 rounded-2xl hover:bg-indigo-950 hover:text-white transition-all z-10 shadow-sm"
        >
          <Search size={20} />
        </button>

        <div className="w-full aspect-square flex items-center justify-center">
          <ChartSVG size={400} />
        </div>
        
        <div className="mt-12 text-center space-y-2">
          <h3 className="text-indigo-950 font-serif text-2xl font-black tracking-tight leading-tight">Configuração de {userName?.split(' ')[0] || 'Destino'}</h3>
          <p className="text-slate-400 text-xs font-medium uppercase tracking-[0.2em]">Cálculo Saqr / Janus Precision</p>
        </div>
      </div>

      {isExpanded && (
        <div className="fixed inset-0 z-[1000] flex items-center justify-center p-8 bg-white/95 backdrop-blur-2xl animate-in fade-in duration-500">
          <button 
            onClick={() => setIsExpanded(false)}
            className="absolute top-12 right-12 flex items-center gap-3 text-slate-400 hover:text-amber-500 font-black uppercase tracking-widest text-[10px] transition-all"
          >
            Fechar Mandala <X size={24} />
          </button>
          
          <div className="max-w-5xl w-full flex flex-col items-center animate-in zoom-in-95 duration-700">
            <ChartSVG size={700} />
            <div className="mt-16 text-center space-y-4">
              <h2 className="text-5xl font-serif text-indigo-950 font-black tracking-tighter">Sua Assinatura Cósmica</h2>
              <p className="text-amber-500 font-black uppercase tracking-[0.3em] text-xs">Visão Expandida Janus</p>
            </div>
          </div>
        </div>
      )}

      <div className="mt-10 w-full bg-white rounded-[3rem] shadow-xl border border-slate-50 overflow-hidden">
        <div className="bg-slate-50/50 px-10 py-5 border-b border-slate-100 flex justify-between items-center">
          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Coordenadas Saqr</span>
          {/* Corrected missing Sun icon below */}
          <Sun size={14} className="text-amber-400" />
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="text-[10px] font-black text-slate-300 uppercase tracking-widest">
                <th className="px-10 py-5">Astro</th>
                <th className="px-6 py-5">Signo</th>
                <th className="px-6 py-5">Posição</th>
              </tr>
            </thead>
            <tbody className="text-slate-700">
              {data.planets.map((p, idx) => (
                <tr key={idx} className="border-t border-slate-50 hover:bg-amber-50/30 transition-colors group">
                  <td className="px-10 py-6 flex items-center gap-4">
                    <span className="text-2xl text-indigo-950 font-bold group-hover:scale-125 transition-transform">{PLANET_SYMBOLS[p.name] || p.symbol}</span>
                    <span className="text-sm font-black text-slate-800">{p.name}</span>
                  </td>
                  <td className="px-6 py-6">
                    <div className="flex items-center gap-3">
                      <span className="text-xl" style={{ color: ZODIAC_COLORS[p.sign] }}>{ZODIAC_SYMBOLS[p.sign]}</span>
                      <span className="text-xs font-bold text-slate-500">{p.sign}</span>
                    </div>
                  </td>
                  <td className="px-6 py-6">
                    <span className="text-[11px] font-mono font-bold text-indigo-300">
                      {Math.floor(p.degree)}° {Math.round((p.degree % 1) * 60)}'
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AstroChart;
