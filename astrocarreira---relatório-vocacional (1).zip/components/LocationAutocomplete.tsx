
import React, { useState, useEffect, useRef } from 'react';

interface LocationAutocompleteProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
}

interface Suggestion {
  display_name: string;
  name: string;
  address: {
    city?: string;
    town?: string;
    village?: string;
    city_district?: string;
    suburb?: string;
    state?: string;
    country?: string;
    region?: string;
  };
}

const LocationAutocomplete: React.FC<LocationAutocompleteProps> = ({ value, onChange, placeholder }) => {
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const timeoutRef = useRef<number | null>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const fetchSuggestions = async (query: string) => {
    if (query.length < 2) return;
    setIsLoading(true);
    try {
      // Busca específica focada em cidades brasileiras
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=6&addressdetails=1&countrycodes=br&accept-language=pt-BR`
      );
      const data = await response.json();
      setSuggestions(data);
      setIsOpen(data.length > 0);
    } catch (error) {
      console.error("Erro na busca de localização:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onChange(e.target.value);
    if (timeoutRef.current) window.clearTimeout(timeoutRef.current);
    timeoutRef.current = window.setTimeout(() => fetchSuggestions(e.target.value), 300);
  };

  const handleSelect = (s: Suggestion) => {
    const addr = s.address;
    const city = addr.city || addr.town || addr.city_district || addr.suburb || s.name;
    const state = addr.state || "";
    
    // Tratamento robusto para Brasília/Distrito Federal
    let formatted = "";
    if (state.toLowerCase().includes("distrito federal") || city.toLowerCase() === "brasília") {
      formatted = "Brasília, Distrito Federal";
    } else {
      formatted = `${city}, ${state}`;
    }
    
    onChange(formatted);
    setIsOpen(false);
    setSuggestions([]);
  };

  return (
    <div className="relative w-full" ref={dropdownRef}>
      <input
        type="text"
        value={value}
        onChange={handleInputChange}
        onFocus={() => suggestions.length > 0 && setIsOpen(true)}
        placeholder={placeholder}
        className="w-full bg-slate-50 border-transparent rounded-[1.5rem] px-8 py-5 focus:bg-white focus:ring-4 focus:ring-indigo-500/10 outline-none transition-all text-xl font-medium"
      />
      {isLoading && (
        <div className="absolute right-6 top-1/2 -translate-y-1/2 w-5 h-5 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
      )}
      {isOpen && (
        <div className="absolute z-[100] w-full mt-3 bg-white border border-slate-100 rounded-[1.5rem] shadow-2xl max-h-64 overflow-y-auto overflow-x-hidden">
          {suggestions.map((s, i) => (
            <button
              key={i}
              type="button"
              onClick={() => handleSelect(s)}
              className="w-full text-left px-6 py-4 hover:bg-indigo-50 transition-all border-b border-slate-50 last:border-0 flex flex-col group"
            >
              <span className="font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">
                {s.address.city || s.address.town || s.name}
              </span>
              <span className="text-xs text-slate-400 uppercase tracking-widest">
                {s.address.state || "Brasil"}
              </span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

export default LocationAutocomplete;
