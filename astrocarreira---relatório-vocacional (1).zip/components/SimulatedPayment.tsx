
import React, { useState } from 'react';
import { CreditCard, Lock, ShieldCheck } from 'lucide-react';

interface SimulatedPaymentProps {
  onSuccess: () => void;
  onCancel: () => void;
}

const SimulatedPayment: React.FC<SimulatedPaymentProps> = ({ onSuccess, onCancel }) => {
  const [isProcessing, setIsProcessing] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      onSuccess();
    }, 2500);
  };

  return (
    <div className="fixed inset-0 z-[100] bg-slate-900/40 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-white rounded-[2rem] shadow-2xl w-full max-w-md overflow-hidden animate-in zoom-in-95 duration-300">
        <div className="bg-indigo-900 p-8 text-white relative">
          <button onClick={onCancel} className="absolute top-4 right-4 text-white/50 hover:text-white">✕</button>
          <h3 className="text-2xl font-bold mb-2">Checkout Premium</h3>
          <p className="text-indigo-200 text-sm">Desbloqueie seu futuro profissional agora.</p>
          <div className="mt-6 flex justify-between items-end">
            <span className="text-3xl font-bold">R$ 47,90</span>
            <span className="text-indigo-300 text-xs uppercase tracking-widest font-bold">Pagamento Único</span>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-8 space-y-4">
          <div className="space-y-1">
            <label className="text-[10px] font-bold text-slate-400 uppercase">Número do Cartão</label>
            <div className="relative">
              <input 
                required
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-slate-800 outline-none focus:ring-2 focus:ring-indigo-500" 
                placeholder="0000 0000 0000 0000"
              />
              <CreditCard className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-400 uppercase">Validade</label>
              <input required className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 outline-none" placeholder="MM/AA" />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-400 uppercase">CVC</label>
              <div className="relative">
                <input required className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 outline-none" placeholder="123" />
                <Lock className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-300" size={16} />
              </div>
            </div>
          </div>

          <button 
            disabled={isProcessing}
            className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-4 rounded-xl shadow-lg shadow-indigo-200 transition-all flex items-center justify-center gap-2"
          >
            {isProcessing ? (
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
            ) : (
              <>Pagar com Cartão</>
            )}
          </button>

          <div className="flex items-center justify-center gap-4 pt-4 grayscale opacity-40">
             <ShieldCheck size={16} />
             <span className="text-[10px] font-bold uppercase tracking-tighter">Conexão Criptografada SSL</span>
          </div>
        </form>
      </div>
    </div>
  );
};

export default SimulatedPayment;
