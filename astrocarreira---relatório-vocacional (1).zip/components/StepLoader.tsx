
import React, { useState, useEffect } from 'react';
import { Sparkles, Compass, Map, Search } from 'lucide-react';

const steps = [
  { icon: Compass, label: "Mapeando abóbada celeste..." },
  { icon: Sparkles, label: "Calculando Ascendente e Casas..." },
  { icon: Search, label: "Cruzando planetas com a 10ª Casa..." },
  { icon: Map, label: "Sintetizando rotas vocacionais..." }
];

const StepLoader: React.FC = () => {
  const [currentStep, setCurrentStep] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentStep(s => (s < steps.length - 1 ? s + 1 : s));
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex flex-col items-center justify-center py-20 px-6">
      <div className="relative w-24 h-24 mb-12">
        <div className="absolute inset-0 border-4 border-indigo-100 rounded-full"></div>
        <div className="absolute inset-0 border-4 border-indigo-600 rounded-full border-t-transparent animate-spin"></div>
        <div className="absolute inset-0 flex items-center justify-center text-indigo-600">
          {React.createElement(steps[currentStep].icon, { size: 32 })}
        </div>
      </div>
      
      <div className="space-y-6 w-full max-w-xs">
        {steps.map((step, idx) => (
          <div 
            key={idx} 
            className={`flex items-center gap-3 transition-all duration-500 ${
              idx === currentStep ? 'opacity-100 scale-100 font-bold text-indigo-900' : 
              idx < currentStep ? 'opacity-40 grayscale' : 'opacity-20'
            }`}
          >
            <div className={`w-2 h-2 rounded-full ${idx <= currentStep ? 'bg-indigo-600' : 'bg-slate-300'}`}></div>
            <span className="text-sm">{step.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default StepLoader;
