
import React from 'react';
import { Profession } from '../types';
import { TrendingUp, Briefcase } from 'lucide-react';

interface VocationalRankingProps {
  professions: Profession[];
}

const VocationalRanking: React.FC<VocationalRankingProps> = ({ professions }) => {
  return (
    <div className="space-y-6 mt-12">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 bg-amber-100 text-amber-600 rounded-full flex items-center justify-center">
          <Briefcase size={20} />
        </div>
        <h3 className="text-xl font-bold text-slate-900">Seu Top 5 Vocacional</h3>
      </div>

      <div className="grid gap-4">
        {professions.map((p, i) => (
          <div key={i} className="group bg-white border border-slate-100 p-6 rounded-3xl hover:border-indigo-200 hover:shadow-xl hover:shadow-indigo-50 transition-all">
            <div className="flex justify-between items-start mb-4">
              <div>
                <span className="text-[10px] font-bold text-indigo-600 uppercase tracking-widest bg-indigo-50 px-2 py-1 rounded-md mb-2 inline-block">Recomendação #{i+1}</span>
                <h4 className="text-lg font-bold text-slate-900">{p.title}</h4>
              </div>
              <div className="text-right">
                <div className="text-2xl font-black text-indigo-600">{p.score}%</div>
                <div className="text-[10px] font-bold text-slate-400 uppercase">Match Astral</div>
              </div>
            </div>
            
            <p className="text-slate-600 text-sm leading-relaxed mb-4">{p.why}</p>
            
            <div className="flex items-center gap-2">
              <TrendingUp size={14} className="text-emerald-500" />
              <span className="text-xs font-bold text-slate-500 uppercase">Tendência de Mercado: </span>
              <span className="text-xs font-bold text-emerald-600 uppercase">{p.marketTrend}</span>
            </div>

            <div className="mt-4 w-full h-1 bg-slate-100 rounded-full overflow-hidden">
              <div 
                className="h-full bg-indigo-500 rounded-full transition-all duration-1000 ease-out"
                style={{ width: `${p.score}%` }}
              ></div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default VocationalRanking;
