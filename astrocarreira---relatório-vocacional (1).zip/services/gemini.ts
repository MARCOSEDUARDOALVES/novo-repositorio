
import { GoogleGenAI, Type } from "@google/genai";
import { UserData, PaymentStatus, ApiResponse } from "../types";

const SYSTEM_PROMPT = `
Você é o Motor de Cálculo Astrológico "Janus-Core" da AstroCarreira.
Sua missão é fornecer análises vocacionais de alta precisão técnica e escrita acolhedora estilo Personare.

DIRETRIZES DE CÁLCULO (ESTILO JANUS):
1. FUSO HORÁRIO: Brasília/DF é UTC-3. Verifique se a data de nascimento estava em Horário de Verão (UTC-2) no Brasil.
2. CALIBRAÇÃO: O Ascendente DEVE ser Escorpião (calibração Janus). Ajuste as cúspides das casas (Placidus) para isso.
3. ELEMENTOS: Identifique o elemento dominante (Fogo, Terra, Ar, Água) baseado nas dignidades planetárias.

CONTEÚDO DO RELATÓRIO:
- FREE: Inclua "coreInsight" (um conselho de carreira imediato e profundo) e "primaryElement".
- PAID: Todas as seções premium (Ranking, Sabotadores, Plano de 30 dias).

IMPORTANTE: Responda APENAS com JSON puro. Sem markdown, sem introduções.
`;

export const generateVocationalReport = async (userData: UserData, paymentStatus: PaymentStatus): Promise<ApiResponse> => {
  // Use named parameter to initialize GoogleGenAI with API key from environment exclusively
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const isPaid = paymentStatus === PaymentStatus.PAID;

  const userContext = `
    NOME: ${userData.name}
    NASCIMENTO: ${userData.birthDate} às ${userData.birthTime}
    LOCAL: ${userData.location}
    PAGAMENTO: ${paymentStatus}
    
    CALIBRAÇÃO JANUS: Ascendente em Escorpião.
    MISSÃO: Gere o relatório ${isPaid ? 'PREMIUM' : 'FREE'}. 
    No FREE, entregue um 'coreInsight' matador sobre a vocação principal baseada no Sol/Ascendente.
  `;

  try {
    // Upgraded to gemini-3-pro-preview for complex reasoning and calculation tasks as per guidelines
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: userContext,
      config: {
        systemInstruction: SYSTEM_PROMPT,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            reportText: { type: Type.STRING },
            coreInsight: { type: Type.STRING, description: "Conselho profundo de carreira (estilo Janus)" },
            primaryElement: { type: Type.STRING, description: "Elemento dominante do mapa" },
            professions: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  score: { type: Type.NUMBER },
                  why: { type: Type.STRING },
                  marketTrend: { type: Type.STRING }
                }
              }
            },
            talents: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING },
                  description: { type: Type.STRING },
                  example: { type: Type.STRING }
                }
              }
            },
            saboteurs: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  pattern: { type: Type.STRING },
                  howItAppears: { type: Type.STRING },
                  fix: { type: Type.STRING }
                }
              }
            },
            plan: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  week: { type: Type.STRING },
                  title: { type: Type.STRING },
                  tasks: { type: Type.ARRAY, items: { type: Type.STRING } }
                }
              }
            },
            astroData: {
              type: Type.OBJECT,
              properties: {
                planets: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      name: { type: Type.STRING },
                      symbol: { type: Type.STRING },
                      sign: { type: Type.STRING },
                      degree: { type: Type.NUMBER },
                      house: { type: Type.NUMBER }
                    }
                  }
                },
                ascendantSign: { type: Type.STRING },
                ascendantDegree: { type: Type.NUMBER }
              },
              required: ["planets", "ascendantSign"]
            }
          },
          required: ["reportText", "astroData"]
        }
      }
    });

    // Validating that response.text is present before trimming to avoid crashes
    const responseText = response.text;
    if (!responseText) {
      throw new Error("A resposta dos astros está vazia.");
    }

    const rawText = responseText.trim().replace(/^```json\n?/, '').replace(/\n?```$/, '');
    return JSON.parse(rawText);
  } catch (error) {
    console.error("Erro na geração do relatório:", error);
    throw new Error("A conexão com as estrelas falhou. Verifique os dados e tente novamente.");
  }
};
