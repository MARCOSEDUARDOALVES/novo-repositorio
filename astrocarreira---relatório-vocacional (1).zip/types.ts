
// Add UserData interface to store form input information
export interface UserData {
  name: string;
  birthDate: string;
  birthTime: string;
  location: string;
}

export enum PaymentStatus {
  FREE = 'FREE',
  PAID = 'PAID'
}

export interface Profession {
  title: string;
  score: number;
  why: string;
  marketTrend: 'alta' | 'estável' | 'crescente';
}

export interface Talent {
  name: string;
  description: string;
  example: string;
}

export interface Saboteur {
  pattern: string;
  howItAppears: string;
  fix: string;
}

export interface ActionPlanStep {
  week: string;
  title: string;
  tasks: string[];
}

export interface PlanetData {
  name: string;
  symbol: string;
  sign: string;
  degree: number;
  house?: number;
}

export interface AstroData {
  planets: PlanetData[];
  houses?: {
    house: number;
    sign: string;
    degree: number;
  }[];
  ascendantSign?: string;
  ascendantDegree?: number;
}

export interface ApiResponse {
  reportText: string;
  // Added coreInsight and primaryElement to match the API response schema and UI requirements
  coreInsight?: string;
  primaryElement?: string;
  professions?: Profession[];
  talents?: Talent[];
  saboteurs?: Saboteur[];
  plan?: ActionPlanStep[];
  astroData: AstroData;
}

export interface ReportState {
  loading: boolean;
  data?: ApiResponse;
  error?: string;
  paymentStatus: PaymentStatus;
}
