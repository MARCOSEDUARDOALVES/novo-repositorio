
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ShieldChart, SubAudit, GeomanticFigure, BinaryRow, ConsultationObjective } from './types';
import { generateShieldChart } from './geomancyUtils';
import { findFigureByRows } from './constants';
import ShieldChartDisplay from './components/ShieldChartDisplay';
import FigureDisplay from './components/FigureDisplay';
import MasterPresence from './components/MasterPresence';
import TtsButton from './components/TtsButton';
import AstrologyConsultation from './components/AstrologyConsultation';
import TarotConsultation from './components/TarotConsultation';
import KabbalahConsultation from './components/KabbalahConsultation';
import SupremeOracle from './components/SupremeOracle';
import IfaConsultation from './components/IfaConsultation';
import IstikharaConsultation from './components/IstikharaConsultation';
import DreamConsultation from './components/DreamConsultation';
import LandingPage from './components/LandingPage';
import { interpretReading, generatePersonaPortrait, interpretSubAudit } from './services/geminiService';
import { Sparkles, Compass, Target, LayoutGrid, ArrowLeft, Heart, Coins, Shell, Moon, Brain } from 'lucide-react';

const getRandomRow = (): BinaryRow => (Math.random() > 0.5 ? 2 : 1);
const getRandomFigure = (): GeomanticFigure => {
  const rows: [BinaryRow, BinaryRow, BinaryRow, BinaryRow] = [getRandomRow(), getRandomRow(), getRandomRow(), getRandomRow()];
  return findFigureByRows(rows);
};
const mergeFigures = (figA: GeomanticFigure, figB: GeomanticFigure): GeomanticFigure => {
  const addRows = (a: BinaryRow, b: BinaryRow): BinaryRow => (a + b) % 2 === 0 ? 2 : 1;
  const newRows: [BinaryRow, BinaryRow, BinaryRow, BinaryRow] = [
    addRows(figA.rows[0], figB.rows[0]),
    addRows(figA.rows[1], figB.rows[1]),
    addRows(figA.rows[2], figB.rows[2]),
    addRows(figA.rows[3], figB.rows[3]),
  ];
  return findFigureByRows(newRows);
};

const App: React.FC = () => {
  const [showLanding, setShowLanding] = useState(true);
  const [showObjective, setShowObjective] = useState(true);
  const [objective, setObjective] = useState<ConsultationObjective>('financial');
  const [activeTab, setActiveTab] = useState<'geomancy' | 'astrology' | 'tarot' | 'kabbalah' | 'supreme' | 'ifa' | 'istikhara' | 'dreams'>('geomancy');
  const [question, setQuestion] = useState('');
  const [subQuestion, setSubQuestion] = useState('');
  const [chart, setChart] = useState<ShieldChart | null>(null);
  const [subAudits, setSubAudits] = useState<SubAudit[]>([]);
  const [interpretation, setInterpretation] = useState<string>('');
  const [masterImage, setMasterImage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [paid, setPaid] = useState(false);
  const [subLoading, setSubLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [hasKey, setHasKey] = useState<boolean>(false);

  useEffect(() => {
    const checkKey = async () => {
      try {
        // @ts-ignore
        if (window.aistudio && typeof window.aistudio.hasSelectedApiKey === 'function') {
          // @ts-ignore
          const selected = await window.aistudio.hasSelectedApiKey();
          setHasKey(selected);
        }
      } catch (e) {
        console.warn("AI Studio key check failed:", e);
      }
    };
    checkKey();
  }, []);

  const handleSelectKey = async () => {
    try {
      // @ts-ignore
      await window.aistudio.openSelectKey();
      setHasKey(true);
      setError(null);
    } catch (e) {
      setError("Não foi possível abrir o seletor.");
    }
  };

  const updateMasterPresence = (img: string | null, text: string) => {
    setMasterImage(img);
    setInterpretation(text);
  };

  const handleCast = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!question.trim()) {
      setError("O Mestre exige uma pergunta clara.");
      return;
    }
    if (!hasKey) {
      setError("Selecione sua chave API paga.");
      return;
    }

    setLoading(true);
    setError(null);
    setInterpretation('');
    setSubAudits([]);
    
    try {
      const newChart = generateShieldChart();
      setChart(newChart);

      const [img, text] = await Promise.all([
        generatePersonaPortrait('geomancy', objective).catch(() => null),
        interpretReading(question, newChart, objective)
      ]);

      setMasterImage(img);
      setInterpretation(text);
    } catch (err: any) {
      setError("Erro na conexão com o oráculo.");
    } finally {
      setLoading(false);
    }
  };

  const handleSubCast = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!subQuestion.trim() || subLoading) return;

    setSubLoading(true);
    try {
      // Lógica Combo: Apenas 4 Mães gerando 1 Juiz Rápido
      const m1 = getRandomFigure();
      const m2 = getRandomFigure();
      const m3 = getRandomFigure();
      const m4 = getRandomFigure();
      const judge = mergeFigures(mergeFigures(m1, m2), mergeFigures(m3, m4));
      
      const subText = await interpretSubAudit(subQuestion, [m1, m2, m3, m4], judge, objective);
      
      const newSub: SubAudit = {
        question: subQuestion,
        mothers: [m1, m2, m3, m4],
        quickJudge: judge,
        interpretation: subText
      };

      setSubAudits([newSub, ...subAudits]);
      setSubQuestion('');
    } catch (err) {
      console.error(err);
    } finally {
      setSubLoading(false);
    }
  };

  const reset = () => {
    setQuestion('');
    setSubQuestion('');
    setChart(null);
    setSubAudits([]);
    setInterpretation('');
    setMasterImage(null);
    setPaid(false);
    setError(null);
  };

  const handleEnterOracle = (tab: 'geomancy' | 'astrology' | 'tarot' | 'kabbalah' | 'supreme' | 'ifa' | 'istikhara' | 'dreams') => {
    setActiveTab(tab);
    setShowLanding(false);
    setShowObjective(true);
  };

  const handleSelectObjective = (obj: ConsultationObjective) => {
    setObjective(obj);
    setShowObjective(false);
    reset();
  };

  return (
    <div className="min-h-screen py-12 px-6 flex flex-col items-center max-w-[1600px] mx-auto">
      <AnimatePresence>
        {showLanding && (
          <motion.div
            initial={{ opacity: 1 }}
            exit={{ opacity: 0, scale: 1.1, filter: 'blur(20px)' }}
            transition={{ duration: 1 }}
            className="fixed inset-0 z-[100]"
          >
            <LandingPage onEnter={handleEnterOracle} />
          </motion.div>
        )}
      </AnimatePresence>
      
      <header className="mb-12 text-center space-y-4 relative w-full">
        <div className="absolute left-0 top-1/2 -translate-y-1/2 flex flex-col gap-2">
          <button 
            onClick={() => setShowLanding(true)}
            className="flex items-center gap-2 text-amber-900 hover:text-amber-600 transition-colors font-cinzel text-[10px] tracking-widest uppercase"
          >
            <ArrowLeft size={14} /> Voltar ao Pórtico
          </button>
          {!showObjective && (
            <button 
              onClick={() => setShowObjective(true)}
              className="flex items-center gap-2 text-amber-700 hover:text-amber-500 transition-colors font-cinzel text-[10px] tracking-widest uppercase"
            >
              <ArrowLeft size={14} /> Mudar Objetivo
            </button>
          )}
        </div>
        <h1 className="text-4xl md:text-6xl font-cinzel font-bold gold-text-shimmer tracking-[-0.05em] uppercase">
          ORACULO DIVINATÓRIO
        </h1>
        <div className="flex items-center justify-center gap-4">
          <div className="h-px w-16 bg-amber-900/40"></div>
          <p className="text-amber-800 font-cinzel tracking-[0.8em] text-[10px] uppercase">Black Cape' — Desvende os Mistérios</p>
          <div className="h-px w-16 bg-amber-900/40"></div>
        </div>
      </header>

      {/* SELEÇÃO DE OBJETIVO */}
      <AnimatePresence>
        {showObjective && !showLanding && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.05, filter: 'blur(10px)' }}
            className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-black/90 backdrop-blur-xl"
          >
            <div className="max-w-4xl w-full space-y-12">
              <div className="text-center space-y-4">
                <h2 className="text-3xl md:text-5xl font-cinzel gold-text-shimmer uppercase tracking-widest">Qual o seu Propósito?</h2>
                <p className="text-amber-700/60 font-cinzel text-sm tracking-[0.3em] uppercase">Escolha a energia que guiará sua consulta</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => handleSelectObjective('relationship')}
                  className="glass-card p-12 rounded-[3rem] border-purple-500/20 hover:border-purple-500/50 transition-all text-center space-y-6 group"
                >
                  <div className="w-20 h-20 bg-purple-500/10 rounded-full flex items-center justify-center mx-auto border border-purple-500/20 group-hover:scale-110 transition-transform">
                    <Heart className="text-purple-500" size={32} />
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-2xl font-cinzel text-purple-100 uppercase tracking-widest">Relacionamento</h3>
                    <p className="text-purple-700/60 text-xs italic leading-relaxed">Respondido por Nuit: Mestra da sexualidade, da alma e da mentalidade feminina.</p>
                  </div>
                </motion.button>

                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => handleSelectObjective('financial')}
                  className="glass-card p-12 rounded-[3rem] border-amber-500/20 hover:border-amber-500/50 transition-all text-center space-y-6 group"
                >
                  <div className="w-20 h-20 bg-amber-500/10 rounded-full flex items-center justify-center mx-auto border border-amber-500/20 group-hover:scale-110 transition-transform">
                    <Coins className="text-amber-500" size={32} />
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-2xl font-cinzel text-amber-100 uppercase tracking-widest">Financeiro</h3>
                    <p className="text-amber-700/60 text-xs italic leading-relaxed">Respondido pelo Sr. Capa Preta: O espírito banqueiro, mestre da riqueza e do poder.</p>
                  </div>
                </motion.button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* GUIA DE CONFIGURAÇÃO (Aparece apenas se não houver chave) */}
      {!hasKey && (
        <div className="w-full max-w-4xl mb-12 animate-in fade-in zoom-in duration-700">
          <div className="glass-card p-6 rounded-2xl border-amber-500/40 bg-amber-500/5 flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-full bg-amber-500/20 flex items-center justify-center border border-amber-500/30">
                <Target className="text-amber-500" size={24} />
              </div>
              <div className="space-y-1">
                <h3 className="text-amber-100 font-cinzel text-sm tracking-widest">Acesso ao Oráculo Supremo</h3>
                <p className="text-amber-700/70 text-[10px] uppercase tracking-wider">Para ativar o motor Swiss Ephemeris e a visão do Mestre, configure sua chave API.</p>
              </div>
            </div>
            <button 
              onClick={handleSelectKey}
              className="whitespace-nowrap bg-amber-600 hover:bg-amber-500 text-black font-cinzel font-bold px-8 py-3 rounded-xl text-[10px] tracking-[0.2em] transition-all shadow-lg active:scale-95"
            >
              CONFIGURAR AGORA
            </button>
          </div>
        </div>
      )}

      {/* NAVEGAÇÃO ENTRE ORÁCULOS */}
      <div className="flex flex-wrap justify-center gap-2 md:gap-4 mb-16 p-2 bg-black/40 border border-amber-900/20 rounded-2xl w-full max-w-6xl">
        <button 
          onClick={() => setActiveTab('geomancy')}
          className={`flex items-center gap-2 md:gap-3 px-4 md:px-8 py-3 md:py-4 rounded-xl font-cinzel text-[10px] md:text-xs tracking-[0.1em] md:tracking-[0.2em] transition-all ${activeTab === 'geomancy' ? 'bg-amber-600 text-black font-bold shadow-lg' : 'text-amber-700 hover:text-amber-500'}`}
        >
          <Compass size={14} className="md:w-4 md:h-4" /> GEOMANCIA
        </button>
        <button 
          onClick={() => setActiveTab('astrology')}
          className={`flex items-center gap-2 md:gap-3 px-4 md:px-8 py-3 md:py-4 rounded-xl font-cinzel text-[10px] md:text-xs tracking-[0.1em] md:tracking-[0.2em] transition-all ${activeTab === 'astrology' ? 'bg-amber-600 text-black font-bold shadow-lg' : 'text-amber-700 hover:text-amber-500'}`}
        >
          <Sparkles size={14} className="md:w-4 md:h-4" /> ASTROLOGIA
        </button>
        <button 
          onClick={() => setActiveTab('tarot')}
          className={`flex items-center gap-2 md:gap-3 px-4 md:px-8 py-3 md:py-4 rounded-xl font-cinzel text-[10px] md:text-xs tracking-[0.1em] md:tracking-[0.2em] transition-all ${activeTab === 'tarot' ? 'bg-amber-600 text-black font-bold shadow-lg' : 'text-amber-700 hover:text-amber-500'}`}
        >
          <LayoutGrid size={14} className="md:w-4 md:h-4" /> TARÔ
        </button>
        <button 
          onClick={() => setActiveTab('kabbalah')}
          className={`flex items-center gap-2 md:gap-3 px-4 md:px-8 py-3 md:py-4 rounded-xl font-cinzel text-[10px] md:text-xs tracking-[0.1em] md:tracking-[0.2em] transition-all ${activeTab === 'kabbalah' ? 'bg-amber-600 text-black font-bold shadow-lg' : 'text-amber-700 hover:text-amber-500'}`}
        >
          <Sparkles size={14} className="md:w-4 md:h-4" /> CABALA
        </button>
        <button 
          onClick={() => setActiveTab('supreme')}
          className={`flex items-center gap-2 md:gap-3 px-4 md:px-8 py-3 md:py-4 rounded-xl font-cinzel text-[10px] md:text-xs tracking-[0.1em] md:tracking-[0.2em] transition-all ${activeTab === 'supreme' ? 'bg-amber-600 text-black font-bold shadow-lg' : 'text-amber-700 hover:text-amber-500'}`}
        >
          <Sparkles size={14} className="md:w-4 md:h-4" /> SUPREMO
        </button>
        <button 
          onClick={() => setActiveTab('ifa')}
          className={`flex items-center gap-2 md:gap-3 px-4 md:px-8 py-3 md:py-4 rounded-xl font-cinzel text-[10px] md:text-xs tracking-[0.1em] md:tracking-[0.2em] transition-all ${activeTab === 'ifa' ? 'bg-amber-600 text-black font-bold shadow-lg' : 'text-amber-700 hover:text-amber-500'}`}
        >
          <Shell size={14} className="md:w-4 md:h-4" /> IFÁ
        </button>
        <button 
          onClick={() => setActiveTab('istikhara')}
          className={`flex items-center gap-2 md:gap-3 px-4 md:px-8 py-3 md:py-4 rounded-xl font-cinzel text-[10px] md:text-xs tracking-[0.1em] md:tracking-[0.2em] transition-all ${activeTab === 'istikhara' ? 'bg-amber-600 text-black font-bold shadow-lg' : 'text-amber-700 hover:text-amber-500'}`}
        >
          <Moon size={14} className="md:w-4 md:h-4" /> ISTIKHARA
        </button>
        <button 
          onClick={() => setActiveTab('dreams')}
          className={`flex items-center gap-2 md:gap-3 px-4 md:px-8 py-3 md:py-4 rounded-xl font-cinzel text-[10px] md:text-xs tracking-[0.1em] md:tracking-[0.2em] transition-all ${activeTab === 'dreams' ? 'bg-indigo-600 text-white font-bold shadow-lg shadow-indigo-900/40' : 'text-indigo-400/60 hover:text-indigo-400'}`}
        >
          <Brain size={14} className="md:w-4 md:h-4" /> INTERPRETADOR DE SONHOS
        </button>
      </div>

      {activeTab === 'geomancy' ? (
        <div className="w-full max-w-7xl mx-auto grid grid-cols-1 xl:grid-cols-12 gap-16 items-center justify-center">
          
          {/* LADO DO MESTRE */}
          <div className="xl:col-span-4 flex flex-col gap-10 items-center">
            <MasterPresence 
              image={masterImage} 
              status={loading ? 'thinking' : (chart ? 'result' : 'idle')} 
              objective={objective}
            />

            {!chart && !loading && (
              <div className="glass-card p-10 rounded-3xl animate-in fade-in slide-in-from-bottom duration-1000">
                <form onSubmit={handleCast} className="space-y-8">
                  {!hasKey && (
                    <button type="button" onClick={handleSelectKey} className="w-full border border-amber-500/30 text-amber-500 font-cinzel text-xs py-3 px-4 rounded-lg hover:bg-amber-500/10 transition-all">
                      CONFIGURAR ACESSO (CHAVE API)
                    </button>
                  )}
                  <div className="space-y-4">
                    <label className="block text-amber-700 font-cinzel text-[10px] tracking-widest uppercase text-center">Manifeste seu Questionamento Principal</label>
                    <p className="text-amber-900/40 text-[9px] uppercase tracking-widest text-center italic">Orientação: Para uma resposta clara, faça uma pergunta objetiva.</p>
                    <textarea
                      value={question}
                      onChange={(e) => setQuestion(e.target.value)}
                      className="w-full bg-black/40 border border-amber-900/20 rounded-2xl p-6 text-amber-100/80 focus:outline-none focus:border-amber-500/40 transition-all resize-none h-44 font-light text-lg italic text-center placeholder:text-amber-900/30"
                      placeholder="O que deseja auditar hoje?"
                    />
                  </div>
                  {error && <p className="text-red-600 text-[10px] text-center font-bold tracking-widest uppercase">{error}</p>}
                  <button type="submit" disabled={loading} className="w-full bg-gradient-to-b from-amber-600 to-amber-900 text-black font-cinzel font-bold py-5 rounded-2xl tracking-[0.3em] transition-all transform hover:scale-[1.02] shadow-2xl active:scale-95 disabled:opacity-30">
                    ABRIR AUDITORIA
                  </button>
                </form>
              </div>
            )}

            {chart && !loading && (
              <button onClick={reset} className="text-amber-900 hover:text-amber-600 text-[10px] uppercase tracking-[0.5em] transition-all font-cinzel mx-auto border-b border-transparent hover:border-amber-600 pb-1">
                — Encerrar Consultoria —
              </button>
            )}
          </div>

          {/* LADO DO RESULTADO */}
          <div className="xl:col-span-8 space-y-16">
            {chart ? (
              <>
                <div className="glass-card p-12 rounded-[4rem] relative overflow-hidden">
                  <ShieldChartDisplay chart={chart} />
                </div>

                {interpretation && (
                  <div className="relative">
                    <TtsButton 
                      text={interpretation} 
                      voice="Puck" 
                      className="absolute top-8 right-8 z-20 shadow-lg bg-black/40 border-amber-500/30" 
                    />
                    <div className="glass-card p-16 md:p-24 rounded-[5rem] relative">
                      <div className="prose prose-invert max-w-none">
                        <div className="whitespace-pre-wrap leading-[2.2] text-amber-100/80 text-2xl font-light italic tracking-tight text-center">
                          {/* Show first paragraph as preview, blur the rest */}
                          <div>
                            {interpretation.split('\n\n')[0]}
                          </div>
                          <div className={`transition-all duration-1000 ${!paid ? 'blur-lg select-none pointer-events-none opacity-40' : ''}`}>
                            {interpretation.split('\n\n').slice(1).join('\n\n')}
                          </div>
                        </div>
                      </div>
                    </div>

                    {!paid && (
                      <div className="absolute inset-x-0 bottom-0 z-10 flex items-center justify-center p-12 bg-gradient-to-t from-black via-black/80 to-transparent pt-32 rounded-b-[5rem]">
                        <motion.div 
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="glass-card p-12 rounded-[3rem] border-amber-500/40 bg-black/80 backdrop-blur-md text-center space-y-8 max-w-md shadow-2xl"
                        >
                          <div className="w-20 h-20 bg-amber-500/10 rounded-full flex items-center justify-center mx-auto border border-amber-500/20">
                            <Coins className="text-amber-500" size={32} />
                          </div>
                          <div className="space-y-2">
                            <h3 className="text-2xl font-cinzel text-amber-100 uppercase tracking-widest">Revelar Auditoria Completa</h3>
                            <p className="text-amber-700/60 text-xs italic">O conhecimento do Mestre exige uma oferenda para o equilíbrio das energias.</p>
                          </div>
                          <div className="text-4xl font-cinzel gold-text-shimmer">R$ 19,99</div>
                          <div className="space-y-4">
                            <button
                              onClick={() => setPaid(true)}
                              className="w-full bg-amber-600 text-black font-cinzel font-bold py-4 rounded-xl tracking-widest hover:bg-amber-500 transition-all shadow-lg active:scale-95"
                            >
                              PAGAR COM PIX OU CARTÃO
                            </button>
                            <p className="text-amber-900/40 text-[8px] uppercase tracking-widest">Pagamento seguro via Pix ou Cartão de Crédito</p>
                          </div>
                        </motion.div>
                      </div>
                    )}
                  </div>
                )}

                {/* SEÇÃO COMBO / SUB-PERGUNTAS */}
                <div className="space-y-10">
                  <div className="flex items-center gap-6">
                    <div className="h-px flex-grow bg-amber-900/20"></div>
                    <h2 className="font-cinzel text-amber-600 text-sm tracking-[0.4em] uppercase">Combo: Auditoria de Detalhes</h2>
                    <div className="h-px flex-grow bg-amber-900/20"></div>
                  </div>

                  <form onSubmit={handleSubCast} className="flex gap-4">
                    <input 
                      type="text" 
                      value={subQuestion}
                      onChange={(e) => setSubQuestion(e.target.value)}
                      placeholder="Aprofunde um ponto específico..."
                      className="flex-grow bg-neutral-900/50 border border-amber-900/20 rounded-xl px-6 py-4 text-amber-100 focus:outline-none focus:border-amber-500/50 italic"
                    />
                    <button 
                      disabled={subLoading}
                      className="bg-amber-700 hover:bg-amber-600 text-black px-8 py-4 rounded-xl font-cinzel font-bold tracking-widest text-xs transition-all disabled:opacity-30"
                    >
                      {subLoading ? '...' : 'DETALHAR'}
                    </button>
                  </form>

                  <div className="space-y-8">
                    {subAudits.map((sub, i) => (
                      <div key={i} className="glass-card p-10 rounded-3xl border-l-4 border-amber-600/50 animate-in slide-in-from-left duration-500">
                        <p className="text-amber-700 font-cinzel text-[10px] tracking-widest uppercase mb-4">Adendo: {sub.question}</p>
                        
                        <div className="flex flex-wrap items-center gap-4 mb-6 opacity-80">
                           {sub.mothers.map((m, mi) => (
                             <FigureDisplay key={mi} figure={m} size="sm" label={`Sinal ${mi+1}`} />
                           ))}
                           <div className="w-8 h-px bg-amber-900/40"></div>
                           <FigureDisplay figure={sub.quickJudge} size="md" label="Veredito" />
                        </div>

                        <div className="text-amber-100/70 italic text-lg leading-relaxed border-t border-amber-900/10 pt-6">
                          {sub.interpretation}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            ) : (
              !loading && (
                <div className="h-full flex items-center justify-center py-40 opacity-10">
                  <div className="text-center space-y-12">
                     <div className="text-8xl text-amber-900 font-cinzel">⚜</div>
                     <p className="font-cinzel text-amber-900 tracking-[1em] text-sm uppercase">Câmara de Transações Ocultas</p>
                  </div>
                </div>
              )
            )}

            {loading && (
              <div className="h-full flex flex-col items-center justify-center py-40 space-y-12">
                 <div className="relative w-32 h-32">
                    <div className="absolute inset-0 border-t-2 border-amber-500 rounded-full animate-spin"></div>
                 </div>
                 <p className="font-cinzel text-amber-700 tracking-[0.5em] text-xs italic animate-pulse uppercase">Avaliando Ativos Espirituais...</p>
              </div>
            )}
          </div>
        </div>
      ) : activeTab === 'astrology' ? (
        <AstrologyConsultation hasKey={hasKey} onSelectKey={handleSelectKey} objective={objective} onResult={updateMasterPresence} />
      ) : activeTab === 'tarot' ? (
        <TarotConsultation hasKey={hasKey} onSelectKey={handleSelectKey} objective={objective} onResult={updateMasterPresence} />
      ) : activeTab === 'kabbalah' ? (
        <KabbalahConsultation hasKey={hasKey} onSelectKey={handleSelectKey} objective={objective} onResult={updateMasterPresence} />
      ) : activeTab === 'supreme' ? (
        <SupremeOracle hasKey={hasKey} onSelectKey={handleSelectKey} objective={objective} onResult={updateMasterPresence} />
      ) : activeTab === 'ifa' ? (
        <IfaConsultation hasKey={hasKey} onSelectKey={handleSelectKey} objective={objective} onResult={updateMasterPresence} />
      ) : activeTab === 'istikhara' ? (
        <IstikharaConsultation hasKey={hasKey} onSelectKey={handleSelectKey} objective={objective} onResult={updateMasterPresence} />
      ) : (
        <DreamConsultation hasKey={hasKey} onSelectKey={handleSelectKey} objective={objective} onResult={(img, text) => {
          setMasterImage(img);
          setInterpretation(text);
          // Auto-scroll logic happens inside the component
        }} />
      )}
    </div>
  );
};

export default App;
