import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Calendar, Clock, MapPin, Star, Briefcase, Target, CreditCard, Loader2, Sparkles, Sun, Moon, ArrowUpCircle, ChevronRight } from 'lucide-react';
import { interpretAstrology, generateAstrologyPreview, generatePersonaPortrait } from '../services/geminiService';
import TtsButton from './TtsButton';
import ReactMarkdown from 'react-markdown';
import { ConsultationObjective } from '../types';

interface AstrologyConsultationProps {
  hasKey: boolean;
  onSelectKey: () => void;
  objective: ConsultationObjective;
  onResult: (image: string | null, text: string) => void;
}

interface PreviewData {
  title: string;
  sun: string;
  moon: string;
  ascendant: string;
  hook: string;
}


const AstrologyConsultation: React.FC<AstrologyConsultationProps> = ({ hasKey, onSelectKey, objective, onResult }) => {
  const isRelationship = objective === 'relationship';
  const personaName = 'Professor Jupiter';
  const personaTitle = 'Mestre das Estrelas';

  const [birthData, setBirthData] = useState({
    date: '',
    time: '',
    location: ''
  });
  const [partnerData, setPartnerData] = useState({
    date: '',
    time: '',
    location: ''
  });
  const [step, setStep] = useState<'form' | 'preview' | 'analyzing' | 'result'>('form');
  const [previewData, setPreviewData] = useState<PreviewData | null>(null);
  const [report, setReport] = useState<string>('');
  const [paid, setPaid] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleStartAnalysis = async () => {
    if (!birthData.date || !birthData.time || !birthData.location) {
      setError("Preencha todos os seus dados natais para a auditoria.");
      return;
    }
    if (isRelationship && (!partnerData.date || !partnerData.time || !partnerData.location)) {
      setError("Preencha todos os dados natais do parceiro(a) para a sinastria.");
      return;
    }
    if (!hasKey) {
      setError("Configure sua chave API para acessar o motor Swiss Ephemeris.");
      return;
    }
    
    setLoading(true);
    setError(null);
    try {
      const preview = await generateAstrologyPreview(birthData, objective, isRelationship ? partnerData : undefined);
      setPreviewData(preview);
      setStep('preview');
    } catch (err) {
      setError("Erro ao gerar prévia. Verifique sua conexão.");
    } finally {
      setLoading(false);
    }
  };

  const handleGoToPayment = () => {
    handleGenerate();
  };

  const handleGenerate = () => {
    setLoading(true);
    setStep('analyzing');
    
    // Simular processamento de ML e Swiss Ephemeris Engine
    setTimeout(async () => {
      try {
        const [img, result] = await Promise.all([
          generatePersonaPortrait('astrology', objective).catch(() => null),
          interpretAstrology(birthData, objective, isRelationship ? partnerData : undefined)
        ]);
        setReport(result);
        onResult(img, result);
        setStep('result');
      } catch (err) {
        setError("Erro na conexão com o servidor Swiss Ephemeris.");
        setStep('form');
      } finally {
        setLoading(false);
      }
    }, 3000);
  };

  return (
    <div className="w-full max-w-4xl mx-auto">
      <AnimatePresence mode="wait">
        {step === 'form' && (
          <motion.div
            key="form"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="glass-card p-8 md:p-12 rounded-[3rem] space-y-8"
          >
            <div className="text-center space-y-2">
              <h2 className="text-3xl font-cinzel gold-text-shimmer uppercase tracking-widest">Auditoria Astrológica Natal</h2>
              <p className="text-amber-700/60 font-light italic">Mapeamento de {isRelationship ? 'Relacionamento e Alma' : 'Propósito e Carreira'} via Swiss Ephemeris & ML</p>
              <p className="text-amber-900/40 text-[9px] uppercase tracking-widest text-center italic mt-2">Orientação: Para uma análise precisa, forneça dados objetivos.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Pessoa 1 */}
              <div className="space-y-6">
                <div className="text-amber-500/60 text-[10px] uppercase tracking-[0.3em] font-bold border-b border-amber-900/20 pb-2">
                  {isRelationship ? 'Seus Dados Natais' : 'Dados Natais'}
                </div>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <label className="flex items-center gap-2 text-amber-600 text-[10px] uppercase tracking-widest">
                      <Calendar size={14} /> Data de Nascimento
                    </label>
                    <input
                      type="date"
                      value={birthData.date}
                      onChange={(e) => setBirthData({ ...birthData, date: e.target.value })}
                      className="w-full bg-black/40 border border-amber-900/20 rounded-xl p-4 text-amber-100 focus:outline-none focus:border-amber-500/40 transition-all"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="flex items-center gap-2 text-amber-600 text-[10px] uppercase tracking-widest">
                      <Clock size={14} /> Horário Exato
                    </label>
                    <input
                      type="time"
                      value={birthData.time}
                      onChange={(e) => setBirthData({ ...birthData, time: e.target.value })}
                      className="w-full bg-black/40 border border-amber-900/20 rounded-xl p-4 text-amber-100 focus:outline-none focus:border-amber-500/40 transition-all"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="flex items-center gap-2 text-amber-600 text-[10px] uppercase tracking-widest">
                      <MapPin size={14} /> Local de Nascimento
                    </label>
                    <input
                      type="text"
                      placeholder="Ex: São Paulo, SP"
                      value={birthData.location}
                      onChange={(e) => setBirthData({ ...birthData, location: e.target.value })}
                      className="w-full bg-black/40 border border-amber-900/20 rounded-xl p-4 text-amber-100 focus:outline-none focus:border-amber-500/40 transition-all"
                    />
                  </div>
                </div>
              </div>

              {/* Pessoa 2 (Sinastria) */}
              {isRelationship && (
                <div className="space-y-6">
                  <div className="text-amber-500/60 text-[10px] uppercase tracking-[0.3em] font-bold border-b border-amber-900/20 pb-2">
                    Dados Natais do Parceiro(a)
                  </div>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <label className="flex items-center gap-2 text-amber-600 text-[10px] uppercase tracking-widest">
                        <Calendar size={14} /> Data de Nascimento
                      </label>
                      <input
                        type="date"
                        value={partnerData.date}
                        onChange={(e) => setPartnerData({ ...partnerData, date: e.target.value })}
                        className="w-full bg-black/40 border border-amber-900/20 rounded-xl p-4 text-amber-100 focus:outline-none focus:border-amber-500/40 transition-all"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="flex items-center gap-2 text-amber-600 text-[10px] uppercase tracking-widest">
                        <Clock size={14} /> Horário Exato
                      </label>
                      <input
                        type="time"
                        value={partnerData.time}
                        onChange={(e) => setPartnerData({ ...partnerData, time: e.target.value })}
                        className="w-full bg-black/40 border border-amber-900/20 rounded-xl p-4 text-amber-100 focus:outline-none focus:border-amber-500/40 transition-all"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="flex items-center gap-2 text-amber-600 text-[10px] uppercase tracking-widest">
                        <MapPin size={14} /> Local de Nascimento
                      </label>
                      <input
                        type="text"
                        placeholder="Ex: Rio de Janeiro, RJ"
                        value={partnerData.location}
                        onChange={(e) => setPartnerData({ ...partnerData, location: e.target.value })}
                        className="w-full bg-black/40 border border-amber-900/20 rounded-xl p-4 text-amber-100 focus:outline-none focus:border-amber-500/40 transition-all"
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>

            {error && <p className="text-red-500 text-[10px] text-center uppercase tracking-widest font-bold">{error}</p>}

            {!hasKey && (
              <button onClick={onSelectKey} className="w-full bg-amber-600/10 border border-amber-500/40 text-amber-500 font-cinzel text-xs py-3 rounded-lg hover:bg-amber-500/20 transition-all">
                CONFIGURAR ACESSO (CHAVE API)
              </button>
            )}

            <button
              onClick={handleStartAnalysis}
              disabled={loading}
              className="w-full bg-gradient-to-r from-amber-700 to-amber-900 text-black font-cinzel font-bold py-5 rounded-2xl tracking-[0.3em] hover:scale-[1.02] transition-all shadow-xl active:scale-95 disabled:opacity-50"
            >
              {loading ? <Loader2 className="mx-auto animate-spin" /> : "GERAR MAPA PRELIMINAR"}
            </button>
          </motion.div>
        )}

        {step === 'preview' && previewData && (
          <motion.div
            key="preview"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="glass-card p-8 md:p-12 rounded-[3rem] space-y-10 border-amber-500/30"
          >
            <div className="text-center space-y-4">
              <div className="inline-block px-4 py-1 bg-amber-500/10 border border-amber-500/20 rounded-full text-[10px] text-amber-500 font-bold tracking-[0.3em] uppercase">
                Assinatura Vibracional Detectada
              </div>
              <h2 className="text-4xl md:text-5xl font-cinzel gold-text-shimmer uppercase tracking-tight leading-none">
                {previewData.title}
              </h2>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div className="bg-black/40 border border-amber-900/20 rounded-2xl p-4 text-center space-y-2">
                <Sun className="mx-auto text-amber-500/60" size={20} />
                <p className="text-[10px] text-amber-700 uppercase tracking-widest">Sol</p>
                <p className="text-amber-100 font-cinzel text-sm">{previewData.sun}</p>
              </div>
              <div className="bg-black/40 border border-amber-900/20 rounded-2xl p-4 text-center space-y-2">
                <Moon className="mx-auto text-amber-500/60" size={20} />
                <p className="text-[10px] text-amber-700 uppercase tracking-widest">Lua</p>
                <p className="text-amber-100 font-cinzel text-sm">{previewData.moon}</p>
              </div>
              <div className="bg-black/40 border border-amber-900/20 rounded-2xl p-4 text-center space-y-2">
                <ArrowUpCircle className="mx-auto text-amber-500/60" size={20} />
                <p className="text-[10px] text-amber-700 uppercase tracking-widest">Asc</p>
                <p className="text-amber-100 font-cinzel text-sm">{previewData.ascendant}</p>
              </div>
            </div>

            <div className="bg-amber-500/5 border-l-2 border-amber-500/40 p-6 rounded-r-2xl">
              <p className="text-amber-100/90 italic text-lg leading-relaxed">
                "{previewData.hook}"
              </p>
            </div>

            <div className="space-y-4">
              <p className="text-center text-amber-700/60 text-xs uppercase tracking-widest">
                A auditoria completa revelará sua rota de poder exata.
              </p>
              <button
                onClick={handleGoToPayment}
                className="w-full bg-amber-600 text-black font-cinzel font-bold py-5 rounded-2xl tracking-[0.2em] flex items-center justify-center gap-3 hover:bg-amber-500 transition-all shadow-2xl group"
              >
                DESBLOQUEAR AUDITORIA COMPLETA (ML)
                <ChevronRight className="group-hover:translate-x-1 transition-transform" />
              </button>
              <button onClick={() => setStep('form')} className="block mx-auto text-amber-900 text-[10px] uppercase tracking-widest hover:text-amber-700 transition-colors">
                Corrigir Dados Natais
              </button>
            </div>
          </motion.div>
        )}

        {step === 'analyzing' && (
          <motion.div
            key="analyzing"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex flex-col items-center justify-center space-y-12 py-20"
          >
            <div className="relative">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
                className="w-40 h-40 border-2 border-dashed border-amber-500/30 rounded-full"
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <Loader2 className="text-amber-500 animate-spin" size={48} />
              </div>
            </div>
            <div className="text-center space-y-4">
              <h3 className="text-2xl font-cinzel gold-text-shimmer animate-pulse uppercase">Auditoria de Professor Jupiter...</h3>
              <p className="text-amber-700/60 text-xs tracking-[0.2em] uppercase italic">"As estrelas não mentem, elas apenas se revelam"</p>
            </div>
          </motion.div>
        )}

        {step === 'result' && (
          <motion.div
            key="result"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-8"
          >
            <div className="relative">
              <div className="glass-card p-8 md:p-12 rounded-[3rem] relative overflow-hidden">
                {!paid ? null : (
                  <TtsButton 
                    text={report} 
                    voice="Zephyr" 
                    className="absolute top-6 right-6 z-20" 
                  />
                )}
                <div className="absolute top-0 right-0 p-8 opacity-10">
                  <Sparkles size={120} className="text-amber-500" />
                </div>
                
                <div className="prose prose-invert prose-amber max-w-none">
                  <div className="markdown-body">
                    {/* Show first paragraph as preview, blur the rest */}
                    <div className="mb-4">
                      <ReactMarkdown>{report.split('\n\n')[0]}</ReactMarkdown>
                    </div>
                    <div className={`transition-all duration-1000 ${!paid ? 'blur-lg select-none pointer-events-none opacity-40' : ''}`}>
                      <ReactMarkdown>{report.split('\n\n').slice(1).join('\n\n')}</ReactMarkdown>
                    </div>
                  </div>
                </div>

                <div className="mt-12 pt-8 border-t border-amber-900/20 flex flex-wrap gap-4 justify-center">
                  <div className="flex items-center gap-2 px-4 py-2 bg-amber-500/5 rounded-full border border-amber-500/10">
                    <Star size={14} className="text-amber-500" />
                    <span className="text-[10px] text-amber-600 uppercase tracking-widest font-bold">Acurácia ML: 99.1%</span>
                  </div>
                  <div className="flex items-center gap-2 px-4 py-2 bg-amber-500/5 rounded-full border border-amber-500/10">
                    <Briefcase size={14} className="text-amber-500" />
                    <span className="text-[10px] text-amber-600 uppercase tracking-widest font-bold">Foco: Carreira & Propósito</span>
                  </div>
                  <div className="flex items-center gap-2 px-4 py-2 bg-amber-500/5 rounded-full border border-amber-500/10">
                    <Target size={14} className="text-amber-500" />
                    <span className="text-[10px] text-amber-600 uppercase tracking-widest font-bold">Motor: Swiss Ephemeris v2.10</span>
                  </div>
                </div>
              </div>

              {!paid && (
                <div className="absolute inset-x-0 bottom-0 z-10 flex items-center justify-center p-12 bg-gradient-to-t from-black via-black/80 to-transparent pt-32 rounded-b-[3rem]">
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="glass-card p-12 rounded-[3rem] border-amber-500/40 bg-black/80 backdrop-blur-md text-center space-y-8 max-w-md shadow-2xl"
                  >
                    <div className="w-20 h-20 bg-amber-500/10 rounded-full flex items-center justify-center mx-auto border border-amber-500/20">
                      <CreditCard className="text-amber-500" size={32} />
                    </div>
                    <div className="space-y-2">
                      <h3 className="text-2xl font-cinzel text-amber-100 uppercase tracking-widest">Revelar Auditoria</h3>
                      <p className="text-amber-700/60 text-xs italic">O processamento de ML em milhares de mapas requer créditos de alta performance.</p>
                    </div>
                    <div className="text-4xl font-cinzel gold-text-shimmer">R$ 19,99</div>
                    <div className="space-y-4">
                      <button
                        onClick={() => setPaid(true)}
                        className="w-full bg-amber-600 text-black font-cinzel font-bold py-4 rounded-xl tracking-widest hover:bg-amber-500 transition-all shadow-lg active:scale-95"
                      >
                        PAGAR COM PIX OU CARTÃO
                      </button>
                      <p className="text-amber-900/40 text-[8px] uppercase tracking-widest">Pagamento seguro via Pix ou Cartão de Crédito</p>
                    </div>
                  </motion.div>
                </div>
              )}
            </div>

            <button
              onClick={() => {
                setStep('form');
                setPaid(false);
              }}
              className="block mx-auto text-amber-900 hover:text-amber-600 text-[10px] uppercase tracking-[0.5em] transition-all font-cinzel border-b border-transparent hover:border-amber-600 pb-1"
            >
              — Nova Auditoria Natal —
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default AstrologyConsultation;
