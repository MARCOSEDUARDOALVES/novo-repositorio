import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Sun, Moon, Sparkles, Loader2 } from 'lucide-react';
import { getDailyTransits } from '../services/geminiService';

interface Transits {
  sunSign: string;
  moonSign: string;
  moonPhase: string;
  highlight: string;
  advice: string;
}

const DailySky: React.FC = () => {
  const [transits, setTransits] = useState<Transits | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchTransits = async () => {
      try {
        const data = await getDailyTransits();
        setTransits(data);
      } catch (error) {
        console.error("Failed to fetch transits", error);
      } finally {
        setLoading(false);
      }
    };
    fetchTransits();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-24">
        <Loader2 className="text-amber-500/40 animate-spin" size={20} />
      </div>
    );
  }

  if (!transits) return null;

  return (
    <motion.div 
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      className="w-full max-w-3xl mx-auto mb-12"
    >
      <div className="glass-card p-6 md:p-8 rounded-[2.5rem] border-amber-500/30 bg-white/[0.03] backdrop-blur-xl relative overflow-hidden group shadow-[0_0_50px_rgba(245,158,11,0.05)] hover:shadow-[0_0_70px_rgba(245,158,11,0.1)] transition-shadow">
        <div className="absolute top-0 right-0 p-6 opacity-10 group-hover:opacity-20 transition-opacity">
          <Sparkles size={48} className="text-amber-500" />
        </div>
        
        {/* Glow Effects */}
        <div className="absolute top-0 left-1/4 w-32 h-32 bg-amber-500/10 blur-[60px] rounded-full pointer-events-none"></div>
        <div className="absolute bottom-0 right-1/4 w-32 h-32 bg-blue-500/10 blur-[60px] rounded-full pointer-events-none"></div>
        <div className="flex flex-col md:flex-row items-center gap-8 md:gap-16">
          {/* Sol e Lua */}
          <div className="flex gap-12">
            <div className="text-center space-y-3">
              <div className="w-14 h-14 rounded-full bg-amber-500/10 flex items-center justify-center mx-auto border border-amber-500/30 shadow-[0_0_20px_rgba(245,158,11,0.1)]">
                <Sun className="text-amber-500" size={24} />
              </div>
              <div>
                <p className="text-[10px] text-amber-500/60 uppercase tracking-[0.2em] font-bold">Sol em</p>
                <p className="text-amber-100 font-cinzel text-base tracking-widest">{transits.sunSign}</p>
              </div>
            </div>
            
            <div className="text-center space-y-3">
              <div className="w-14 h-14 rounded-full bg-blue-500/10 flex items-center justify-center mx-auto border border-blue-500/20 shadow-[0_0_20px_rgba(59,130,246,0.1)]">
                <Moon className="text-blue-200" size={24} />
              </div>
              <div>
                <p className="text-[10px] text-blue-400/60 uppercase tracking-[0.2em] font-bold">Lua {transits.moonPhase}</p>
                <p className="text-amber-100 font-cinzel text-base tracking-widest">{transits.moonSign}</p>
              </div>
            </div>
          </div>

          {/* Destaque e Conselho */}
          <div className="flex-1 space-y-3 text-center md:text-left border-t md:border-t-0 md:border-l border-amber-900/20 pt-6 md:pt-0 md:pl-12">
            <div className="inline-block px-3 py-1 bg-amber-500/10 rounded-full text-[9px] text-amber-500 font-bold tracking-widest uppercase mb-2">
              Insight do Dia
            </div>
            <p className="text-amber-100/90 text-sm md:text-base italic leading-relaxed font-light">
              "{transits.highlight}"
            </p>
            <div className="h-px w-12 bg-amber-900/40 my-2 mx-auto md:mx-0"></div>
            <p className="text-amber-700/80 text-[10px] uppercase tracking-[0.2em] leading-relaxed font-bold">
              Conselho: <span className="text-amber-600/60 font-normal">{transits.advice}</span>
            </p>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default DailySky;
