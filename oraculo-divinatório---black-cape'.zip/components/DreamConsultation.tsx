import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, Loader2, CreditCard, Send, Brain, MessageSquare, ChevronRight } from 'lucide-react';
import { interpretDream, dreamChat, generatePersonaPortrait } from '../services/geminiService';
import TtsButton from './TtsButton';
import { ConsultationObjective } from '../types';
import ReactMarkdown from 'react-markdown';

interface Message {
  role: 'user' | 'model';
  content: string;
}

interface DreamConsultationProps {
  hasKey: boolean;
  onSelectKey: () => void;
  objective: ConsultationObjective;
  onResult: (image: string | null, text: string) => void;
}

const DreamConsultation: React.FC<DreamConsultationProps> = ({ hasKey, onSelectKey, objective, onResult }) => {
  const [dream, setDream] = useState('');
  const [chatInput, setChatInput] = useState('');
  const [step, setStep] = useState<'form' | 'analyzing' | 'result'>('form');
  const [messages, setMessages] = useState<Message[]>([]);
  const [isChatting, setIsChatting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isBlurred, setIsBlurred] = useState(true);

  const chatEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleInterpret = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!dream.trim()) return;

    setStep('analyzing');
    setError(null);
    
    try {
      const [img, result] = await Promise.all([
        generatePersonaPortrait('dreams', objective).catch(() => null),
        interpretDream(dream, objective)
      ]);
      
      setMessages([{ role: 'model', content: result }]);
      onResult(img, result);
      setStep('result');
    } catch (err) {
      setError("O labirinto do inconsciente fechou seus portões. Tente novamente.");
      setStep('form');
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || isChatting) return;

    const userMessage = chatInput;
    setChatInput('');
    const newMessages: Message[] = [...messages, { role: 'user', content: userMessage }];
    setMessages(newMessages);
    setIsChatting(true);

    try {
      const response = await dreamChat(newMessages, objective);
      setMessages([...newMessages, { role: 'model', content: response }]);
    } catch (err) {
      setError("A transferência psicanalítica falhou.");
    } finally {
      setIsChatting(false);
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto p-4 md:p-8">
      <AnimatePresence mode="wait">
        {step === 'form' && (
          <motion.div
            key="form"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="bg-slate-950/80 backdrop-blur-xl border border-indigo-500/20 rounded-3xl p-6 md:p-10 shadow-2xl space-y-8"
          >
            <div className="text-center space-y-2">
              <div className="flex justify-center mb-4">
                <div className="p-3 bg-indigo-500/10 rounded-2xl border border-indigo-500/20">
                  <Brain className="text-indigo-400" size={32} />
                </div>
              </div>
              <h2 className="text-3xl font-cinzel text-indigo-100 uppercase tracking-widest">Interpretador de Sonhos</h2>
              <p className="text-indigo-400/60 font-light italic">Pela sabedoria de Jung, Freud e Artemidoro</p>
            </div>

            <form onSubmit={handleInterpret} className="space-y-6">
              <div className="space-y-4">
                <label className="block font-cinzel text-[10px] text-indigo-400 tracking-[0.2em] uppercase">
                  Relate seu sonho ou estado psíquico:
                </label>
                <textarea
                  value={dream}
                  onChange={(e) => setDream(e.target.value)}
                  className="w-full bg-slate-900/50 border border-indigo-500/10 rounded-2xl p-6 text-indigo-100 placeholder:text-indigo-900/40 focus:outline-none focus:border-indigo-500/30 transition-all min-h-[200px] resize-none text-sm leading-relaxed"
                  placeholder="Descreva as imagens, sensações e símbolos que surgiram em seu sono..."
                />
              </div>

              <button
                disabled={!dream.trim()}
                type="submit"
                className="w-full h-16 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-30 disabled:cursor-not-allowed text-white font-cinzel tracking-[0.3em] rounded-2xl transition-all shadow-lg shadow-indigo-900/20 flex items-center justify-center gap-3 uppercase text-xs"
              >
                <Sparkles size={20} />
                Iniciar Análise
              </button>
            </form>
          </motion.div>
        )}

        {step === 'analyzing' && (
          <motion.div
            key="analyzing"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex flex-col items-center justify-center min-h-[400px] space-y-8"
          >
            <div className="relative">
              <div className="absolute inset-0 bg-indigo-500/20 blur-3xl rounded-full" />
              <Loader2 className="animate-spin text-indigo-500 relative" size={64} strokeWidth={1} />
            </div>
            <div className="text-center space-y-4">
              <h3 className="text-2xl font-cinzel text-indigo-200 animate-pulse uppercase">Explorando o Labirinto...</h3>
              <p className="text-indigo-700/60 text-xs tracking-[0.2em] uppercase italic">"Onde o Id estava, o Ego deverá estar"</p>
            </div>
          </motion.div>
        )}

        {step === 'result' && (
          <motion.div
            key="result"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="space-y-6"
          >
            {/* Header with payment simulation */}
            <div className="bg-slate-950/80 backdrop-blur-xl border border-indigo-500/20 rounded-3xl overflow-hidden shadow-2xl relative">
              {!isBlurred && (
                <TtsButton 
                  text={messages[0].content} 
                  voice="Charon" 
                  className="absolute top-6 right-6 z-20" 
                />
              )}
              <div className={`p-8 md:p-12 transition-all duration-1000 ${isBlurred ? 'blur-md select-none' : 'blur-0'}`}>
                <div className="prose prose-invert prose-amber max-w-none">
                   <ReactMarkdown>{messages[0].content}</ReactMarkdown>
                </div>
              </div>

              {isBlurred && (
                <div className="absolute inset-0 flex items-center justify-center p-6 bg-slate-950/40">
                  <div className="max-w-md w-full bg-slate-900/90 border border-indigo-500/30 rounded-3xl p-8 text-center space-y-6 backdrop-blur-md shadow-2xl">
                    <div className="flex justify-center">
                      <div className="w-16 h-16 rounded-full bg-indigo-500/10 flex items-center justify-center">
                        <CreditCard className="text-indigo-400" size={32} />
                      </div>
                    </div>
                    <div>
                      <h4 className="font-cinzel text-indigo-100 text-lg uppercase tracking-widest mb-2">Acesso ao Inconsciente</h4>
                      <p className="text-indigo-400/60 text-xs leading-relaxed">
                        Para revelar a análise profunda de Freud e Jung, utilize sua Chave de Prata.
                      </p>
                    </div>
                    {hasKey ? (
                      <button
                        onClick={() => setIsBlurred(false)}
                        className="w-full py-4 bg-indigo-600 hover:bg-indigo-500 text-white font-cinzel tracking-widest rounded-xl transition-all text-xs uppercase"
                      >
                        Usar Chave de Prata
                      </button>
                    ) : (
                      <button
                        onClick={onSelectKey}
                        className="w-full py-4 bg-indigo-600 hover:bg-indigo-500 text-white font-cinzel tracking-widest rounded-xl transition-all text-xs uppercase"
                      >
                        Adquirir Chave
                      </button>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Chat Session */}
            {!isBlurred && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-slate-950/80 backdrop-blur-xl border border-indigo-500/20 rounded-3xl p-6 md:p-8 shadow-2xl space-y-6"
              >
                <div className="flex items-center gap-3 border-b border-indigo-500/10 pb-4">
                  <MessageSquare className="text-indigo-400" size={20} />
                  <h3 className="font-cinzel text-[10px] text-indigo-400 uppercase tracking-widest font-bold">
                    Sessão Psicanalítica Contínua
                  </h3>
                </div>

                <div className="space-y-4 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
                  {messages.slice(1).map((msg, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, x: msg.role === 'user' ? 20 : -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                      <div className={`max-w-[85%] rounded-2xl p-4 text-sm leading-relaxed ${
                        msg.role === 'user' 
                          ? 'bg-indigo-600 text-white rounded-tr-none' 
                          : 'bg-slate-900 border border-indigo-500/10 text-indigo-100 rounded-tl-none'
                      }`}>
                        {msg.role === 'model' ? (
                          <div className="prose prose-invert prose-sm">
                            <ReactMarkdown>{msg.content}</ReactMarkdown>
                          </div>
                        ) : (
                          msg.content
                        )}
                      </div>
                    </motion.div>
                  ))}
                  {isChatting && (
                    <div className="flex justify-start">
                      <div className="bg-slate-900 border border-indigo-500/10 rounded-2xl rounded-tl-none p-4">
                        <Loader2 className="animate-spin text-indigo-500" size={20} />
                      </div>
                    </div>
                  )}
                  <div ref={chatEndRef} />
                </div>

                <form onSubmit={handleSendMessage} className="relative">
                  <input
                    type="text"
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    placeholder="Faça uma pergunta ao Analista..."
                    className="w-full bg-slate-900/50 border border-indigo-500/10 rounded-2xl py-4 pl-6 pr-20 text-sm text-indigo-100 focus:outline-none focus:border-indigo-500/30 transition-all"
                  />
                  <button
                    type="submit"
                    disabled={!chatInput.trim() || isChatting}
                    className="absolute right-2 top-2 bottom-2 px-6 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-30 rounded-xl transition-all"
                  >
                    <Send size={18} className="text-white" />
                  </button>
                </form>
              </motion.div>
            )}

            <button
               onClick={() => setStep('form')}
               className="w-full py-4 text-indigo-400 hover:text-indigo-300 font-cinzel text-[10px] tracking-widest uppercase flex items-center justify-center gap-2"
            >
              Novo Sonho <ChevronRight size={14} />
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default DreamConsultation;
