
import React from 'react';
import { GeomanticFigure } from '../types';

interface FigureDisplayProps {
  figure: GeomanticFigure;
  label?: string;
  size?: 'sm' | 'md' | 'lg';
}

const FigureDisplay: React.FC<FigureDisplayProps> = ({ figure, label, size = 'md' }) => {
  const containerClasses = {
    sm: "w-16 h-24 p-2",
    md: "w-28 h-40 p-3",
    lg: "w-36 h-52 p-4"
  };

  const nameClasses = {
    sm: "text-[9px] mt-2",
    md: "text-[11px] mt-3 uppercase tracking-tighter",
    lg: "text-sm mt-4 font-bold uppercase tracking-widest"
  };

  const labelClasses = {
    sm: "text-[7px]",
    md: "text-[9px]",
    lg: "text-[10px]"
  };

  return (
    <div className={`figure-card glass-card rounded-xl flex flex-col items-center justify-between border-t-2 border-t-amber-500/20 ${containerClasses[size]}`}>
      {label && (
        <span className={`font-cinzel text-amber-600/60 mb-2 text-center whitespace-nowrap overflow-hidden text-ellipsis w-full ${labelClasses[size]}`}>
          {label}
        </span>
      )}
      
      <div className="flex-grow flex flex-col justify-center gap-1.5">
        {figure.rows.map((row, idx) => (
          <div key={idx} className="flex justify-center h-4 items-center">
            <span className="geomancy-dot" />
            {row === 2 && <span className="geomancy-dot" />}
          </div>
        ))}
      </div>

      <div className="w-full pt-2 mt-2 border-t border-amber-900/20 text-center">
        <span className={`font-cinzel gold-text-shimmer block leading-none ${nameClasses[size]}`}>
          {figure.name}
        </span>
      </div>
    </div>
  );
};

export default FigureDisplay;
