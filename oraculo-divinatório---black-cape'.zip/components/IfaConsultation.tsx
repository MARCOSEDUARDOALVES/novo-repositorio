import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, Loader2, CreditCard, ChevronRight, Shell } from 'lucide-react';
import { interpretIfaReading, interpretIfaSubAudit, generatePersonaPortrait } from '../services/geminiService';
import TtsButton from './TtsButton';
import { IfaOdu, ConsultationObjective, IfaSubAudit } from '../types';
import ReactMarkdown from 'react-markdown';

interface IfaConsultationProps {
  hasKey: boolean;
  onSelectKey: () => void;
  objective: ConsultationObjective;
  onResult: (image: string | null, text: string) => void;
}

const IFA_ODUS: IfaOdu[] = [
  { name: "Eji Ogbe", binary: [1, 1, 1, 1], meaning: "O princípio de todas as coisas, luz total, expansão e sucesso." },
  { name: "Oyeku Meji", binary: [2, 2, 2, 2], meaning: "O fim de um ciclo, escuridão, proteção contra a morte e renovação." },
  { name: "Iwori Meji", binary: [2, 1, 1, 2], meaning: "Fogo, paixão, conflito e a necessidade de clareza mental." },
  { name: "Idi Meji", binary: [1, 2, 2, 1], meaning: "Estabilidade, fundação, fertilidade e o poder da terra." },
  { name: "Irosun Meji", binary: [1, 1, 2, 2], meaning: "Resiliência, superação de dificuldades e a voz dos ancestrais." },
  { name: "Owanrin Meji", binary: [2, 2, 1, 1], meaning: "Mudanças inesperadas, caos necessário e a quebra de padrões." },
  { name: "Obara Meji", binary: [1, 2, 2, 2], meaning: "Prosperidade, autoridade, mas alerta contra a arrogância." },
  { name: "Okanran Meji", binary: [2, 2, 2, 1], meaning: "Novos começos, rebeldia e a força para mudar o destino." },
  { name: "Ogunda Meji", binary: [1, 1, 1, 2], meaning: "Justiça, vitória sobre inimigos e o poder da ferramenta." },
  { name: "Osa Meji", binary: [2, 1, 1, 1], meaning: "Viagem, fuga, o vento e a influência das forças femininas." },
  { name: "Ika Meji", binary: [2, 1, 2, 2], meaning: "Controle, contenção, mas risco de isolamento e feitiçaria." },
  { name: "Oturupon Meji", binary: [2, 2, 1, 2], meaning: "Saúde, resistência física e a necessidade de paciência." },
  { name: "Otura Meji", binary: [1, 2, 1, 1], meaning: "Paz, espiritualidade, comunicação e a busca pela verdade." },
  { name: "Irete Meji", binary: [1, 1, 2, 1], meaning: "Humildade, sacrifício e a recompensa pelo esforço contínuo." },
  { name: "Ose Meji", binary: [1, 2, 1, 2], meaning: "Vitória, doçura, mas alerta contra a perda de energia." },
  { name: "Ofun Meji", binary: [2, 1, 2, 1], meaning: "Sabedoria suprema, mistério e a conclusão de grandes obras." },
];

const IfaConsultation: React.FC<IfaConsultationProps> = ({ hasKey, onSelectKey, objective, onResult }) => {
  const [question, setQuestion] = useState('');
  const [subQuestion, setSubQuestion] = useState('');
  const [step, setStep] = useState<'form' | 'analyzing' | 'result'>('form');
  const [selectedOdus, setSelectedOdus] = useState<IfaOdu[]>([]);
  const [report, setReport] = useState<string>('');
  const [paid, setPaid] = useState(false);
  const [subAudits, setSubAudits] = useState<IfaSubAudit[]>([]);
  const [loading, setLoading] = useState(false);
  const [subLoading, setSubLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleStartReading = () => {
    if (!question.trim()) {
      setError(`O Grande Sacerdote exige uma pergunta clara para Ifá.`);
      return;
    }
    if (!hasKey) {
      setError("Configure sua chave API para acessar a sabedoria de Ifá.");
      return;
    }
    setError(null);
    handleGenerate();
  };

  const handleGenerate = () => {
    setLoading(true);
    setStep('analyzing');
    
    // Sortear 3 Odus
    const shuffled = [...IFA_ODUS].sort(() => 0.5 - Math.random());
    const odus = shuffled.slice(0, 3);
    setSelectedOdus(odus);

    setTimeout(async () => {
      try {
        const [img, result] = await Promise.all([
          generatePersonaPortrait('ifa', objective).catch(() => null),
          interpretIfaReading(question, odus, objective)
        ]);
        setReport(result);
        onResult(img, result);
        setStep('result');
      } catch (err) {
        setError("Erro na conexão com o Orun.");
        setStep('form');
      } finally {
        setLoading(false);
      }
    }, 3000);
  };

  const handleSubAudit = async () => {
    if (!subQuestion.trim()) return;
    setSubLoading(true);
    
    try {
      // Sortear 1 Odu para o desmembramento
      const odu = IFA_ODUS[Math.floor(Math.random() * IFA_ODUS.length)];
      
      const subText = await interpretIfaSubAudit(subQuestion, [odu], question, objective);
      
      const newSub: IfaSubAudit = {
        question: subQuestion,
        odus: [odu],
        interpretation: subText
      };
      
      setSubAudits([newSub, ...subAudits]);
      setSubQuestion('');
    } catch (err) {
      console.error(err);
    } finally {
      setSubLoading(false);
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto">
      <AnimatePresence mode="wait">
        {step === 'form' && (
          <motion.div
            key="form"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="glass-card p-8 md:p-12 rounded-[3rem] space-y-8"
          >
            <div className="text-center space-y-2">
              <h2 className="text-3xl font-cinzel gold-text-shimmer uppercase tracking-widest">Oráculo de Ifá</h2>
              <p className="text-amber-700/60 font-light italic">A Sabedoria Ancestral de Oluwo Pai Cipriano</p>
            </div>

            <div className="space-y-4">
              <label className="block text-amber-600 text-[10px] uppercase tracking-widest text-center">
                Sua Pergunta ao Oráculo
              </label>
              <p className="text-amber-900/40 text-[9px] uppercase tracking-widest text-center italic">Orientação: Para uma resposta clara, faça uma pergunta objetiva.</p>
              <textarea
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                placeholder="Ex: Quais caminhos Ifá aponta para minha prosperidade?"
                className="w-full bg-black/40 border border-amber-900/20 rounded-2xl p-6 text-amber-100 font-cinzel text-lg text-center focus:outline-none focus:border-amber-500 transition-all placeholder:text-amber-900/20 min-h-[120px]"
              />
            </div>

            {error && <p className="text-red-500 text-[10px] text-center uppercase tracking-widest font-bold">{error}</p>}

            {!hasKey && (
              <button onClick={onSelectKey} className="w-full bg-amber-600/10 border border-amber-500/40 text-amber-500 font-cinzel text-xs py-3 rounded-lg hover:bg-amber-500/20 transition-all">
                CONFIGURAR ACESSO (CHAVE API)
              </button>
            )}

            <button
              onClick={handleStartReading}
              className="w-full bg-gradient-to-r from-amber-700 to-amber-900 text-black font-cinzel font-bold py-5 rounded-2xl tracking-[0.3em] hover:scale-[1.02] transition-all shadow-xl active:scale-95"
            >
              LANÇAR OS BÚZIOS (3 JOGADAS)
            </button>
          </motion.div>
        )}

        {step === 'analyzing' && (
          <motion.div
            key="analyzing"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex flex-col items-center justify-center space-y-12 py-20"
          >
            <motion.div
              animate={{ 
                rotate: [0, 360],
                scale: [1, 1.2, 1]
              }}
              transition={{ 
                duration: 3, 
                repeat: Infinity, 
                ease: "easeInOut"
              }}
              className="w-32 h-32 bg-amber-900/20 border border-amber-500/30 rounded-full flex items-center justify-center"
            >
              <Shell className="text-amber-500" size={48} />
            </motion.div>
            <div className="text-center space-y-4">
              <h3 className="text-2xl font-cinzel gold-text-shimmer animate-pulse uppercase">Consultando o Orun...</h3>
              <p className="text-amber-700/60 text-xs tracking-[0.2em] uppercase italic">"Ifá é a voz do destino, Odu é o caminho"</p>
            </div>
          </motion.div>
        )}

        {step === 'result' && (
          <motion.div
            key="result"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-8"
          >
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {selectedOdus.map((odu, idx) => (
                <motion.div
                  key={idx}
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ delay: idx * 0.3 }}
                  className="glass-card p-6 rounded-3xl border-amber-500/40 text-center space-y-4"
                >
                  <div className="w-12 h-12 bg-amber-500/10 rounded-full flex items-center justify-center mx-auto border border-amber-500/20">
                    <Shell className="text-amber-500" size={24} />
                  </div>
                  <div>
                    <p className="text-[10px] text-amber-700 uppercase tracking-widest">Odu {idx + 1}</p>
                    <h4 className="text-amber-100 font-cinzel text-lg font-bold uppercase">{odu.name}</h4>
                  </div>
                  <div className="grid grid-cols-2 gap-2 justify-center mx-auto w-fit">
                    {odu.binary.map((val, i) => (
                      <div key={i} className="flex gap-1 justify-center">
                        {[...Array(val)].map((_, j) => (
                          <div key={j} className="w-1.5 h-1.5 bg-amber-500 rounded-full" />
                        ))}
                      </div>
                    ))}
                  </div>
                </motion.div>
              ))}
            </div>

            <div className="relative">
              <div className="glass-card p-8 md:p-12 rounded-[3rem] relative overflow-hidden">
                {!paid ? null : (
                  <TtsButton 
                    text={report} 
                    voice="Fenrir" 
                    className="absolute top-6 right-6 z-20" 
                  />
                )}
                <div className="prose prose-invert prose-amber max-w-none">
                  <div className="markdown-body">
                    {/* Show first paragraph as preview, blur the rest */}
                    <div className="mb-4">
                      <ReactMarkdown>{report.split('\n\n')[0]}</ReactMarkdown>
                    </div>
                    <div className={`transition-all duration-1000 ${!paid ? 'blur-lg select-none pointer-events-none opacity-40' : ''}`}>
                      <ReactMarkdown>{report.split('\n\n').slice(1).join('\n\n')}</ReactMarkdown>
                    </div>
                  </div>
                </div>

                <div className="mt-12 pt-8 border-t border-amber-900/20 flex flex-wrap gap-4 justify-center">
                  <div className="flex items-center gap-2 px-4 py-2 bg-amber-500/5 rounded-full border border-amber-500/10">
                    <Sparkles size={14} className="text-amber-500" />
                    <span className="text-[10px] text-amber-600 uppercase tracking-widest font-bold">Oluwo: Pai Cipriano</span>
                  </div>
                  <div className="flex items-center gap-2 px-4 py-2 bg-amber-500/5 rounded-full border border-amber-500/10">
                    <ChevronRight size={14} className="text-amber-500" />
                    <span className="text-[10px] text-amber-600 uppercase tracking-widest font-bold">Tradição de Ifá</span>
                  </div>
                </div>
              </div>

              {!paid && (
                <div className="absolute inset-x-0 bottom-0 z-10 flex items-center justify-center p-12 bg-gradient-to-t from-black via-black/80 to-transparent pt-32 rounded-b-[3rem]">
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="glass-card p-12 rounded-[3rem] border-amber-500/40 bg-black/80 backdrop-blur-md text-center space-y-8 max-w-md shadow-2xl"
                  >
                    <div className="w-20 h-20 bg-amber-500/10 rounded-full flex items-center justify-center mx-auto border border-amber-500/20">
                      <CreditCard className="text-amber-500" size={32} />
                    </div>
                    <div className="space-y-2">
                      <h3 className="text-2xl font-cinzel text-amber-100 uppercase tracking-widest">Revelar Caminhos</h3>
                      <p className="text-amber-700/60 text-xs italic">O conhecimento de Ifá exige uma oferenda simbólica para o equilíbrio das energias.</p>
                    </div>
                    <div className="text-4xl font-cinzel gold-text-shimmer">R$ 19,99</div>
                    <div className="space-y-4">
                      <button
                        onClick={() => setPaid(true)}
                        className="w-full bg-amber-600 text-black font-cinzel font-bold py-4 rounded-xl tracking-widest hover:bg-amber-500 transition-all shadow-lg active:scale-95"
                      >
                        PAGAR COM PIX OU CARTÃO
                      </button>
                      <p className="text-amber-900/40 text-[8px] uppercase tracking-widest">Pagamento seguro via Pix ou Cartão de Crédito</p>
                    </div>
                  </motion.div>
                </div>
              )}
            </div>

            {/* SUB-AUDIT (DESMEMBRAMENTO) */}
            <div className="space-y-6">
              <div className="glass-card p-8 rounded-[2rem] border-amber-500/20 space-y-4">
                <h3 className="text-xl font-cinzel text-amber-500 uppercase tracking-widest text-center">Desmembrar Assunto (Combo 1 Odu)</h3>
                <div className="flex gap-4">
                  <input 
                    type="text"
                    value={subQuestion}
                    onChange={(e) => setSubQuestion(e.target.value)}
                    placeholder="Dúvida específica sobre este jogo..."
                    className="flex-1 bg-black/40 border border-amber-900/20 rounded-xl px-6 py-4 text-amber-100 focus:outline-none focus:border-amber-500 transition-all"
                  />
                  <button 
                    onClick={handleSubAudit}
                    disabled={subLoading || !subQuestion.trim()}
                    className="bg-amber-600 text-black px-8 rounded-xl font-cinzel font-bold hover:bg-amber-500 transition-all disabled:opacity-50"
                  >
                    {subLoading ? <Loader2 className="animate-spin" /> : "DESMEMBRAR"}
                  </button>
                </div>
              </div>

              <AnimatePresence>
                {subAudits.map((sub, idx) => (
                  <motion.div
                    key={idx}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="glass-card p-8 rounded-[2rem] border-amber-900/20 space-y-6"
                  >
                    <div className="flex items-center justify-between border-b border-amber-900/20 pb-4">
                      <h4 className="text-amber-500 font-cinzel text-sm uppercase tracking-widest">Detalhamento: {sub.question}</h4>
                      <div className="flex gap-2">
                        {sub.odus.map((o, i) => (
                          <div key={i} className="px-2 py-1 bg-amber-900/20 rounded text-[8px] text-amber-100 uppercase border border-amber-500/20">
                            {o.name}
                          </div>
                        ))}
                      </div>
                    </div>
                    <div className="prose prose-invert prose-sm max-w-none">
                      <ReactMarkdown>{sub.interpretation}</ReactMarkdown>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>

            <button
              onClick={() => {
                setStep('form');
                setSubAudits([]);
                setQuestion('');
                setPaid(false);
              }}
              className="block mx-auto text-amber-900 hover:text-amber-600 text-[10px] uppercase tracking-[0.5em] transition-all font-cinzel border-b border-transparent hover:border-amber-600 pb-1"
            >
              — Nova Consulta a Ifá —
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default IfaConsultation;
