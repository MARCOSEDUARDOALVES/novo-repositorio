import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, Loader2, CreditCard, ChevronRight, Moon } from 'lucide-react';
import { interpretIstikhara, generatePersonaPortrait } from '../services/geminiService';
import TtsButton from './TtsButton';
import { ConsultationObjective } from '../types';
import ReactMarkdown from 'react-markdown';

interface IstikharaConsultationProps {
  hasKey: boolean;
  onSelectKey: () => void;
  objective: ConsultationObjective;
  onResult: (image: string | null, text: string) => void;
}

const IstikharaConsultation: React.FC<IstikharaConsultationProps> = ({ hasKey, onSelectKey, objective, onResult }) => {
  const [question, setQuestion] = useState('');
  const [step, setStep] = useState<'form' | 'analyzing' | 'result'>('form');
  const [report, setReport] = useState<string>('');
  const [paid, setPaid] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleStartReading = () => {
    if (!question.trim()) {
      setError(`O Mestre exige uma pergunta clara para o Istikhara.`);
      return;
    }
    if (!hasKey) {
      setError("Configure sua chave API para acessar a clareza divina.");
      return;
    }
    setError(null);
    handleGenerate();
  };

  const handleGenerate = () => {
    setLoading(true);
    setStep('analyzing');
    
    setTimeout(async () => {
      try {
        const [img, result] = await Promise.all([
          generatePersonaPortrait('istikhara', objective).catch(() => null),
          interpretIstikhara(question, objective)
        ]);
        setReport(result);
        onResult(img, result);
        setStep('result');
      } catch (err) {
        setError("Erro na conexão com o plano espiritual.");
        setStep('form');
      } finally {
        setLoading(false);
      }
    }, 3000);
  };

  return (
    <div className="w-full max-w-4xl mx-auto">
      <AnimatePresence mode="wait">
        {step === 'form' && (
          <motion.div
            key="form"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="glass-card p-8 md:p-12 rounded-[3rem] space-y-8"
          >
            <div className="text-center space-y-2">
              <h2 className="text-3xl font-cinzel gold-text-shimmer uppercase tracking-widest">Istikhara: Consulta Divina</h2>
              <p className="text-amber-700/60 font-light italic">A Sabedoria Infinitas do Sábio Al-Khidr</p>
            </div>

            <div className="space-y-4">
              <label className="block text-amber-600 text-[10px] uppercase tracking-widest text-center">
                Sua Intenção (Niyyah)
              </label>
              <p className="text-amber-900/40 text-[9px] uppercase tracking-widest text-center italic">Orientação: Para uma resposta clara, faça uma pergunta objetiva.</p>
              <textarea
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                placeholder="Ex: Devo seguir com este novo empreendimento?"
                className="w-full bg-black/40 border border-amber-900/20 rounded-2xl p-6 text-amber-100 font-cinzel text-lg text-center focus:outline-none focus:border-amber-500 transition-all placeholder:text-amber-900/20 min-h-[120px]"
              />
            </div>

            {error && <p className="text-red-500 text-[10px] text-center uppercase tracking-widest font-bold">{error}</p>}

            {!hasKey && (
              <button onClick={onSelectKey} className="w-full bg-amber-600/10 border border-amber-500/40 text-amber-500 font-cinzel text-xs py-3 rounded-lg hover:bg-amber-500/20 transition-all">
                CONFIGURAR ACESSO (CHAVE API)
              </button>
            )}

            <button
              onClick={handleStartReading}
              className="w-full bg-gradient-to-r from-amber-700 to-amber-900 text-black font-cinzel font-bold py-5 rounded-2xl tracking-[0.3em] hover:scale-[1.02] transition-all shadow-xl active:scale-95"
            >
              BUSCAR CLAREZA
            </button>
          </motion.div>
        )}

        {step === 'analyzing' && (
          <motion.div
            key="analyzing"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex flex-col items-center justify-center space-y-12 py-20"
          >
            <div className="relative w-32 h-32">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
                className="absolute inset-0 border-t-2 border-amber-500 rounded-full"
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <Moon className="text-amber-500 animate-pulse" size={48} />
              </div>
            </div>
            <div className="text-center space-y-4">
              <h3 className="text-2xl font-cinzel gold-text-shimmer animate-pulse uppercase">Consultando o Destino...</h3>
              <p className="text-amber-700/60 text-xs tracking-[0.2em] uppercase italic">Aguardando o sinal da paz interior</p>
            </div>
          </motion.div>
        )}

        {step === 'result' && report && (
          <motion.div
            key="result"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-8"
          >
            <div className="relative">
              <div className="glass-card p-8 md:p-12 rounded-[3rem] relative overflow-hidden">
                {!paid ? null : (
                  <TtsButton 
                    text={report} 
                    voice="Zephyr" 
                    className="absolute top-6 right-6 z-20" 
                  />
                )}
                <div className="prose prose-invert prose-amber max-w-none">
                  <div className="markdown-body">
                    {/* Show first paragraph as preview, blur the rest */}
                    <div className="mb-4">
                      <ReactMarkdown>{report.split('\n\n')[0]}</ReactMarkdown>
                    </div>
                    <div className={`transition-all duration-1000 ${!paid ? 'blur-lg select-none pointer-events-none opacity-40' : ''}`}>
                      <ReactMarkdown>{report.split('\n\n').slice(1).join('\n\n')}</ReactMarkdown>
                    </div>
                  </div>
                </div>

                <div className="mt-12 pt-8 border-t border-amber-900/20 flex flex-wrap gap-4 justify-center">
                  <div className="flex items-center gap-2 px-4 py-2 bg-amber-500/5 rounded-full border border-amber-500/10">
                    <Moon size={14} className="text-amber-500" />
                    <span className="text-[10px] text-amber-600 uppercase tracking-widest font-bold">Mestre: Sábio Al-Khidr</span>
                  </div>
                  <div className="flex items-center gap-2 px-4 py-2 bg-amber-500/5 rounded-full border border-amber-500/10">
                    <Sparkles size={14} className="text-amber-500" />
                    <span className="text-[10px] text-amber-600 uppercase tracking-widest font-bold">Visão de Blak Cape</span>
                  </div>
                </div>
              </div>

              {!paid && (
                <div className="absolute inset-x-0 bottom-0 z-10 flex items-center justify-center p-12 bg-gradient-to-t from-black via-black/80 to-transparent pt-32 rounded-b-[3rem]">
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="glass-card p-12 rounded-[3rem] border-amber-500/40 bg-black/80 backdrop-blur-md text-center space-y-8 max-w-md shadow-2xl"
                  >
                    <div className="w-20 h-20 bg-amber-500/10 rounded-full flex items-center justify-center mx-auto border border-amber-500/20">
                      <CreditCard className="text-amber-500" size={32} />
                    </div>
                    <div className="space-y-2">
                      <h3 className="text-2xl font-cinzel text-amber-100 uppercase tracking-widest">Revelar Orientação</h3>
                      <p className="text-amber-700/60 text-xs italic">O acesso à clareza divina exige uma contribuição para o equilíbrio das energias.</p>
                    </div>
                    <div className="text-4xl font-cinzel gold-text-shimmer">R$ 19,99</div>
                    <div className="space-y-4">
                      <button
                        onClick={() => setPaid(true)}
                        className="w-full bg-amber-600 text-black font-cinzel font-bold py-4 rounded-xl tracking-widest hover:bg-amber-500 transition-all shadow-lg active:scale-95"
                      >
                        PAGAR COM PIX OU CARTÃO
                      </button>
                      <p className="text-amber-900/40 text-[8px] uppercase tracking-widest">Pagamento seguro via Pix ou Cartão de Crédito</p>
                    </div>
                  </motion.div>
                </div>
              )}
            </div>

            <button
              onClick={() => {
                setStep('form');
                setQuestion('');
                setPaid(false);
              }}
              className="block mx-auto text-amber-900 hover:text-amber-600 text-[10px] uppercase tracking-[0.5em] transition-all font-cinzel border-b border-transparent hover:border-amber-600 pb-1"
            >
              — Nova Consulta Istikhara —
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default IstikharaConsultation;
