import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, Loader2, CreditCard, Eye, ShieldCheck } from 'lucide-react';
import { interpretKabbalahReading, generatePersonaPortrait } from '../services/geminiService';
import TtsButton from './TtsButton';
import { KabbalahName, ConsultationObjective } from '../types';
import ReactMarkdown from 'react-markdown';

interface KabbalahConsultationProps {
  hasKey: boolean;
  onSelectKey: () => void;
  objective: ConsultationObjective;
  onResult: (image: string | null, text: string) => void;
}

const KABBALAH_NAMES: KabbalahName[] = [
  { id: 1, letters: "Vav He Vav", meaning: "Viagem no Tempo" },
  { id: 2, letters: "Yod Lamed Yod", meaning: "Recuperando a Centelha" },
  { id: 3, letters: "Samech Teth Yod", meaning: "Fazendo Milagres" },
  { id: 4, letters: "Ayin Lamed Mem", meaning: "Eliminando Pensamentos Negativos" },
  { id: 5, letters: "Mem He Shin", meaning: "Cura" },
  { id: 6, letters: "Lamed Lamed He", meaning: "Estado de Sonho" },
  { id: 7, letters: "Aleph Kaph Aleph", meaning: "DNA da Alma" },
  { id: 8, letters: "Kaph He Tav", meaning: "Defusing Negative Energy" },
  { id: 9, letters: "He Zayin Yod", meaning: "Influências Angélicas" },
  { id: 10, letters: "Aleph Lamed Daled", meaning: "Proteção contra o Mau Olhado" },
  { id: 11, letters: "Lamed Aleph Vav", meaning: "Banindo a Presença do Mal" },
  { id: 12, letters: "He He Ayin", meaning: "Amor Incondicional" },
  { id: 13, letters: "Yod Zayin Lamed", meaning: "Paraíso na Terra" },
  { id: 14, letters: "Mem He Bhet", meaning: "Adeus às Armas" },
  { id: 15, letters: "He Resh Yod", meaning: "Visão de Longo Alcance" },
  { id: 16, letters: "He Kaph Mem", meaning: "Dumping Depression" },
  { id: 17, letters: "Lamed Aleph Vav", meaning: "Great Escape" },
  { id: 18, letters: "Kaph Lamed Yod", meaning: "Fertilidade" },
  { id: 19, letters: "Lamed Vav Vav", meaning: "Conexão Direta com Deus" },
  { id: 20, letters: "Pe He Lamed", meaning: "Victory Over Addiction" },
];

const KabbalahConsultation: React.FC<KabbalahConsultationProps> = ({ hasKey, onSelectKey, objective, onResult }) => {
  const personaName = 'Senhor Zohar';

  const [question, setQuestion] = useState('');
  const [step, setStep] = useState<'form' | 'analyzing' | 'result'>('form');
  const [selectedName, setSelectedName] = useState<KabbalahName | null>(null);
  const [report, setReport] = useState<string>('');
  const [paid, setPaid] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleStartReading = () => {
    if (!question.trim()) {
      setError(`O Mestre exige uma pergunta para a Luz da Cabala.`);
      return;
    }
    if (!hasKey) {
      setError("Configure sua chave API para acessar os mistérios do Zohar.");
      return;
    }
    setError(null);
    handleGenerate();
  };

  const handleGenerate = () => {
    setLoading(true);
    setStep('analyzing');
    
    // Sorteio aleatório de um dos nomes
    const randomName = KABBALAH_NAMES[Math.floor(Math.random() * KABBALAH_NAMES.length)];
    setSelectedName(randomName);

    setTimeout(async () => {
      try {
        const [img, result] = await Promise.all([
          generatePersonaPortrait('kabbalah', objective).catch(() => null),
          interpretKabbalahReading(question, randomName, objective)
        ]);
        setReport(result);
        onResult(img, result);
        setStep('result');
      } catch (err) {
        setError("Erro na conexão com as Sefirot.");
        setStep('form');
      } finally {
        setLoading(false);
      }
    }, 4000);
  };

  return (
    <div className="w-full max-w-4xl mx-auto">
      <AnimatePresence mode="wait">
        {step === 'form' && (
          <motion.div
            key="form"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="glass-card p-8 md:p-12 rounded-[3rem] space-y-8 border-amber-500/10"
          >
            <div className="text-center space-y-2">
              <h2 className="text-3xl font-cinzel gold-text-shimmer uppercase tracking-widest">Oráculo Cabalístico</h2>
              <p className="text-amber-700/60 font-light italic">Os 72 Nomes de Deus e a Sabedoria do Zohar</p>
            </div>

            <div className="space-y-4">
              <label className="block text-amber-600 text-[10px] uppercase tracking-widest text-center">
                Sua Intenção ou Dúvida
              </label>
              <p className="text-amber-900/40 text-[9px] uppercase tracking-widest text-center italic">Orientação: Para uma resposta clara, faça uma pergunta objetiva.</p>
              <textarea
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                placeholder="O que você deseja retificar em sua vida?"
                className="w-full bg-black/40 border border-amber-900/20 rounded-2xl p-6 text-amber-100 font-cinzel text-lg text-center focus:outline-none focus:border-amber-500 transition-all placeholder:text-amber-900/20 min-h-[120px]"
              />
            </div>

            {error && <p className="text-red-500 text-[10px] text-center uppercase tracking-widest font-bold">{error}</p>}

            {!hasKey && (
              <button onClick={onSelectKey} className="w-full bg-amber-600/10 border border-amber-500/40 text-amber-500 font-cinzel text-xs py-3 rounded-lg hover:bg-amber-500/20 transition-all">
                CONFIGURAR ACESSO (CHAVE API)
              </button>
            )}

            <button
              onClick={handleStartReading}
              className="w-full bg-gradient-to-r from-amber-700 to-amber-900 text-black font-cinzel font-bold py-5 rounded-2xl tracking-[0.3em] hover:scale-[1.02] transition-all shadow-xl active:scale-95"
            >
              REVELAR O NOME SAGRADO
            </button>
          </motion.div>
        )}

        {step === 'analyzing' && (
          <motion.div
            key="analyzing"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex flex-col items-center justify-center space-y-12 py-20"
          >
            <div className="relative">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
                className="w-48 h-48 border-2 border-dashed border-amber-500/20 rounded-full flex items-center justify-center"
              >
                <div className="text-amber-500/40 text-4xl font-cinzel">🔯</div>
              </motion.div>
              <div className="absolute inset-0 flex items-center justify-center">
                <Loader2 className="text-amber-500 animate-spin" size={48} />
              </div>
            </div>
            <div className="text-center space-y-4">
              <h3 className="text-2xl font-cinzel gold-text-shimmer animate-pulse uppercase">Emanando a Luz do Zohar...</h3>
              <p className="text-amber-700/60 text-xs tracking-[0.2em] uppercase italic">Sintonizando com as 10 Sefirot</p>
            </div>
          </motion.div>
        )}

        {step === 'result' && selectedName && (
          <motion.div
            key="result"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-8"
          >
            <div className="glass-card p-12 rounded-[3rem] text-center space-y-6 border-amber-500/30">
              <div className="text-[10px] text-amber-700 uppercase tracking-[0.5em] mb-4">Nome de Deus Revelado</div>
              <div className="text-6xl md:text-8xl font-cinzel gold-text-shimmer tracking-widest mb-4">
                {selectedName.letters}
              </div>
              <div className="h-px w-24 bg-amber-900/40 mx-auto"></div>
              <h3 className="text-2xl font-cinzel text-amber-100 uppercase tracking-widest">
                {selectedName.meaning}
              </h3>
              <p className="text-amber-700/60 text-xs italic">Nome #{selectedName.id} da Tecnologia da Alma</p>
            </div>

            <div className="relative">
              <div className="glass-card p-8 md:p-12 rounded-[3rem] relative overflow-hidden">
                {!paid ? null : (
                  <TtsButton 
                    text={report} 
                    voice="Charon" 
                    className="absolute top-6 right-6 z-20" 
                  />
                )}
                <div className="prose prose-invert prose-amber max-w-none">
                  <div className="markdown-body">
                    {/* Show first paragraph as preview, blur the rest */}
                    <div className="mb-4">
                      <ReactMarkdown>{report.split('\n\n')[0]}</ReactMarkdown>
                    </div>
                    <div className={`transition-all duration-1000 ${!paid ? 'blur-lg select-none pointer-events-none opacity-40' : ''}`}>
                      <ReactMarkdown>{report.split('\n\n').slice(1).join('\n\n')}</ReactMarkdown>
                    </div>
                  </div>
                </div>

                <div className="mt-12 pt-8 border-t border-amber-900/20 flex flex-wrap gap-4 justify-center">
                  <div className="flex items-center gap-2 px-4 py-2 bg-amber-500/5 rounded-full border border-amber-500/10">
                    <Eye size={14} className="text-amber-500" />
                    <span className="text-[10px] text-amber-600 uppercase tracking-widest font-bold">Mestre: Senhor Zohar</span>
                  </div>
                  <div className="flex items-center gap-2 px-4 py-2 bg-amber-500/5 rounded-full border border-amber-500/10">
                    <ShieldCheck size={14} className="text-amber-500" />
                    <span className="text-[10px] text-amber-600 uppercase tracking-widest font-bold">Proteção Espiritual Ativada</span>
                  </div>
                </div>
              </div>

              {!paid && (
                <div className="absolute inset-x-0 bottom-0 z-10 flex items-center justify-center p-12 bg-gradient-to-t from-black via-black/80 to-transparent pt-32 rounded-b-[3rem]">
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="glass-card p-12 rounded-[3rem] border-amber-500/40 bg-black/80 backdrop-blur-md text-center space-y-8 max-w-md shadow-2xl"
                  >
                    <div className="w-20 h-20 bg-amber-500/10 rounded-full flex items-center justify-center mx-auto border border-amber-500/20">
                      <CreditCard className="text-amber-500" size={32} />
                    </div>
                    <div className="space-y-2">
                      <h3 className="text-2xl font-cinzel text-amber-100 uppercase tracking-widest">Revelar Meditação</h3>
                      <p className="text-amber-700/60 text-xs italic">A revelação dos Nomes Sagrados exige um ato de restrição e compartilhamento.</p>
                    </div>
                    <div className="text-4xl font-cinzel gold-text-shimmer">R$ 19,99</div>
                    <div className="space-y-4">
                      <button
                        onClick={() => setPaid(true)}
                        className="w-full bg-amber-600 text-black font-cinzel font-bold py-4 rounded-xl tracking-widest hover:bg-amber-500 transition-all shadow-lg active:scale-95"
                      >
                        PAGAR COM PIX OU CARTÃO
                      </button>
                      <p className="text-amber-900/40 text-[8px] uppercase tracking-widest">Pagamento seguro via Pix ou Cartão de Crédito</p>
                    </div>
                  </motion.div>
                </div>
              )}
            </div>

            <button
              onClick={() => {
                setStep('form');
                setPaid(false);
              }}
              className="block mx-auto text-amber-900 hover:text-amber-600 text-[10px] uppercase tracking-[0.5em] transition-all font-cinzel border-b border-transparent hover:border-amber-600 pb-1"
            >
              — Nova Meditação Cabalística —
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default KabbalahConsultation;
