import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Compass, Sparkles, LayoutGrid, Quote, Cross, Shell, Moon, Brain } from 'lucide-react';
import DailySky from './DailySky';
import OracleIntro from './OracleIntro';

interface QuoteType {
  text: string;
  author: string;
  source: 'Cristo' | 'Buda' | 'Filosofia';
}

const QUOTES: QuoteType[] = [
  { text: "O Reino de Deus está dentro de vós.", author: "Jesus Cristo", source: "Cristo" },
  { text: "A verdade vos libertará.", author: "Jesus Cristo", source: "Cristo" },
  { text: "A mente é tudo. O que você pensa, você se torna.", author: "Buda", source: "Buda" },
  { text: "A paz vem de dentro. Não a procure à sua volta.", author: "Buda", source: "Buda" },
  { text: "Conhece-te a ti mesmo e conhecerás o universo e os deuses.", author: "Sócrates", source: "Filosofia" },
  { text: "Onde não há visão, o povo perece.", author: "Provérbios", source: "Filosofia" },
  { text: "A vida não examinada não vale a pena ser vivida.", author: "Sócrates", source: "Filosofia" },
  { text: "Faze o que tu queres, há de ser tudo da Lei.", author: "Aleister Crowley", source: "Filosofia" },
  { text: "Tudo o que somos é o resultado do que pensamos.", author: "Buda", source: "Buda" },
  { text: "Eu sou o caminho, a verdade e a vida.", author: "Jesus Cristo", source: "Cristo" },
];

interface LandingPageProps {
  onEnter: (tab: 'geomancy' | 'astrology' | 'tarot' | 'kabbalah' | 'supreme' | 'ifa' | 'istikhara' | 'dreams') => void;
}

const LandingPage: React.FC<LandingPageProps> = ({ onEnter }) => {
  const [currentQuoteIndex, setCurrentQuoteIndex] = useState(0);
  const [selectedOracle, setSelectedOracle] = useState<'geomancy' | 'astrology' | 'tarot' | 'kabbalah' | 'supreme' | 'ifa' | 'istikhara' | null>(null);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentQuoteIndex((prev) => (prev + 1) % QUOTES.length);
    }, 8000);
    return () => clearInterval(interval);
  }, []);

  const currentQuote = QUOTES[currentQuoteIndex];

  const oracleNames: Record<string, string> = {
    geomancy: 'Geomancia',
    astrology: 'Astrologia',
    tarot: 'Tarô',
    kabbalah: 'Cabala',
    supreme: 'Oráculo Supremo',
    ifa: 'Ifá',
    istikhara: 'Istikhara'
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#0a0502] overflow-y-auto scrollbar-hide flex flex-col items-center p-6 md:p-12">
      <AnimatePresence>
        {selectedOracle && (
          <OracleIntro 
            oracleId={selectedOracle}
            oracleName={oracleNames[selectedOracle]} 
            onClose={() => setSelectedOracle(null)}
            onProceed={() => {
              onEnter(selectedOracle);
              setSelectedOracle(null);
            }}
          />
        )}
      </AnimatePresence>
      {/* Background Atmosférico */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full bg-[radial-gradient(circle_at_center,rgba(251,191,36,0.08)_0%,transparent_70%)]"></div>
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-amber-900/20 blur-[120px] rounded-full animate-pulse"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-amber-600/10 blur-[120px] rounded-full animate-pulse" style={{ animationDelay: '2s' }}></div>
      </div>

      {/* Título Principal */}
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 2, ease: "easeOut" }}
        className="relative z-10 text-center mb-12 mt-12 md:mt-0"
      >
        <h1 className="text-4xl md:text-6xl font-cinzel font-bold gold-text-shimmer tracking-tight leading-tight uppercase drop-shadow-[0_0_15px_rgba(245,158,11,0.3)]">
          ORACULO DIVINATÓRIO <br />
          <span className="text-2xl md:text-4xl opacity-80">o Black Cape'</span>
        </h1>
        <p className="text-amber-700/60 font-cinzel text-sm md:text-lg tracking-[0.3em] mt-4 uppercase italic">
          Desvende os mistérios de sua vida
        </p>
      </motion.div>

      {/* Céu de Hoje - Mais Informativo */}
      <div className="relative z-10 w-full px-4 mb-12">
        <DailySky />
      </div>

      <div className="h-px w-32 bg-gradient-to-r from-transparent via-amber-900/40 to-transparent mx-auto mb-16"></div>

      {/* Conteúdo Central: Citações */}
      <div className="relative z-10 max-w-3xl w-full text-center mb-16 px-4">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentQuoteIndex}
            initial={{ opacity: 0, y: 20, filter: 'blur(10px)' }}
            animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
            exit={{ opacity: 0, y: -20, filter: 'blur(10px)' }}
            transition={{ duration: 1.5, ease: "easeInOut" }}
            className="space-y-6"
          >
            <Quote className="mx-auto text-amber-900/40 mb-4" size={40} />
            <h2 className="text-xl md:text-3xl font-cinzel italic text-amber-100/90 leading-relaxed tracking-tight">
              "{currentQuote.text}"
            </h2>
            <div className="flex flex-col items-center gap-1">
              <span className="text-amber-600 font-cinzel text-[10px] md:text-xs tracking-[0.2em] md:tracking-[0.3em] uppercase">
                {currentQuote.author}
              </span>
              <span className="text-amber-900 text-[8px] md:text-[9px] tracking-[0.4em] md:tracking-[0.5em] uppercase font-bold">
                — {currentQuote.source} —
              </span>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Portais de Entrada - Grid Ajustado para Responsividade */}
      <div className="relative z-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 w-full max-w-7xl pb-24 px-4">
        <motion.button
          whileHover={{ scale: 1.02, y: -5 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => setSelectedOracle('geomancy')}
          className="group relative glass-card p-6 rounded-[2rem] border-amber-900/20 hover:border-amber-500/40 transition-all duration-500 overflow-hidden"
        >
          <div className="absolute inset-0 bg-gradient-to-b from-amber-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
          <div className="relative z-10 flex flex-col items-center gap-4">
            <div className="w-12 h-12 rounded-full border border-amber-900/40 flex items-center justify-center group-hover:border-amber-500/60 transition-colors">
              <Compass className="text-amber-700 group-hover:text-amber-500 transition-colors" size={20} />
            </div>
            <div className="text-center space-y-1">
              <h3 className="font-cinzel text-amber-100 text-xs tracking-widest uppercase font-bold">
                Geomancia <br/>
                <span className="text-[9px] lowercase italic opacity-50 font-normal">por</span> Banqueiro Árabe
              </h3>
            </div>
          </div>
        </motion.button>

        <motion.button
          whileHover={{ scale: 1.02, y: -5 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => setSelectedOracle('astrology')}
          className="group relative glass-card p-6 rounded-[2rem] border-amber-900/20 hover:border-amber-500/40 transition-all duration-500 overflow-hidden"
        >
          <div className="absolute inset-0 bg-gradient-to-b from-amber-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
          <div className="relative z-10 flex flex-col items-center gap-4">
            <div className="w-12 h-12 rounded-full border border-amber-900/40 flex items-center justify-center group-hover:border-amber-500/60 transition-colors">
              <Sparkles className="text-amber-700 group-hover:text-amber-500 transition-colors" size={20} />
            </div>
            <div className="text-center space-y-1">
              <h3 className="font-cinzel text-amber-100 text-xs tracking-widest uppercase font-bold">
                Astrologia <br/>
                <span className="text-[9px] lowercase italic opacity-50 font-normal">por</span> Professor Jupiter
              </h3>
            </div>
          </div>
        </motion.button>

        <motion.button
          whileHover={{ scale: 1.02, y: -5 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => setSelectedOracle('tarot')}
          className="group relative glass-card p-6 rounded-[2rem] border-amber-900/20 hover:border-amber-500/40 transition-all duration-500 overflow-hidden"
        >
          <div className="absolute inset-0 bg-gradient-to-b from-amber-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
          <div className="relative z-10 flex flex-col items-center gap-4">
            <div className="w-12 h-12 rounded-full border border-amber-900/40 flex items-center justify-center group-hover:border-amber-500/60 transition-colors">
              <LayoutGrid className="text-amber-700 group-hover:text-amber-500 transition-colors" size={20} />
            </div>
            <div className="text-center space-y-1">
              <h3 className="font-cinzel text-amber-100 text-xs tracking-widest uppercase font-bold">
                Tarô <br/>
                <span className="text-[9px] lowercase italic opacity-50 font-normal">por</span> Dona Maria Mulambo
              </h3>
            </div>
          </div>
        </motion.button>

        <motion.button
          whileHover={{ scale: 1.02, y: -5 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => setSelectedOracle('kabbalah')}
          className="group relative glass-card p-6 rounded-[2rem] border-amber-900/20 hover:border-amber-500/40 transition-all duration-500 overflow-hidden"
        >
          <div className="absolute inset-0 bg-gradient-to-b from-amber-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
          <div className="relative z-10 flex flex-col items-center gap-4">
            <div className="w-12 h-12 rounded-full border border-amber-900/40 flex items-center justify-center group-hover:border-amber-500/60 transition-colors">
              <div className="text-amber-700 group-hover:text-amber-500 transition-colors text-lg font-cinzel">🔯</div>
            </div>
            <div className="text-center space-y-1">
              <h3 className="font-cinzel text-amber-100 text-xs tracking-widest uppercase font-bold">
                Cabala <br/>
                <span className="text-[9px] lowercase italic opacity-50 font-normal">por</span> Senhor Zohar
              </h3>
            </div>
          </div>
        </motion.button>

        <motion.button
          whileHover={{ scale: 1.02, y: -5 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => setSelectedOracle('supreme')}
          className="group relative glass-card p-6 rounded-[2rem] border-amber-500/40 hover:border-amber-400/60 transition-all duration-500 overflow-hidden"
        >
          <div className="absolute inset-0 bg-gradient-to-b from-amber-400/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
          <div className="relative z-10 flex flex-col items-center gap-4">
            <div className="w-12 h-12 rounded-full border border-amber-500/40 flex items-center justify-center group-hover:border-amber-400/60 transition-colors">
              <Cross className="text-amber-500 group-hover:text-amber-400 transition-colors" size={20} />
            </div>
            <div className="text-center space-y-1">
              <h3 className="font-cinzel text-amber-100 text-xs tracking-widest uppercase font-bold">
                Supremo <br/>
                <span className="text-[9px] lowercase italic opacity-50 font-normal">por</span> Jesus & Madalena
              </h3>
            </div>
          </div>
        </motion.button>

        <motion.button
          whileHover={{ scale: 1.02, y: -5 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => setSelectedOracle('ifa')}
          className="group relative glass-card p-6 rounded-[2rem] border-amber-900/20 hover:border-amber-500/40 transition-all duration-500 overflow-hidden"
        >
          <div className="absolute inset-0 bg-gradient-to-b from-amber-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
          <div className="relative z-10 flex flex-col items-center gap-4">
            <div className="w-12 h-12 rounded-full border border-amber-900/40 flex items-center justify-center group-hover:border-amber-500/60 transition-colors">
              <Shell className="text-amber-700 group-hover:text-amber-500 transition-colors" size={20} />
            </div>
            <div className="text-center space-y-1">
              <h3 className="font-cinzel text-amber-100 text-xs tracking-widest uppercase font-bold">
                Ifá <br/>
                <span className="text-[9px] lowercase italic opacity-50 font-normal">por</span> Oluwo Pai Cipriano
              </h3>
            </div>
          </div>
        </motion.button>

        <motion.button
          whileHover={{ scale: 1.02, y: -5 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => setSelectedOracle('istikhara')}
          className="group relative glass-card p-6 rounded-[2rem] border-amber-900/20 hover:border-amber-500/40 transition-all duration-500 overflow-hidden"
        >
          <div className="absolute inset-0 bg-gradient-to-b from-amber-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
          <div className="relative z-10 flex flex-col items-center gap-4">
            <div className="w-12 h-12 rounded-full border border-amber-900/40 flex items-center justify-center group-hover:border-amber-500/60 transition-colors">
              <Moon className="text-amber-700 group-hover:text-amber-500 transition-colors" size={20} />
            </div>
            <div className="text-center space-y-1">
              <h3 className="font-cinzel text-amber-100 text-xs tracking-widest uppercase font-bold">
                Istikhara <br/>
                <span className="text-[9px] lowercase italic opacity-50 font-normal">por</span> Sábio Al-Khidr
              </h3>
            </div>
          </div>
        </motion.button>

        <motion.button
          whileHover={{ scale: 1.02, y: -5 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => onEnter('dreams')}
          className="group relative glass-card p-6 rounded-[2rem] border-indigo-500/20 hover:border-indigo-500/40 transition-all duration-500 overflow-hidden"
        >
          <div className="absolute inset-0 bg-gradient-to-b from-indigo-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
          <div className="relative z-10 flex flex-col items-center gap-4">
            <div className="w-12 h-12 rounded-full border border-indigo-500/40 flex items-center justify-center group-hover:border-indigo-500/60 transition-colors">
              <Brain className="text-indigo-400 group-hover:text-indigo-300 transition-colors" size={20} />
            </div>
            <div className="text-center space-y-1">
              <h3 className="font-cinzel text-indigo-100 text-xs tracking-widest uppercase font-bold text-center">
                Interpretador de Sonhos <br/>
                <span className="text-[9px] lowercase italic opacity-50 font-normal">por</span> O Analista
              </h3>
            </div>
          </div>
        </motion.button>
      </div>

      {/* Footer Decorativo */}
      <div className="relative z-10 py-12 w-full text-center">
        <p className="text-amber-900/40 font-cinzel text-[9px] tracking-[1em] uppercase">
          Mestre Black Cape — Oráculo Supremo
        </p>
      </div>
    </div>
  );
};

export default LandingPage;
