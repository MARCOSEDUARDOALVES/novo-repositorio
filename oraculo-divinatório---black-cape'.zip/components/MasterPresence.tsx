
import React from 'react';
import { ConsultationObjective } from '../types';

interface MasterPresenceProps {
  image?: string | null;
  status: 'idle' | 'thinking' | 'result';
  objective: ConsultationObjective;
  oracle?: string;
}

const MasterPresence: React.FC<MasterPresenceProps> = ({ image, status, objective, oracle = 'geomancy' }) => {
  const isRelationship = objective === 'relationship';
  const getEntityInfo = () => {
    switch (oracle) {
      case 'astrology':
        return { name: 'PROFESSOR JUPITER', subtitle: 'Mestre das Estrelas & Destino', icon: '✨' };
      case 'tarot':
        return { name: 'DONA MARIA MULAMBO', subtitle: 'Rainha das Encruzilhadas & Caminhos', icon: '💃' };
      case 'kabbalah':
        return { name: 'SENHOR ZOHAR', subtitle: 'Guardião da Luz & Tikkun', icon: '🔯' };
      case 'supreme':
        return { name: 'JESUS & MADALENA', subtitle: 'O Cristo Cósmico & Equilíbrio Sagrado', icon: '🕊️' };
      case 'ifa':
        return { name: 'OLUWO PAI CIPRIANO', subtitle: 'Sacerdote da Floresta & Ancestralidade', icon: '🐚' };
      case 'istikhara':
        return { name: 'SÁBIO AL-KHIDR', subtitle: 'Mestre da Clareza & Fé', icon: '🌙' };
      case 'dreams':
        return { name: 'O ANALISTA', subtitle: 'Freud & Jung: Portal do Inconsciente', icon: '🌀' };
      default:
        return { name: 'BANQUEIRO ÁRABE (Sr. Capa Preta)', subtitle: 'Soberano da Fortuna & Estrategista Oculto', icon: '👳‍♂️' };
    }
  };

  const { name, subtitle, icon } = getEntityInfo();
  const idleText = `${name} AGUARDA SUA INTENÇÃO...`;

  return (
    <div className="relative w-full max-w-sm mx-auto group">
      {/* Aura de Luxo */}
      <div className={`absolute -inset-1 bg-gradient-to-tr ${isRelationship ? 'from-purple-600 via-pink-200 to-indigo-900' : 'from-amber-600 via-amber-200 to-amber-900'} rounded-2xl opacity-10 blur-2xl group-hover:opacity-20 transition duration-1000`}></div>
      
      <div className="relative aspect-[4/5] bg-neutral-900 rounded-xl overflow-hidden border border-amber-500/30 shadow-2xl flex flex-col items-center justify-center">
        
        {status === 'idle' && (
          <div className="flex flex-col items-center text-center p-8 space-y-6">
            <div className="w-20 h-20 rounded-full border border-amber-900/40 flex items-center justify-center">
               <span className="text-4xl text-amber-900 opacity-30">{icon}</span>
            </div>
            <p className="font-cinzel text-amber-700 tracking-[0.2em] text-xs animate-gold uppercase">{idleText}</p>
          </div>
        )}

        {status === 'thinking' && (
          <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center space-y-6 z-20 backdrop-blur-sm">
            <div className="relative">
              <div className="w-16 h-16 border-2 border-amber-500/20 rounded-full animate-ping absolute inset-0"></div>
              <div className="w-16 h-16 border-t-2 border-amber-500 rounded-full animate-spin"></div>
            </div>
            <p className="font-cinzel text-amber-500 text-[10px] tracking-[0.4em] uppercase">Auditando Destinos</p>
          </div>
        )}

        {(status === 'result' || status === 'thinking') && image && (
          <img 
            src={image} 
            alt={name} 
            className={`w-full h-full object-cover transition-all duration-2000 ${status === 'thinking' ? 'opacity-30 scale-110 blur-sm' : 'opacity-100 scale-100'}`}
          />
        )}

        <div className="absolute bottom-0 left-0 w-full bg-gradient-to-t from-black via-black/90 to-transparent p-6 pt-12">
          <h3 className="text-amber-500 font-cinzel text-lg tracking-[0.3em] text-center drop-shadow-md">{name}</h3>
          <div className="h-px w-12 bg-amber-800 mx-auto my-2"></div>
          <p className="text-[9px] text-amber-700 text-center uppercase tracking-[0.4em]">{subtitle}</p>
        </div>
      </div>
    </div>
  );
};

export default MasterPresence;
