import React from 'react';
import { motion } from 'framer-motion';
import { BookOpen, Cpu, Zap, ShieldCheck, ChevronRight, X } from 'lucide-react';

interface OracleContent {
  origin: string;
  tradition: string;
  focus: string;
  description: string;
  entity: string;
  archetype: string;
}

const ORACLE_DATA: Record<string, OracleContent> = {
  geomancy: {
    origin: "Árabe e Medieval",
    tradition: "O Escudo da Terra",
    focus: "Decisões Práticas e Vida Material",
    description: "A Geomância é um dos oráculos mais antigos da humanidade, mapeando as energias da terra através de 16 figuras sagradas.",
    entity: "Sr. Capa Preta",
    archetype: "Espírito banqueiro, mestre da riqueza e da estratégia oculta."
  },
  astrology: {
    origin: "Caldeia e Helênica",
    tradition: "Swiss Ephemeris & ML",
    focus: "Mapeamento de Destino e Ciclos",
    description: "A leitura da assinatura do universo no momento do seu nascimento através de cálculos astronômicos de alta precisão.",
    entity: "Professor Jupiter",
    archetype: "Mestre das estrelas e do cosmos, sábio acadêmico dos destinos celestiais."
  },
  tarot: {
    origin: "Egípcia e Europeia",
    tradition: "Thoth (Aleister Crowley)",
    focus: "Vontade Verdadeira e Arquétipos",
    description: "Uma ferramenta de alta magia que mergulha no subconsciente para revelar a Vontade Verdadeira.",
    entity: "Dona Maria Mulambo",
    archetype: "Rainha das Encruzilhadas, direta e visceral, conhece os segredos da alma."
  },
  kabbalah: {
    origin: "Hebraica (Zohar)",
    tradition: "72 Nomes de Deus",
    focus: "Retificação (Tikkun) e Luz",
    description: "A tecnologia da alma para identificar pontos de correção e permitir que a Luz volte a fluir.",
    entity: "Senhor Zohar",
    archetype: "Guardião da luz e dos mistérios profundos da retificação espiritual."
  },
  supreme: {
    origin: "Gnóstica e Crística",
    tradition: "Cristo & Madalena",
    focus: "Graça Divina e Equilíbrio",
    description: "A união das polaridades sagradas para trazer uma mensagem de amor incondicional e cura.",
    entity: "Jesus e Maria Madalena",
    archetype: "Equilíbrio sagrado entre o masculino e feminino em estado de graça."
  },
  ifa: {
    origin: "Iorubá (Nigéria)",
    tradition: "Odu Ifá",
    focus: "Ancestralidade e Alinhamento",
    description: "O sistema de adivinhação que revela o Odu — a voz dos ancestrais orientando sua jornada.",
    entity: "Oluwo Pai Cipriano",
    archetype: "Grande sacerdote da floresta, sábio ancestral e guardião da paz."
  },
  istikhara: {
    origin: "Islâmica (Sufismo)",
    tradition: "Salat al-Istikhara",
    focus: "Decisões Cruciais e Paz Interior",
    description: "A consulta divina para buscar clareza se um caminho é benéfico para a alma e para a vida.",
    entity: "Sábio Al-Khidr",
    archetype: "Mestre da orientação divina, traz paz e fé nas encruzilhadas do destino."
  },
  dreams: {
    origin: "Psicanalítica e Mística",
    tradition: "O Interpretador de Sonhos",
    focus: "Sonhos e Psiquismo Profundo",
    description: "Uma imersão nas camadas do inconsciente utilizando os compêndios de Jung, Freud e tradições sagradas.",
    entity: "O Analista",
    archetype: "Síntese de Freud e Jung, navegando entre a ciência da alma e os mistérios do espírito."
  }
};

interface OracleIntroProps {
  onClose: () => void;
  onProceed: () => void;
  oracleId: string;
  oracleName: string;
}

const OracleIntro: React.FC<OracleIntroProps> = ({ onClose, onProceed, oracleId, oracleName }) => {
  const content = ORACLE_DATA[oracleId] || ORACLE_DATA.geomancy;

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/90 backdrop-blur-md"
    >
      <motion.div 
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        className="glass-card max-w-2xl w-full p-8 md:p-12 rounded-[3rem] border-amber-500/30 relative overflow-hidden"
      >
        {/* Decorative background */}
        <div className="absolute top-0 right-0 p-8 opacity-5">
          <Zap size={200} className="text-amber-500" />
        </div>

        <button 
          onClick={onClose}
          className="absolute top-6 right-6 text-amber-900 hover:text-amber-500 transition-colors"
        >
          <X size={24} />
        </button>

        <div className="space-y-8 relative z-10">
          <div className="text-center space-y-2">
            <div className="inline-block px-4 py-1 bg-amber-500/10 border border-amber-500/20 rounded-full text-[10px] text-amber-500 font-bold tracking-[0.3em] uppercase mb-2">
              Origem: {content.origin}
            </div>
            <h2 className="text-3xl md:text-4xl font-cinzel gold-text-shimmer uppercase tracking-tight">
              {oracleName}
            </h2>
            <p className="text-amber-700/60 italic">{content.tradition}</p>
          </div>

          <div className="space-y-6">
            <div className="p-6 bg-amber-500/5 rounded-2xl border border-amber-500/10">
              <p className="text-sm text-amber-100/90 leading-relaxed text-center italic">
                "{content.description}"
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2 p-4 bg-amber-500/5 rounded-xl border border-amber-500/10">
                <div className="flex items-center gap-2 text-amber-500">
                  <BookOpen size={16} />
                  <h3 className="font-cinzel text-[10px] uppercase tracking-widest">Foco da Consulta</h3>
                </div>
                <p className="text-xs text-amber-100/70">{content.focus}</p>
              </div>

              <div className="space-y-2 p-4 bg-amber-500/10 rounded-xl border border-amber-500/30">
                <div className="flex items-center gap-2 text-amber-400">
                   <Zap size={16} />
                  <h3 className="font-cinzel text-[10px] uppercase tracking-widest font-bold">Mestre Regente</h3>
                </div>
                <p className="text-xs text-amber-100 font-bold">{content.entity}</p>
                <p className="text-[10px] text-amber-500/60 leading-tight italic">"{content.archetype}"</p>
              </div>
            </div>

            <div className="space-y-4 p-6 bg-amber-500/5 rounded-2xl border border-amber-500/10">
              <div className="flex items-center gap-3 text-amber-500">
                <Zap size={20} />
                <h3 className="font-cinzel text-sm uppercase tracking-widest">O que esperar?</h3>
              </div>
              <p className="text-xs text-amber-100/70 leading-relaxed">
                Ao prosseguir, você criará um momento de sincronicidade. O Mestre Black Cape analisará os símbolos revelados para entregar uma auditoria estratégica de sua vida, focada em clareza e resultados.
              </p>
            </div>
          </div>

          <div className="pt-4">
            <button
              onClick={onProceed}
              className="w-full bg-amber-600 text-black font-cinzel font-bold py-5 rounded-2xl tracking-[0.2em] flex items-center justify-center gap-3 hover:bg-amber-500 transition-all shadow-2xl group"
            >
              INICIAR CONSULTA EM {oracleName.toUpperCase()}
              <ChevronRight className="group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default OracleIntro;
