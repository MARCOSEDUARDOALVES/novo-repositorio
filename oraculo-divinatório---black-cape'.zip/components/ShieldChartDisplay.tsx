
import React from 'react';
import { ShieldChart } from '../types';
import FigureDisplay from './FigureDisplay';

interface ShieldChartDisplayProps {
  chart: ShieldChart;
}

const ShieldChartDisplay: React.FC<ShieldChartDisplayProps> = ({ chart }) => {
  return (
    <div className="shield-grid py-10 w-full">
      
      {/* Nível 1: Mães e Filhas (As 8 figuras primárias) */}
      <div className="w-full overflow-x-auto pb-4">
        <div className="flex flex-col gap-6 items-center">
          <div className="flex gap-3 justify-center">
            {chart.mothers.map((fig, idx) => (
              <FigureDisplay key={`mother-${idx}`} figure={fig} label={`Mãe ${idx + 1}`} size="md" />
            ))}
            <div className="w-px bg-amber-900/30 mx-2 self-stretch" />
            {chart.daughters.map((fig, idx) => (
              <FigureDisplay key={`daughter-${idx}`} figure={fig} label={`Filha ${idx + 1}`} size="md" />
            ))}
          </div>
          <p className="text-[10px] font-cinzel text-amber-900 tracking-[0.8em] uppercase">Fundamentos do Destino</p>
        </div>
      </div>

      {/* Nível 2: Sobrinhos */}
      <div className="flex flex-col gap-4 items-center">
        <div className="flex gap-4 justify-center">
          {chart.nephews.map((fig, idx) => (
            <FigureDisplay key={`nephew-${idx}`} figure={fig} label={`Sobrinho ${idx + 1}`} size="md" />
          ))}
        </div>
        <p className="text-[10px] font-cinzel text-amber-900 tracking-[0.6em] uppercase">Processos e Fluxos</p>
      </div>

      {/* Nível 3: Testemunhas */}
      <div className="flex flex-col gap-4 items-center">
        <div className="flex gap-8 justify-center">
          <FigureDisplay figure={chart.witnesses[0]} label="Passado" size="lg" />
          <FigureDisplay figure={chart.witnesses[1]} label="Futuro" size="lg" />
        </div>
        <p className="text-[10px] font-cinzel text-amber-900 tracking-[0.4em] uppercase">Testemunhas</p>
      </div>

      {/* Nível 4: Juiz e Reconciliador */}
      <div className="flex flex-col items-center gap-6 relative">
        <div className="absolute -top-12 left-1/2 -translate-x-1/2 w-px h-12 bg-gradient-to-b from-amber-900/30 to-amber-500/50"></div>
        
        <div className="flex flex-col items-center gap-8">
           <div className="relative group">
              <div className="absolute -inset-2 bg-amber-500/10 blur-xl group-hover:bg-amber-500/20 transition-all"></div>
              <FigureDisplay figure={chart.judge} label="O JUIZ" size="lg" />
           </div>

           {chart.reconciler && (
             <div className="mt-8 border-t border-amber-900/40 pt-8 flex flex-col items-center">
                <FigureDisplay figure={chart.reconciler} label="O Reconciliador" size="md" />
                <p className="text-[8px] font-cinzel text-amber-800 mt-2 tracking-widest">A SOMA FINAL</p>
             </div>
           )}
        </div>
      </div>
    </div>
  );
};

export default ShieldChartDisplay;
