import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, Loader2, CreditCard, Cross, Heart, Star, Sun, Moon } from 'lucide-react';
import { interpretSupremeOracle, generatePersonaPortrait } from '../services/geminiService';
import TtsButton from './TtsButton';
import { Apostle, ConsultationObjective } from '../types';
import ReactMarkdown from 'react-markdown';

interface SupremeOracleProps {
  hasKey: boolean;
  onSelectKey: () => void;
  objective: ConsultationObjective;
  onResult: (image: string | null, text: string) => void;
}

const APOSTLES: Apostle[] = [
  { name: "Bartolomeu", sign: "Áries", archetype: "O Pioneiro e o Fogo da Fé" },
  { name: "Tiago Menor", sign: "Touro", archetype: "A Estabilidade e o Solo Sagrado" },
  { name: "André", sign: "Gêmeos", archetype: "O Mensageiro e a Dualidade da Alma" },
  { name: "Pedro", sign: "Câncer", archetype: "A Rocha e a Emoção Protetora" },
  { name: "Judas Iscariotes", sign: "Leão", archetype: "A Sombra do Ego e o Brilho do Poder" },
  { name: "João", sign: "Virgem", archetype: "A Pureza e o Serviço Devocional" },
  { name: "Tiago Maior", sign: "Libra", archetype: "O Equilíbrio e a Justiça Divina" },
  { name: "Tomé", sign: "Escorpião", archetype: "A Dúvida que Transforma e a Profundidade" },
  { name: "Filipe", sign: "Sagitário", archetype: "A Busca pela Verdade e a Expansão" },
  { name: "Mateus", sign: "Capricórnio", archetype: "A Estrutura e a Responsabilidade Espiritual" },
  { name: "Tadeu", sign: "Aquário", archetype: "A Fraternidade e a Visão do Futuro" },
  { name: "Simão", sign: "Peixes", archetype: "O Sacrifício e a Compaixão Universal" },
];

const SupremeOracle: React.FC<SupremeOracleProps> = ({ hasKey, onSelectKey, objective, onResult }) => {
  const [question, setQuestion] = useState('');
  const [step, setStep] = useState<'form' | 'analyzing' | 'result'>('form');
  const [selectedApostle, setSelectedApostle] = useState<Apostle | null>(null);
  const [report, setReport] = useState<string>('');
  const [paid, setPaid] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [portrait, setPortrait] = useState<string | null>(null);

  const handleStartReading = () => {
    if (!question.trim()) {
      setError("O Cristo e Madalena aguardam sua pergunta sincera.");
      return;
    }
    if (!hasKey) {
      setError("A conexão com o Oráculo Supremo exige a Chave da Sabedoria (API Key).");
      return;
    }
    setError(null);
    handleGenerate();
  };

  const handleGenerate = () => {
    setLoading(true);
    setStep('analyzing');
    
    // Sorteio do Apóstolo
    const randomApostle = APOSTLES[Math.floor(Math.random() * APOSTLES.length)];
    setSelectedApostle(randomApostle);

    setTimeout(async () => {
      try {
        const [result, img] = await Promise.all([
          interpretSupremeOracle(question, randomApostle, objective),
          generatePersonaPortrait('supreme', objective).catch(() => null)
        ]);
        setReport(result);
        setPortrait(img);
        onResult(img, result);
        setStep('result');
      } catch (err) {
        setError("A conexão com o plano supremo foi interrompida.");
        setStep('form');
      } finally {
        setLoading(false);
      }
    }, 5000);
  };

  return (
    <div className="w-full max-w-4xl mx-auto">
      <AnimatePresence mode="wait">
        {step === 'form' && (
          <motion.div
            key="form"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="glass-card p-8 md:p-12 rounded-[3rem] space-y-8 border-amber-500/20"
          >
            <div className="text-center space-y-4">
              <div className="flex justify-center gap-4 text-amber-500">
                <Sun size={24} className="animate-pulse" />
                <Cross size={32} />
                <Moon size={24} className="animate-pulse" />
              </div>
              <h2 className="text-4xl font-cinzel gold-text-shimmer uppercase tracking-widest">Oráculo Supremo</h2>
              <p className="text-amber-700/60 font-light italic text-sm">A Voz do Cristo Cósmico & Maria Madalena</p>
            </div>

            <div className="space-y-4">
              <label className="block text-amber-600 text-[10px] uppercase tracking-widest text-center">
                Sua Súplica ou Questionamento
              </label>
              <p className="text-amber-900/40 text-[9px] uppercase tracking-widest text-center italic">Orientação: Para uma resposta clara, faça uma pergunta objetiva.</p>
              <textarea
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                placeholder="Abra seu coração para a Luz..."
                className="w-full bg-black/40 border border-amber-900/20 rounded-2xl p-6 text-amber-100 font-cinzel text-lg text-center focus:outline-none focus:border-amber-500 transition-all placeholder:text-amber-900/20 min-h-[150px]"
              />
            </div>

            {error && <p className="text-red-500 text-[10px] text-center uppercase tracking-widest font-bold">{error}</p>}

            {!hasKey && (
              <button onClick={onSelectKey} className="w-full bg-amber-600/10 border border-amber-500/40 text-amber-500 font-cinzel text-xs py-3 rounded-lg hover:bg-amber-500/20 transition-all">
                CONFIGURAR ACESSO (CHAVE API)
              </button>
            )}

            <button
              onClick={handleStartReading}
              className="w-full bg-gradient-to-r from-amber-700 to-amber-900 text-black font-cinzel font-bold py-5 rounded-2xl tracking-[0.3em] hover:scale-[1.02] transition-all shadow-xl active:scale-95"
            >
              INVOCAR A LUZ SUPREMA
            </button>
          </motion.div>
        )}

        {step === 'analyzing' && (
          <motion.div
            key="analyzing"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex flex-col items-center justify-center space-y-12 py-20"
          >
            <div className="relative">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
                className="w-56 h-56 border-2 border-dashed border-amber-500/20 rounded-full flex items-center justify-center"
              >
                <div className="text-amber-500/40 text-6xl font-cinzel">🕊️</div>
              </motion.div>
              <div className="absolute inset-0 flex items-center justify-center">
                <Loader2 className="text-amber-500 animate-spin" size={64} />
              </div>
            </div>
            <div className="text-center space-y-4">
              <h3 className="text-2xl font-cinzel gold-text-shimmer animate-pulse uppercase">Sintonizando com o Cristo e Madalena...</h3>
              <p className="text-amber-700/60 text-xs tracking-[0.2em] uppercase italic">Acessando os Registros Akáshicos</p>
            </div>
          </motion.div>
        )}

        {step === 'result' && selectedApostle && (
          <motion.div
            key="result"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-8"
          >
            {portrait && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="w-full aspect-[4/3] rounded-[3rem] overflow-hidden border border-amber-500/20 shadow-2xl relative"
              >
                <img src={portrait} alt="Cristo e Madalena" className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-12">
                  <div className="space-y-2">
                    <h3 className="text-3xl font-cinzel text-amber-100 uppercase tracking-widest">A Presença Divina</h3>
                    <p className="text-amber-500/60 text-sm italic">Cristo Cósmico & Maria Madalena</p>
                  </div>
                </div>
              </motion.div>
            )}

            <div className="glass-card p-12 rounded-[3rem] text-center space-y-6 border-amber-500/30">
              <div className="text-[10px] text-amber-700 uppercase tracking-[0.5em] mb-4">Arquétipo do Apóstolo</div>
              <div className="text-4xl md:text-6xl font-cinzel gold-text-shimmer tracking-widest mb-4">
                {selectedApostle.name}
              </div>
              <div className="h-px w-24 bg-amber-900/40 mx-auto"></div>
              <h3 className="text-2xl font-cinzel text-amber-100 uppercase tracking-widest">
                {selectedApostle.sign}
              </h3>
              <p className="text-amber-700/60 text-xs italic">{selectedApostle.archetype}</p>
            </div>

            <div className="relative">
              <div className="glass-card p-8 md:p-12 rounded-[3rem] relative overflow-hidden">
                {!paid ? null : (
                  <TtsButton 
                    text={report} 
                    voice="Kore" 
                    className="absolute top-6 right-6 z-20" 
                  />
                )}
                <div className="prose prose-invert prose-amber max-w-none">
                  <div className="markdown-body">
                    {/* Show first paragraph as preview, blur the rest */}
                    <div className="mb-4">
                      <ReactMarkdown>{report.split('\n\n')[0]}</ReactMarkdown>
                    </div>
                    <div className={`transition-all duration-1000 ${!paid ? 'blur-lg select-none pointer-events-none opacity-40' : ''}`}>
                      <ReactMarkdown>{report.split('\n\n').slice(1).join('\n\n')}</ReactMarkdown>
                    </div>
                  </div>
                </div>

                <div className="mt-12 pt-8 border-t border-amber-900/20 flex flex-wrap gap-4 justify-center">
                  <div className="flex items-center gap-2 px-4 py-2 bg-amber-500/5 rounded-full border border-amber-500/10">
                    <Heart size={14} className="text-amber-500" />
                    <span className="text-[10px] text-amber-600 uppercase tracking-widest font-bold">Amor Incondicional</span>
                  </div>
                  <div className="flex items-center gap-2 px-4 py-2 bg-amber-500/5 rounded-full border border-amber-500/10">
                    <Star size={14} className="text-amber-500" />
                    <span className="text-[10px] text-amber-600 uppercase tracking-widest font-bold">Luz Crística</span>
                  </div>
                </div>
              </div>

              {!paid && (
                <div className="absolute inset-x-0 bottom-0 z-10 flex items-center justify-center p-12 bg-gradient-to-t from-black via-black/80 to-transparent pt-32 rounded-b-[3rem]">
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="glass-card p-12 rounded-[3rem] border-amber-500/40 bg-black/80 backdrop-blur-md text-center space-y-8 max-w-md shadow-2xl"
                  >
                    <div className="w-20 h-20 bg-amber-500/10 rounded-full flex items-center justify-center mx-auto border border-amber-500/20">
                      <CreditCard className="text-amber-500" size={32} />
                    </div>
                    <div className="space-y-2">
                      <h3 className="text-2xl font-cinzel text-amber-100 uppercase tracking-widest">Revelar Graça</h3>
                      <p className="text-amber-700/60 text-xs italic">O acesso ao Oráculo Supremo requer uma contribuição para a manutenção do templo digital.</p>
                    </div>
                    <div className="text-4xl font-cinzel gold-text-shimmer">R$ 19,99</div>
                    <div className="space-y-4">
                      <button
                        onClick={() => setPaid(true)}
                        className="w-full bg-amber-600 text-black font-cinzel font-bold py-4 rounded-xl tracking-widest hover:bg-amber-500 transition-all shadow-lg active:scale-95"
                      >
                        PAGAR COM PIX OU CARTÃO
                      </button>
                      <p className="text-amber-900/40 text-[8px] uppercase tracking-widest">Pagamento seguro via Pix ou Cartão de Crédito</p>
                    </div>
                  </motion.div>
                </div>
              )}
            </div>

            <button
              onClick={() => {
                setStep('form');
                setPaid(false);
              }}
              className="block mx-auto text-amber-900 hover:text-amber-600 text-[10px] uppercase tracking-[0.5em] transition-all font-cinzel border-b border-transparent hover:border-amber-600 pb-1"
            >
              — Nova Consulta Suprema —
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default SupremeOracle;
