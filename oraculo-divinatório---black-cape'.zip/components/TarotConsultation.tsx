import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, Loader2, CreditCard, ChevronRight, LayoutGrid } from 'lucide-react';
import { interpretTarotReading, interpretTarotSubAudit, generatePersonaPortrait } from '../services/geminiService';
import TtsButton from './TtsButton';
import { TarotCard, ConsultationObjective, TarotSubAudit } from '../types';
import ReactMarkdown from 'react-markdown';

interface TarotConsultationProps {
  hasKey: boolean;
  onSelectKey: () => void;
  objective: ConsultationObjective;
  onResult: (image: string | null, text: string) => void;
}

const THOTH_CARDS: TarotCard[] = [
  { name: "O Louco", arcana: "major" },
  { name: "O Mago", arcana: "major" },
  { name: "A Sacerdotisa", arcana: "major" },
  { name: "A Imperatriz", arcana: "major" },
  { name: "O Imperador", arcana: "major" },
  { name: "O Hierofante", arcana: "major" },
  { name: "Os Amantes", arcana: "major" },
  { name: "A Carruagem", arcana: "major" },
  { name: "O Ajustamento", arcana: "major" },
  { name: "O Eremita", arcana: "major" },
  { name: "A Fortuna", arcana: "major" },
  { name: "A Luxúria", arcana: "major" },
  { name: "O Enforcado", arcana: "major" },
  { name: "A Morte", arcana: "major" },
  { name: "A Arte", arcana: "major" },
  { name: "O Diabo", arcana: "major" },
  { name: "A Torre", arcana: "major" },
  { name: "A Estrela", arcana: "major" },
  { name: "A Lua", arcana: "major" },
  { name: "O Sol", arcana: "major" },
  { name: "O Aeon", arcana: "major" },
  { name: "O Universo", arcana: "major" },
  { name: "Ás de Bastões", arcana: "minor", suit: "wands" },
  { name: "Dois de Bastões (Domínio)", arcana: "minor", suit: "wands" },
  { name: "Três de Bastões (Virtude)", arcana: "minor", suit: "wands" },
  { name: "Ás de Copas", arcana: "minor", suit: "cups" },
  { name: "Dois de Copas (Amor)", arcana: "minor", suit: "cups" },
  { name: "Ás de Espadas", arcana: "minor", suit: "swords" },
  { name: "Ás de Discos", arcana: "minor", suit: "disks" },
];

const TarotConsultation: React.FC<TarotConsultationProps> = ({ hasKey, onSelectKey, objective, onResult }) => {
  const isRelationship = objective === 'relationship';
  const personaName = 'Dona Maria Mulambo';

  const [question, setQuestion] = useState('');
  const [subQuestion, setSubQuestion] = useState('');
  const [step, setStep] = useState<'form' | 'analyzing' | 'result'>('form');
  const [selectedCards, setSelectedCards] = useState<TarotCard[]>([]);
  const [report, setReport] = useState<string>('');
  const [paid, setPaid] = useState(false);
  const [subAudits, setSubAudits] = useState<TarotSubAudit[]>([]);
  const [loading, setLoading] = useState(false);
  const [subLoading, setSubLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleStartReading = () => {
    if (!question.trim()) {
      setError(`O Mestre exige uma pergunta clara para o Tarô.`);
      return;
    }
    if (!hasKey) {
      setError("Configure sua chave API para acessar o conhecimento oculto.");
      return;
    }
    setError(null);
    handleGenerate();
  };

  const handleGenerate = () => {
    setLoading(true);
    setStep('analyzing');
    
    // Sortear 6 cartas para a Mandala
    const shuffled = [...THOTH_CARDS].sort(() => 0.5 - Math.random());
    const cards = shuffled.slice(0, 6);
    setSelectedCards(cards);

    setTimeout(async () => {
      try {
        const [img, result] = await Promise.all([
          generatePersonaPortrait('tarot', objective).catch(() => null),
          interpretTarotReading(question, cards, objective)
        ]);
        setReport(result);
        onResult(img, result);
        setStep('result');
      } catch (err) {
        setError("Erro na conexão com o plano astral.");
        setStep('form');
      } finally {
        setLoading(false);
      }
    }, 3000);
  };

  const handleSubAudit = async () => {
    if (!subQuestion.trim()) return;
    setSubLoading(true);
    
    try {
      // Sortear 3 cartas para o desmembramento
      const shuffled = [...THOTH_CARDS].sort(() => 0.5 - Math.random());
      const cards = shuffled.slice(0, 3);
      
      const subText = await interpretTarotSubAudit(subQuestion, cards, question, objective);
      
      const newSub: TarotSubAudit = {
        question: subQuestion,
        cards,
        interpretation: subText
      };
      
      setSubAudits([newSub, ...subAudits]);
      setSubQuestion('');
    } catch (err) {
      console.error(err);
    } finally {
      setSubLoading(false);
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto">
      <AnimatePresence mode="wait">
        {step === 'form' && (
          <motion.div
            key="form"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="glass-card p-8 md:p-12 rounded-[3rem] space-y-8"
          >
            <div className="text-center space-y-2">
              <h2 className="text-3xl font-cinzel gold-text-shimmer uppercase tracking-widest">Mandala do Tarô de Thoth</h2>
              <p className="text-amber-700/60 font-light italic">A Visão de Aleister Crowley sobre sua Vontade Verdadeira</p>
            </div>

            <div className="space-y-4">
              <label className="block text-amber-600 text-[10px] uppercase tracking-widest text-center">
                Sua Pergunta Estratégica
              </label>
              <p className="text-amber-900/40 text-[9px] uppercase tracking-widest text-center italic">Orientação: Para uma resposta clara, faça uma pergunta objetiva.</p>
              <textarea
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                placeholder="Ex: Qual o próximo passo para minha expansão de mercado?"
                className="w-full bg-black/40 border border-amber-900/20 rounded-2xl p-6 text-amber-100 font-cinzel text-lg text-center focus:outline-none focus:border-amber-500 transition-all placeholder:text-amber-900/20 min-h-[120px]"
              />
            </div>

            {error && <p className="text-red-500 text-[10px] text-center uppercase tracking-widest font-bold">{error}</p>}

            {!hasKey && (
              <button onClick={onSelectKey} className="w-full bg-amber-600/10 border border-amber-500/40 text-amber-500 font-cinzel text-xs py-3 rounded-lg hover:bg-amber-500/20 transition-all">
                CONFIGURAR ACESSO (CHAVE API)
              </button>
            )}

            <button
              onClick={handleStartReading}
              className="w-full bg-gradient-to-r from-amber-700 to-amber-900 text-black font-cinzel font-bold py-5 rounded-2xl tracking-[0.3em] hover:scale-[1.02] transition-all shadow-xl active:scale-95"
            >
              CONSULTAR A MANDALA
            </button>
          </motion.div>
        )}

        {step === 'analyzing' && (
          <motion.div
            key="analyzing"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex flex-col items-center justify-center space-y-12 py-20"
          >
            <div className="flex gap-4">
              {[0, 1, 2, 3, 4, 5].map((i) => (
                <motion.div
                  key={i}
                  animate={{ 
                    rotateY: [0, 180, 360],
                    y: [0, -10, 0]
                  }}
                  transition={{ 
                    duration: 2, 
                    repeat: Infinity, 
                    delay: i * 0.2 
                  }}
                  className="w-16 h-24 bg-amber-900/20 border border-amber-500/30 rounded-lg flex items-center justify-center"
                >
                  <div className="text-amber-500/20 text-xl font-cinzel">⚜</div>
                </motion.div>
              ))}
            </div>
            <div className="text-center space-y-4">
              <h3 className="text-2xl font-cinzel gold-text-shimmer animate-pulse uppercase">Invocando Dona Maria Mulambo...</h3>
              <p className="text-amber-700/60 text-xs tracking-[0.2em] uppercase italic">"Rainha das Sete Catacumbas, abra os caminhos"</p>
            </div>
          </motion.div>
        )}

        {step === 'result' && (
          <motion.div
            key="result"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-8"
          >
            <div className="grid grid-cols-3 md:grid-cols-6 gap-4">
              {selectedCards.map((card, i) => (
                <motion.div
                  key={i}
                  initial={{ rotateY: 90, opacity: 0 }}
                  animate={{ rotateY: 0, opacity: 1 }}
                  transition={{ delay: i * 0.2 }}
                  className="glass-card p-3 rounded-xl border-amber-500/40 text-center space-y-1"
                >
                  <div className="aspect-[2/3] bg-black/40 rounded-lg flex items-center justify-center border border-amber-900/20 mb-1">
                    <LayoutGrid className="text-amber-500/20" size={24} />
                  </div>
                  <p className="text-[8px] text-amber-700 uppercase tracking-widest">Posição {i + 1}</p>
                  <p className="text-amber-100 font-cinzel text-[10px] font-bold uppercase truncate">{card.name}</p>
                </motion.div>
              ))}
            </div>

            <div className="relative">
              <div className="glass-card p-8 md:p-12 rounded-[3rem] relative overflow-hidden">
                {!paid ? null : (
                  <TtsButton 
                    text={report} 
                    voice="Kore" 
                    className="absolute top-6 right-6 z-20" 
                  />
                )}
                <div className="prose prose-invert prose-amber max-w-none">
                  <div className="markdown-body">
                    {/* Show first paragraph as preview, blur the rest */}
                    <div className="mb-4">
                      <ReactMarkdown>{report.split('\n\n')[0]}</ReactMarkdown>
                    </div>
                    <div className={`transition-all duration-1000 ${!paid ? 'blur-lg select-none pointer-events-none opacity-40' : ''}`}>
                      <ReactMarkdown>{report.split('\n\n').slice(1).join('\n\n')}</ReactMarkdown>
                    </div>
                  </div>
                </div>

                <div className="mt-12 pt-8 border-t border-amber-900/20 flex flex-wrap gap-4 justify-center">
                  <div className="flex items-center gap-2 px-4 py-2 bg-amber-500/5 rounded-full border border-amber-500/10">
                    <Sparkles size={14} className="text-amber-500" />
                    <span className="text-[10px] text-amber-600 uppercase tracking-widest font-bold">Fonte: Aleister Crowley</span>
                  </div>
                  <div className="flex items-center gap-2 px-4 py-2 bg-amber-500/5 rounded-full border border-amber-500/10">
                    <ChevronRight size={14} className="text-amber-500" />
                    <span className="text-[10px] text-amber-600 uppercase tracking-widest font-bold">Thoth Tarot Mandala</span>
                  </div>
                </div>
              </div>

              {!paid && (
                <div className="absolute inset-x-0 bottom-0 z-10 flex items-center justify-center p-12 bg-gradient-to-t from-black via-black/80 to-transparent pt-32 rounded-b-[3rem]">
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="glass-card p-12 rounded-[3rem] border-amber-500/40 bg-black/80 backdrop-blur-md text-center space-y-8 max-w-md shadow-2xl"
                  >
                    <div className="w-20 h-20 bg-amber-500/10 rounded-full flex items-center justify-center mx-auto border border-amber-500/20">
                      <CreditCard className="text-amber-500" size={32} />
                    </div>
                    <div className="space-y-2">
                      <h3 className="text-2xl font-cinzel text-amber-100 uppercase tracking-widest">Revelar Mandala</h3>
                      <p className="text-amber-700/60 text-xs italic">O acesso à egrégora de Crowley exige uma contribuição para o equilíbrio das forças.</p>
                    </div>
                    <div className="text-4xl font-cinzel gold-text-shimmer">R$ 19,99</div>
                    <div className="space-y-4">
                      <button
                        onClick={() => setPaid(true)}
                        className="w-full bg-amber-600 text-black font-cinzel font-bold py-4 rounded-xl tracking-widest hover:bg-amber-500 transition-all shadow-lg active:scale-95"
                      >
                        PAGAR COM PIX OU CARTÃO
                      </button>
                      <p className="text-amber-900/40 text-[8px] uppercase tracking-widest">Pagamento seguro via Pix ou Cartão de Crédito</p>
                    </div>
                  </motion.div>
                </div>
              )}
            </div>

            {/* SUB-AUDIT (DESMEMBRAMENTO) */}
            <div className="space-y-6">
              <div className="glass-card p-8 rounded-[2rem] border-amber-500/20 space-y-4">
                <h3 className="text-xl font-cinzel text-amber-500 uppercase tracking-widest text-center">Desmembrar Assunto (Combo 3 Cartas)</h3>
                <div className="flex gap-4">
                  <input 
                    type="text"
                    value={subQuestion}
                    onChange={(e) => setSubQuestion(e.target.value)}
                    placeholder="Dúvida específica sobre este jogo..."
                    className="flex-1 bg-black/40 border border-amber-900/20 rounded-xl px-6 py-4 text-amber-100 focus:outline-none focus:border-amber-500 transition-all"
                  />
                  <button 
                    onClick={handleSubAudit}
                    disabled={subLoading || !subQuestion.trim()}
                    className="bg-amber-600 text-black px-8 rounded-xl font-cinzel font-bold hover:bg-amber-500 transition-all disabled:opacity-50"
                  >
                    {subLoading ? <Loader2 className="animate-spin" /> : "DESMEMBRAR"}
                  </button>
                </div>
              </div>

              <AnimatePresence>
                {subAudits.map((sub, idx) => (
                  <motion.div
                    key={idx}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="glass-card p-8 rounded-[2rem] border-amber-900/20 space-y-6"
                  >
                    <div className="flex items-center justify-between border-b border-amber-900/20 pb-4">
                      <h4 className="text-amber-500 font-cinzel text-sm uppercase tracking-widest">Detalhamento: {sub.question}</h4>
                      <div className="flex gap-2">
                        {sub.cards.map((c, i) => (
                          <div key={i} className="px-2 py-1 bg-amber-900/20 rounded text-[8px] text-amber-100 uppercase border border-amber-500/20">
                            {c.name}
                          </div>
                        ))}
                      </div>
                    </div>
                    <div className="prose prose-invert prose-sm max-w-none">
                      <ReactMarkdown>{sub.interpretation}</ReactMarkdown>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>

            <button
              onClick={() => {
                setStep('form');
                setSubAudits([]);
                setQuestion('');
                setPaid(false);
              }}
              className="block mx-auto text-amber-900 hover:text-amber-600 text-[10px] uppercase tracking-[0.5em] transition-all font-cinzel border-b border-transparent hover:border-amber-600 pb-1"
            >
              — Nova Consulta ao Tarô —
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default TarotConsultation;
