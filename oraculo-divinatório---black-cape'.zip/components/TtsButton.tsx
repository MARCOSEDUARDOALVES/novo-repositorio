import React, { useState } from 'react';
import { Volume2, VolumeX, Loader2 } from 'lucide-react';
import { textToSpeech } from '../services/geminiService';

interface TtsButtonProps {
  text: string;
  voice?: 'Puck' | 'Charon' | 'Kore' | 'Fenrir' | 'Zephyr';
  className?: string;
}

const TtsButton: React.FC<TtsButtonProps> = ({ text, voice = 'Kore', className = "" }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [audioSource, setAudioSource] = useState<AudioBufferSourceNode | null>(null);
  const [audioContext, setAudioContext] = useState<AudioContext | null>(null);

  const stopAudio = () => {
    if (audioSource) {
      audioSource.stop();
      setAudioSource(null);
    }
    setIsPlaying(false);
  };

  const playAudio = async () => {
    if (isPlaying) {
      stopAudio();
      return;
    }

    setIsLoading(true);
    try {
      const base64Audio = await textToSpeech(text, voice);
      if (!base64Audio) {
        setIsLoading(false);
        return;
      }

      const ctx = audioContext || new (window.AudioContext || (window as any).webkitAudioContext)();
      if (!audioContext) setAudioContext(ctx);

      // Decode base64 to binary
      const binaryString = atob(base64Audio);
      const len = binaryString.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }

      // Convert to Int16Array (Gemini TTS usually returns 16-bit PCM)
      const pcmData = new Int16Array(bytes.buffer);
      
      // Create AudioBuffer
      const audioBuffer = ctx.createBuffer(1, pcmData.length, 24000);
      const channelData = audioBuffer.getChannelData(0);
      
      // Normalize to -1.0 to 1.0 range
      for (let i = 0; i < pcmData.length; i++) {
        channelData[i] = pcmData[i] / 32768.0;
      }

      const source = ctx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(ctx.destination);
      source.onended = () => {
        setIsPlaying(false);
        setAudioSource(null);
      };

      source.start();
      setAudioSource(source);
      setIsPlaying(true);
    } catch (error) {
      console.error("Error playing audio:", error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <button
      onClick={playAudio}
      disabled={isLoading}
      className={`p-2 rounded-full bg-amber-600/10 border border-amber-600/20 text-amber-600 hover:bg-amber-600/20 transition-all ${className}`}
      title={isPlaying ? "Parar de ouvir" : "Ouvir interpretação"}
    >
      {isLoading ? (
        <Loader2 size={20} className="animate-spin" />
      ) : isPlaying ? (
        <VolumeX size={20} />
      ) : (
        <Volume2 size={20} />
      )}
    </button>
  );
};

export default TtsButton;
