
import { BinaryRow, GeomanticFigure } from './types';

export const GEOMANTIC_FIGURES: Record<string, GeomanticFigure> = {
  "1111": { name: "Via", rows: [1, 1, 1, 1], element: "Water", meaning: "The Path. Change, journey, isolation." },
  "2222": { name: "Populus", rows: [2, 2, 2, 2], element: "Water", meaning: "The People. Gathering, neutrality, public affairs." },
  "1122": { name: "Conjunctio", rows: [1, 1, 2, 2], element: "Air", meaning: "Conjunction. Meeting, joining, union." },
  "2211": { name: "Carcer", rows: [2, 2, 1, 1], element: "Earth", meaning: "The Prison. Restraint, stability, boundaries." },
  "1212": { name: "Albus", rows: [1, 2, 1, 2], element: "Water", meaning: "White. Wisdom, peace, clarity." },
  "2121": { name: "Rubeus", rows: [2, 1, 2, 1], element: "Fire", meaning: "Red. Passion, anger, violence." },
  "1221": { name: "Fortuna Major", rows: [1, 2, 2, 1], element: "Fire", meaning: "Greater Fortune. Success from within, solid victory." },
  "2112": { name: "Fortuna Minor", rows: [2, 1, 1, 2], element: "Fire", meaning: "Lesser Fortune. Speed, external luck, temporary gain." },
  "1121": { name: "Puella", rows: [1, 1, 2, 1], element: "Air", meaning: "The Girl. Harmony, beauty, shallow joy." },
  "2122": { name: "Puer", rows: [2, 1, 2, 2], element: "Fire", meaning: "The Boy. Energy, impulsiveness, aggression." },
  "1211": { name: "Amissio", rows: [1, 2, 1, 1], element: "Fire", meaning: "Loss. Giving up, depletion, sacrifice." },
  "1112": { name: "Acquisitio", rows: [1, 1, 1, 2], element: "Air", meaning: "Gain. Profit, increase, expansion." },
  "1222": { name: "Caput Draconis", rows: [1, 2, 2, 2], element: "Earth", meaning: "Head of the Dragon. New beginnings, entry." },
  "2221": { name: "Cauda Draconis", rows: [2, 2, 2, 1], element: "Fire", meaning: "Tail of the Dragon. Ending, exit, bad karma." },
  "2212": { name: "Laetitia", rows: [2, 2, 1, 2], element: "Air", meaning: "Joy. Happiness, laughter, elevation." },
  "2111": { name: "Tristitia", rows: [2, 1, 1, 1], element: "Earth", meaning: "Sorrow. Weight, depression, depth." },
};

export const findFigureByRows = (rows: [BinaryRow, BinaryRow, BinaryRow, BinaryRow]): GeomanticFigure => {
  const key = rows.join('');
  return GEOMANTIC_FIGURES[key];
};
