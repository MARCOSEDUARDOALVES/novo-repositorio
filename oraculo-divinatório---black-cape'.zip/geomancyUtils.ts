
import { BinaryRow, GeomanticFigure, ShieldChart } from './types';
import { GEOMANTIC_FIGURES, findFigureByRows } from './constants';

const getRandomRow = (): BinaryRow => (Math.random() > 0.5 ? 2 : 1);

const getRandomFigure = (): GeomanticFigure => {
  const rows: [BinaryRow, BinaryRow, BinaryRow, BinaryRow] = [
    getRandomRow(),
    getRandomRow(),
    getRandomRow(),
    getRandomRow()
  ];
  return findFigureByRows(rows);
};

const addRows = (rowA: BinaryRow, rowB: BinaryRow): BinaryRow => {
  // 1 = Odd, 2 = Even
  // Odd + Odd = Even (1+1=2)
  // Odd + Even = Odd (1+2=3 -> 1)
  // Even + Even = Even (2+2=4 -> 2)
  const sum = rowA + rowB;
  return sum % 2 === 0 ? 2 : 1;
};

const mergeFigures = (figA: GeomanticFigure, figB: GeomanticFigure): GeomanticFigure => {
  const newRows: [BinaryRow, BinaryRow, BinaryRow, BinaryRow] = [
    addRows(figA.rows[0], figB.rows[0]),
    addRows(figA.rows[1], figB.rows[1]),
    addRows(figA.rows[2], figB.rows[2]),
    addRows(figA.rows[3], figB.rows[3]),
  ];
  return findFigureByRows(newRows);
};

export const generateShieldChart = (): ShieldChart => {
  // 1. Generate 4 Mothers
  const mothers: [GeomanticFigure, GeomanticFigure, GeomanticFigure, GeomanticFigure] = [
    getRandomFigure(),
    getRandomFigure(),
    getRandomFigure(),
    getRandomFigure()
  ];

  // 2. Derive 4 Daughters from Mothers (transposition)
  // Daughter 1 is made of Row 1 of all 4 Mothers, etc.
  const d1Rows: [BinaryRow, BinaryRow, BinaryRow, BinaryRow] = [mothers[0].rows[0], mothers[1].rows[0], mothers[2].rows[0], mothers[3].rows[0]];
  const d2Rows: [BinaryRow, BinaryRow, BinaryRow, BinaryRow] = [mothers[0].rows[1], mothers[1].rows[1], mothers[2].rows[1], mothers[3].rows[1]];
  const d3Rows: [BinaryRow, BinaryRow, BinaryRow, BinaryRow] = [mothers[0].rows[2], mothers[1].rows[2], mothers[2].rows[2], mothers[3].rows[2]];
  const d4Rows: [BinaryRow, BinaryRow, BinaryRow, BinaryRow] = [mothers[0].rows[3], mothers[1].rows[3], mothers[2].rows[3], mothers[3].rows[3]];

  const daughters: [GeomanticFigure, GeomanticFigure, GeomanticFigure, GeomanticFigure] = [
    findFigureByRows(d1Rows),
    findFigureByRows(d2Rows),
    findFigureByRows(d3Rows),
    findFigureByRows(d4Rows)
  ];

  // 3. Derive 4 Nephews
  // Nephew 1 = Mother 1 + Mother 2
  // Nephew 2 = Mother 3 + Mother 4
  // Nephew 3 = Daughter 1 + Daughter 2
  // Nephew 4 = Daughter 3 + Daughter 4
  const nephews: [GeomanticFigure, GeomanticFigure, GeomanticFigure, GeomanticFigure] = [
    mergeFigures(mothers[0], mothers[1]),
    mergeFigures(mothers[2], mothers[3]),
    mergeFigures(daughters[0], daughters[1]),
    mergeFigures(daughters[2], daughters[3])
  ];

  // 4. Derive 2 Witnesses
  // Right Witness = Nephew 1 + Nephew 2
  // Left Witness = Nephew 3 + Nephew 4
  const witnesses: [GeomanticFigure, GeomanticFigure] = [
    mergeFigures(nephews[0], nephews[1]),
    mergeFigures(nephews[2], nephews[3])
  ];

  // 5. Derive the Judge
  // Judge = Witness 1 + Witness 2
  const judge = mergeFigures(witnesses[0], witnesses[1]);

  // 6. Optional Reconciler
  // Reconciler = Judge + Mother 1
  const reconciler = mergeFigures(judge, mothers[0]);

  return { mothers, daughters, nephews, witnesses, judge, reconciler };
};
