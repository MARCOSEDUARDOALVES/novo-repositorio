
import { GoogleGenAI, Modality } from "@google/genai";
import { ShieldChart, GeomanticFigure, TarotCard, KabbalahName, ConsultationObjective, Apostle, IfaOdu } from "../types";

/**
 * Get the persona prompt based on the oracle and objective.
 */
const getOraclePersona = (oracle: string, objective: ConsultationObjective) => {
  const objectives = {
    relationship: "Foque em sentimentos, conexões de alma, desejos ocultos e reconciliação.",
    financial: "Foque em prosperidade, caminhos abertos, estratégia de poder e crescimento de ativos."
  };

  const personas: Record<string, { name: string, description: string }> = {
    geomancy: {
      name: "Banqueiro Árabe (Sr. Capa Preta)",
      description: "Você é o 'Sr. Capa Preta', um poderoso banqueiro árabe, mestre da riqueza, da estratégia financeira e das ciências ocultas. Sua linguagem é polida, autoritária, implacável e utiliza metáforas de alta finança, ROI espiritual e sabedoria das areias."
    },
    astrology: {
      name: "Professor Jupiter",
      description: "Você é o 'Professor Jupiter', o maior mestre das estrelas e do cosmos. Sua linguagem é acadêmica, precisa, sábia e profundamente conectada aos ciclos planetários e ao destino escrito no céu."
    },
    tarot: {
      name: "Dona Maria Mulambo",
      description: "Você é 'Dona Maria Mulambo', a Rainha das Sete Catacumbas e das Encruzilhadas. Você é a mestra dos caminhos e dos segredos do Tarô. Sua linguagem é direta, visceral, empoderada e conhece todas as dores e glórias humanas."
    },
    kabbalah: {
      name: "Senhor Zohar",
      description: "Você é o 'Senhor Zohar', o guardião da luz e dos mistérios da Cabala. Você fala com a voz dos profetas, buscando a retificação da alma (Tikkun) e o fluxo da energia divina."
    },
    supreme: {
      name: "Jesus e Maria Madalena",
      description: "Você é a voz dual do 'Cristo Cósmico' e de 'Maria Madalena'. Sua sabedoria une o Sagrado Masculino e Feminino em um equilíbrio perfeito de amor e cura."
    },
    ifa: {
      name: "Oluwo Pai Cipriano",
      description: "Você é o 'Oluwo Pai Cipriano', o grande sacerdote da floresta e dos Odus de Ifá. Sua sabedoria é ancestral, ligada à terra e aos orixás. Sua voz é a voz da experiência e da paz."
    },
    istikhara: {
      name: "Sábio Al-Khidr",
      description: "Você é o 'Sábio Al-Khidr', o mestre da orientação divina no Islã. Sua linguagem é de paz, fé e busca pela clareza na vontade divina através do Istikhara."
    },
    dreams: {
      name: "O Analista do Inconsciente",
      description: "Você é uma síntese de C.G. Jung, Freud, Artemidoro e a sabedoria mística do Zohar e do Islã. Você analisa sonhos e o psiquismo humano. Sua linguagem é profunda, simbólica, psicanalítica e espiritual. Você é um profundo conhecedor da 'Divina Comédia' de Dante, do 'Livro Vermelho' de Jung, das teorias de Freud, da 'Oneirocritica' de Artemidoro e do 'Dicionário de Símbolos' de Jean Chevalier. Você integra interpretações cabalísticas do Zohar e a tradição profética islâmica sobre sonhos."
    }
  };

  const p = personas[oracle] || personas.geomancy;
  return `Persona: ${p.name}. Descrição: ${p.description} Objetivo da Consulta: ${objectives[objective]}`;
};

/**
 * Interprets an Ifá reading based on 3 traditional Odus and the wisdom of Oluwo Pai Cipriano.
 */
export const interpretIfaReading = async (question: string, odus: IfaOdu[], objective: ConsultationObjective): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const persona = getOraclePersona('ifa', objective);
  
  const prompt = `
    ${persona}
    O cliente busca uma auditoria espiritual sobre: "${question}"
    Os 3 Odus revelados são: ${odus.map(o => o.name).join(', ')}
    
    ESTRUTURA:
    - # 🐚 IFÁ: A VOZ DE OLUWO PAI CIPRIANO
    - ## I. Configuração dos Odus
    - ## II. Caminhos do Ebó
    - ## III. Veredito de Ifá
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: { temperature: 0.7 }
    });
    return response.text;
  } catch (error: any) {
    return "Oluwo Pai Cipriano pede paciência.";
  }
};

/**
 * Interprets a reading from the Supreme Oracle.
 */
export const interpretSupremeOracle = async (question: string, apostle: Apostle, objective: ConsultationObjective): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const persona = getOraclePersona('supreme', objective);
  
  const prompt = `
    ${persona}
    Pergunta: "${question}"
    Arquétipo: ${apostle.name} (${apostle.archetype})
    
    ESTRUTURA:
    - # 🕊️ ORÁCULO SUPREMO: CRISTO & MADALENA
    - ## I. Mensagem de ${apostle.name}
    - ## II. Veredito Dual
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: { temperature: 0.7 }
    });
    return response.text;
  } catch (error: any) {
    return "As esferas de luz estão em silêncio.";
  }
};

/**
 * Interprets a Kabbalistic reading.
 */
export const interpretKabbalahReading = async (question: string, name: KabbalahName, objective: ConsultationObjective): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const persona = getOraclePersona('kabbalah', objective);
  
  const prompt = `
    ${persona}
    Pergunta: "${question}"
    Nome Sagrado: ${name.letters} (${name.meaning})
    
    ESTRUTURA:
    - # 🔯 CABALA: A LUZ DE SENHOR ZOHAR
    - ## I. Emanação da Luz
    - ## II. Veredito do Zohar
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: { temperature: 0.6 }
    });
    return response.text;
  } catch (error: any) {
    return "Senhor Zohar está em meditação.";
  }
};

/**
 * Interprets a Tarot reading.
 */
export const interpretTarotReading = async (question: string, cards: TarotCard[], objective: ConsultationObjective): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const persona = getOraclePersona('tarot', objective);
  
  const prompt = `
    ${persona}
    Pergunta: "${question}"
    Cartas: ${cards.map(c => c.name).join(', ')}
    
    ESTRUTURA:
    - # 🃏 TARÔ: A VISÃO DE DONA MARIA MULAMBO
    - ## I. Configuração das Forças
    - ## II. Veredito da Rainha
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: { temperature: 0.7 }
    });
    return response.text;
  } catch (error: any) {
    return "Maria Mulambo está cuidando dos caminhos.";
  }
};

/**
 * Generates the portrait for each entity.
 */
export const generatePersonaPortrait = async (oracle: string, objective: ConsultationObjective): Promise<string | null> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const prompts: Record<string, string> = {
    geomancy: 'Realistic portrait of "Sr. Capa Preta" as an opulent Arab Banker in a high-end black silk thobe and embroidered bisht (cape) with gold details. He has an authoritative expression, looking like an elite wealth manager. Background: an ultra-luxurious private club in Dubai with gold accents.',
    astrology: 'Realistic portrait of "Professor Jupiter", wise astronomer in blue star robes holding astrolabe. Background: observatory library.',
    tarot: 'Realistic portrait of "Dona Maria Mulambo", elegant woman in red/purple lace, Queen of Streets. Background: mystical night crossroad.',
    kabbalah: 'Realistic portrait of "Senhor Zohar", ancient Jewish sage in white robes reading a golden scroll. Background: glowing Hebrew letters.',
    supreme: 'Realistic portrait of the Cosmic Christ and Mary Magdalene in divine balance. Golden auras, ethereal garden.',
    ifa: 'Realistic portrait of "Oluwo Pai Cipriano", elderly black priest in white clothes and sacred beads. Background: sacred forest.',
    istikhara: 'Realistic portrait of "Sábio Al-Khidr", serene Middle Eastern advisor in green/white clothes. Background: moonlit oasis.',
    dreams: 'Realistic portrait of a dual figure, half Sigmund Freud, half C.G. Jung, sitting in a library filled with mirrors and nebula-like floating symbols. Surreal indigo atmosphere.'
  };

  const prompt = prompts[oracle] || prompts.geomancy;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-image-preview',
      contents: { parts: [{ text: prompt }] },
      config: { imageConfig: { aspectRatio: "3:4", imageSize: "4K" } }
    });

    if (response.candidates?.[0]?.content?.parts) {
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    return null;
  } catch (error: any) {
    return null;
  }
};

/**
 * Interprets the geomantic shield chart.
 */
export const interpretReading = async (question: string, chart: ShieldChart, objective: ConsultationObjective) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const persona = getOraclePersona('geomancy', objective);
  
  const prompt = `${persona}\nPergunta: "${question}"\nJuiz: ${chart.judge.name}. Dê o veredito.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: { temperature: 0.8 }
    });
    return response.text;
  } catch (error: any) {
    return "Os registros de Capa Preta estão em manutenção.";
  }
};

/**
 * Astrology interpretation.
 */
export const interpretAstrology = async (
  birthData: { date: string, time: string, location: string }, 
  objective: ConsultationObjective,
  partnerData?: { date: string, time: string, location: string }
) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const persona = getOraclePersona('astrology', objective);
  const isSynastry = objective === 'relationship' && partnerData;

  const prompt = `${persona}\nDados: P1(${birthData.date}), ${isSynastry ? `P2(${partnerData.date})` : ''}\nAudite o destino celestial.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: { temperature: 0.6 }
    });
    return response.text;
  } catch (error: any) {
    return "Professor Jupiter está recalibrando seu astrolábio.";
  }
};

/**
 * Istikhara interpretation.
 */
export const interpretIstikhara = async (question: string, objective: ConsultationObjective): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const persona = getOraclePersona('istikhara', objective);
  const prompt = `${persona}\nBusca de clareza: "${question}"`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: { temperature: 0.7 }
    });
    return response.text;
  } catch (error: any) {
    return "O Sábio Al-Khidr está em prece.";
  }
};

export const getDailyTransits = async () => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const prompt = `Forneça os trânsitos astrológicos principais para hoje em formato JSON: sunSign, moonSign, moonPhase, highlight, advice.`;
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: { temperature: 0.5, responseMimeType: "application/json" }
    });
    return JSON.parse(response.text);
  } catch (error: any) {
    return { sunSign: "Peixes", moonSign: "Gêmeos", moonPhase: "Crescente", highlight: "Sensibilidade alta.", advice: "Confie na intuição." };
  }
};

export const generateAstrologyPreview = async (
  birthData: { date: string, time: string, location: string }, 
  objective: ConsultationObjective,
  partnerData?: { date: string, time: string, location: string }
) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const persona = getOraclePersona('astrology', objective);
  const prompt = `${persona}\nGere pílula de marketing em JSON: title, sun, moon, ascendant, hook.`;
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: { temperature: 0.9, responseMimeType: "application/json" }
    });
    return JSON.parse(response.text);
  } catch (error: any) {
    return { title: "Destino Incerto", sun: "N/A", moon: "N/A", ascendant: "N/A", hook: "Raridade detectada." };
  }
};

export const interpretSubAudit = async (question: string, figures: GeomanticFigure[], judge: GeomanticFigure, objective: ConsultationObjective) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const persona = getOraclePersona('geomancy', objective);
  const prompt = `${persona}\nResponda sobre: "${question}" baseado no Juiz ${judge.name}.`;
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview', contents: prompt, config: { temperature: 0.9 }
    });
    return response.text;
  } catch (err) { return "Capa Preta está ocupado."; }
};

export const interpretTarotSubAudit = async (question: string, cards: TarotCard[], originalQuestion: string, objective: ConsultationObjective) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const persona = getOraclePersona('tarot', objective);
  const prompt = `${persona}\nResponda sobre: "${question}" com as cartas ${cards.map(c => c.name).join(', ')}. Pergunta original: ${originalQuestion}`;
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview', contents: prompt, config: { temperature: 0.9 }
    });
    return response.text;
  } catch (err) { return "Mulambo está rodando a saia."; }
};

export const interpretIfaSubAudit = async (question: string, odus: IfaOdu[], originalQuestion: string, objective: ConsultationObjective) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const persona = getOraclePersona('ifa', objective);
  const prompt = `${persona}\nResponda sobre: "${question}" com o Odu ${odus[0].name}. Pergunta original: ${originalQuestion}`;
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview', contents: prompt, config: { temperature: 0.9 }
    });
    return response.text;
  } catch (err) { return "Ifá está em silêncio."; }
};

/**
 * Dream Interpretation and Psychoanalytic Session.
 */
export const interpretDream = async (dreamDescription: string, objective: ConsultationObjective): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const persona = getOraclePersona('dreams', objective);
  
  const prompt = `
    ${persona}
    Relato do Sonho: "${dreamDescription}"
    
    Sua missão é realizar uma Análise Profunda do Inconsciente, funcionando como um compêndio vivo de sabedoria psicanalítica e espiritual.
    
    REFERÊNCIAS OBRIGATÓRIAS:
    - Jung: Sombra, Anima/Animus, Livro Vermelho.
    - Freud: Id/Ego/Superego, Desejos Reprimidos.
    - Clássicos: Artemidoro (Oneirocritica), Jean Chevalier (Dicionário de Símbolos).
    - Espiritual: Zohar (Kabbalah), Tradição Islâmica (Sunnah e Sonhos), Divina Comédia (Dante).
    
    ESTRUTURA DA RESPOSTA (Markdown):
    - # 🌀 O LABIRINTO DO INCONSCIENTE: ANÁLISE PSICANALÍTICA
    - ## I. Fenomenologia (Principais Arquétipos)
    - ## II. Topografia Analítica (Jung & Freud)
    - ## III. Portais Sagrados (Zohar, Islã e Literatura)
    - ## IV. Síncrese do Analista (Conclusão)
    
    Mantenha um tom profissional, erudito e profundo.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: { temperature: 0.8 }
    });
    return response.text;
  } catch (error: any) {
    return "O inconsciente está nublado. Tente novamente.";
  }
};

/**
 * Continuing the consultation (Chat).
 */
export const dreamChat = async (history: { role: 'user' | 'model', content: string }[], objective: ConsultationObjective): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const persona = getOraclePersona('dreams', objective);
  
  const formattedHistory = history.map(h => ({
    role: h.role === 'user' ? 'user' : 'model',
    parts: [{ text: h.content }]
  }));

  try {
    const chat = ai.chats.create({
      model: 'gemini-3-flash-preview',
      history: [
        { role: 'user', parts: [{ text: `Você é o Analista. ${persona}. Inicie o processo psicanalítico.` }] },
        ...formattedHistory.slice(0, -1)
      ]
    });

    const lastMessage = history[history.length - 1].content;
    const result = await chat.sendMessage({ message: lastMessage });
    return result.text || "O silêncio do inconsciente.";
  } catch (error: any) {
    return "A transferência psicanalítica foi interrompida. Tente novamente.";
  }
};

/**
 * Converts text to speech using Gemini TTS.
 */
export const textToSpeech = async (text: string, voice: 'Puck' | 'Charon' | 'Kore' | 'Fenrir' | 'Zephyr' = 'Kore'): Promise<string | null> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  try {
    // Process text to remove markdown headers and symbols for cleaner speech
    const cleanText = text.replace(/[#*`_~🌀🃏🔯🕊️🐚🌙♛🃏]/g, '').trim();

    const response = await ai.models.generateContent({
      model: "gemini-3.1-flash-tts-preview",
      contents: [{ parts: [{ text: `Read this with a wise, mystical and authoritative tone: ${cleanText}` }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: voice },
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    return base64Audio || null;
  } catch (error: any) {
    console.error("TTS Error:", error);
    return null;
  }
};
