
export type BinaryRow = 1 | 2; // 1 = one dot (odd), 2 = two dots (even)

export type ConsultationObjective = 'financial' | 'relationship';

export interface GeomanticFigure {
  name: string;
  rows: [BinaryRow, BinaryRow, BinaryRow, BinaryRow];
  element: 'Earth' | 'Air' | 'Fire' | 'Water';
  meaning: string;
}

export interface ShieldChart {
  mothers: [GeomanticFigure, GeomanticFigure, GeomanticFigure, GeomanticFigure];
  daughters: [GeomanticFigure, GeomanticFigure, GeomanticFigure, GeomanticFigure];
  nephews: [GeomanticFigure, GeomanticFigure, GeomanticFigure, GeomanticFigure];
  witnesses: [GeomanticFigure, GeomanticFigure];
  judge: GeomanticFigure;
  reconciler?: GeomanticFigure;
}

export interface SubAudit {
  question: string;
  mothers: [GeomanticFigure, GeomanticFigure, GeomanticFigure, GeomanticFigure];
  quickJudge: GeomanticFigure;
  interpretation: string;
}

export interface BirthData {
  date: string;
  time: string;
  location: string;
  latitude?: number;
  longitude?: number;
}

export interface AstrologyReport {
  birthData: BirthData;
  chartData: any; // Raw data from "Janus" simulation
  interpretation: string;
  careerAnalysis: string;
  purposeAnalysis: string;
}

export interface ReadingResponse {
  interpretation: string;
  summary: string;
}

export interface TarotCard {
  name: string;
  arcana: 'major' | 'minor';
  suit?: 'wands' | 'cups' | 'swords' | 'disks';
  value?: string;
  image?: string;
}

export interface TarotReading {
  question: string;
  cards: TarotCard[];
  interpretation: string;
}

export interface TarotSubAudit {
  question: string;
  cards: TarotCard[];
  interpretation: string;
}

export interface KabbalahName {
  id: number;
  letters: string;
  meaning: string;
}

export interface KabbalahReading {
  question: string;
  name: KabbalahName;
  interpretation: string;
}

export interface Apostle {
  name: string;
  sign: string;
  archetype: string;
}

export interface SupremeReading {
  question: string;
  apostle: Apostle;
  psalm: string;
  parable: string;
  interpretation: string;
}

export interface IfaOdu {
  name: string;
  binary: [BinaryRow, BinaryRow, BinaryRow, BinaryRow]; // Representing the Odu pattern
  meaning: string;
}

export interface IfaReading {
  question: string;
  odus: IfaOdu[];
  interpretation: string;
}

export interface IfaSubAudit {
  question: string;
  odus: IfaOdu[];
  interpretation: string;
}

export interface IstikharaReading {
  question: string;
  interpretation: string;
  guidance: string;
  prayer?: string;
}
